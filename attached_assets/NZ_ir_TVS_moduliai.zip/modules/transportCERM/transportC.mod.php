<?php
//////////////////////////////////////////////////
//2016.01.12
// Transporto skaiciuokles modulis
/////////////////////////////////////////////////

$root_path = COMMON::getRootFolder();
require_once ($root_path . "modules/module.php");
//require_once ($root_path . "modules/db_mysql.php");

class transportC_mod extends module {

    
    function __construct($uid=0) {
            parent::__construct();
            
    }//end function 




///////////////////////////////////////////////////////////////////////////////////////////////////////////
// TRANSPORTO KAINU IVEDIMO FUNKCIJOS
///////////////////////////////////////////////////////////////////////////////////////////////////////


    ///////////////////////////////////////////////////////////////////////////////////////////////////
    //nuskaito nauja transporto kainyna CSV formate, parsina, istrina sena ir sukelia nauja i DB
    public function kainynasInsert($updateUID=null){


            $csv = array();

            //var_dump($_FILES);

            // check there are no errors
            if($_FILES['kainCfile']['error'] == 0){
                $name = $_FILES['kainCfile']['name'];
                $ext = strtolower(end(explode('.', $_FILES['kainCfile']['name'])));
                $type = $_FILES['kainCfile']['type'];
                $tmpName = $_FILES['kainCfile']['tmp_name'];

                // check the file is a csv
                if($ext === 'csv'){
                    if(($handle = fopen($tmpName, 'r')) !== FALSE) {
                        // necessary if a large csv file
                        set_time_limit(0);

                        //paruosiam rezultatu Array
                        $kainynas = array();

                        $kodai = array();
                        $kainos = array();

                        $el=0;
                        $row = 0;

                        $yraKlaidu = 'NE';
                        $arBuvoKlaidaKodai='NE';
                        $arBuvoKlaidaSvoriai='NE';
                        $arBuvoKlaidaKaina='NE';
//echo "<br><br><Br>";
                        while(($data = fgetcsv($handle, 3000, ',')) !== FALSE) {
                            // number of fields in the csv
                            $col_count = count($data);

                            $kod = strtoupper($data[0]);

                            switch ($kod) {
                                case 'SALIS':
                                    if($data[1]){
                                        $kainynas['SALIS'] = iconv ("CP1257","UTF-8", $data[1]);
                                    }else{
                                        $yraKlaidu = 'TAIP';
                                        $this->AddError('Klaida šalies pavadinime');
                                    }
                                    break;
                                case 'IMONE':
                                    if($data[1]){
                                        $kainynas['IMONE'] = iconv ("CP1257","UTF-8", $data[1]);
                                    }else{
                                        $yraKlaidu = 'TAIP';
                                        $this->AddError('Klaida įmonės pavadinime');
                                    }
                                    break;
                                case 'PAVAD':
                                    if($data[1]){
                                        $kainynas['PAVAD'] = iconv ("CP1257","UTF-8", $data[1]);
                                    }else{
                                        $yraKlaidu = 'TAIP';
                                        $this->AddError('Klaida kainyno pavadinime');
                                    }
                                    break;
                                case 'BUDAS':
                                    $galimiBudai = array("ZEME", "ORAS", "DOC");
                                    if(in_array(strtoupper($data[1]), $galimiBudai)){
                                        $kainynas['BUDAS'] = strtoupper($data[1]);
                                    }else{
                                        $yraKlaidu = 'TAIP';
                                        $this->AddError('Neteisingas pristatymo būdas:'.strtoupper($data[1]));
                                    }

                                    break;
                                case 'EXIM':
                                    $galimiEXIM = array("EXP", "IMP", "UNIV");
                                    if(in_array(strtoupper($data[1]), $galimiEXIM)){
                                        $kainynas['ExIm'] = strtoupper($data[1]);
                                    }else{
                                        $kainynas['ExIm'] = "X";
                                        $yraKlaidu = 'TAIP';
                                        $this->AddError('Neteisingai nurodyta ar Importo Kainynas ar Exporto ar Universalus (EXIM):'.strtoupper($data[1]));
                                    }

                                    break;
                                case 'KURO_MOKESTIS':
                                    $data[1] = str_replace(',', '.', $data[1]);
                                    if(is_numeric($data[1])){
                                        $kainynas['KURO_MOKESTIS'] = $data[1];
                                        $kainynas['KURO_MOKESTIS_TIP'] = strtoupper($data[2]);
                                    }else{
                                        $yraKlaidu = 'TAIP';
                                        $this->AddError('Kuro mokestis turi būti skaičius');
                                    }
                                    break;
                                case 'SAUGOS_MOK':
                                    $data[1] = str_replace(',', '.', $data[1]);
                                    if(is_numeric($data[1])){
                                        $kainynas['SAUGOS_MOK'] = $data[1];
                                        $kainynas['SAUGOS_MOK_TIP'] = strtoupper($data[2]);
                                    }else{
                                        $yraKlaidu = 'TAIP';
                                        $this->AddError('Saugos mokestis turi būti skaičius');
                                    }
                                    break;

                                case 'PRISTAT_DIENOS':
                                    $data[1] = str_replace(',', '.', $data[1]);
                                    if(is_numeric($data[1])){
                                        $kainynas['PRISTAT_DIENOS'] = $data[1];
                                        //$kainynas['PRISTAT_DIENOS_TIP'] = $data[2];
                                    }else{
                                        //$yraKlaidu = 'TAIP';
                                        //$this->AddError('Pristatymo dienos būti skaičius');
                                    }
                                    break;
                                case 'PRISTAT_DIENOS_MAX':
                                    $data[1] = str_replace(',', '.', $data[1]);
                                    if(is_numeric($data[1])){
                                        $kainynas['PRISTAT_DIENOS_MAX'] = $data[1];
                                        //$kainynas['KURO_MOKESTIS_MAX_TIP'] = $data[2];
                                    }else{
                                        //$yraKlaidu = 'TAIP';
                                        //$this->AddError('Pristatymo dienos MAX turi būti skaičius');
                                    }
                                    break;
                                case 'ATOKIU_VIETOVIU_PRIST_MOK':
                                    $data[1] = str_replace(',', '.', $data[1]);
                                    if(is_numeric($data[1])){
                                        $kainynas['ATOKIU_VIETOVIU_PRIST_MOK'] = $data[1];
                                        $kainynas['ATOKIU_VIETOVIU_PRIST_MOK_TIP'] = strtoupper($data[2]);
                                    }else{
                                        $yraKlaidu = 'TAIP';
                                        $this->AddError('Atokių vietų pristatymo mokestis turi būti skaičius');
                                    }

                                    break;
                                case 'NEUTRALUS_PRISTATYMAS':
                                    $data[1] = str_replace(',', '.', $data[1]);
                                    if(is_numeric($data[1])){
                                        $kainynas['NEUTRALUS_PRIST_MOK'] = $data[1];
                                        $kainynas['NEUTRALUS_PRIST_MOK_TIP'] = strtoupper($data[2]);
                                    }else{
                                        $yraKlaidu = 'TAIP';
                                        $this->AddError('Atokių vietų pristatymo mokestis turi būti skaičius');
                                    }

                                    break;
                                case 'IMPORTO_MOK':
                                    $data[1] = str_replace(',', '.', $data[1]);
                                    if(is_numeric($data[1])){
                                        $kainynas['IMPORTO_MOK'] = $data[1];
                                        $kainynas['IMPORTO_MOK_TIP'] = strtoupper($data[2]);
                                    }else{
                                        $yraKlaidu = 'TAIP';
                                        $this->AddError('Importo mokestis turi būti skaičius: ' . $data[1]);
                                    }
                                    break;
                                case 'DAUGIAU1PAK_MOK':
                                    $data[1] = str_replace(',', '.', $data[1]);
                                    if(is_numeric($data[1])){
                                        $kainynas['DAUGIAU1PAK_MOK'] = $data[1];
                                        $kainynas['DAUGIAU1PAK_MOK_TIP'] = strtoupper($data[2]);
                                    }else{
                                        $yraKlaidu = 'TAIP';
                                        $this->AddError('Importo mokestis turi būti skaičius: ' . $data[1]);
                                    }
                                    break;
                                case 'MUITINES_TARPININK_PASL':
                                    $data[1] = str_replace(',', '.', $data[1]);
                                    if(is_numeric($data[1])){
                                        $kainynas['MUITINES_TARPININK_PASL'] = $data[1];
                                        $kainynas['MUITINES_TARPININK_PASL_TIP'] = strtoupper($data[2]);
                                    }else{
                                        $yraKlaidu = 'TAIP';
                                        $this->AddError('Muitinės tarpininko mokestis turi būti skaičius');
                                    }

                                    break;

                                    
                                case 'ISVYKIMO_DIENOS':
                                    $data[1] = str_replace(',', '.', $data[1]);
                                    $kainynas['ISVYKIMO_DIENOS'] = $data[1];

                                    break;

                                case 'IKI_9_00':
                                    $data[1] = str_replace(',', '.', $data[1]);
                                    if(is_numeric($data[1])){
                                        $kainynas['IKI_9_00'] = $data[1];
                                        $kainynas['IKI_9_00_TIP'] = strtoupper($data[2]);
                                    }else{
                                        $yraKlaidu = 'TAIP';
                                        $this->AddError('Iki 9 val. mokestis turi būti skaičius');
                                    }

                                    break;
                                case 'IKI_10_00':
                                    $data[1] = str_replace(',', '.', $data[1]);
                                    if(is_numeric($data[1])){
                                        $kainynas['IKI_10_00'] = $data[1];
                                        $kainynas['IKI_10_00_TIP'] = strtoupper($data[2]);
                                    }else{
                                        $yraKlaidu = 'TAIP';
                                        $this->AddError('Iki 10 val. mokestis turi būti skaičius');
                                    }

                                    break;
                                case 'IKI_12_00':
                                    $data[1] = str_replace(',', '.', $data[1]);
                                    if(is_numeric($data[1])){
                                        $kainynas['IKI_12_00'] = $data[1];
                                        $kainynas['IKI_12_00_TIP'] = strtoupper($data[2]);
                                    }else{
                                        $yraKlaidu = 'TAIP';
                                        $this->AddError('Iki 12 val. mokestis turi būti skaičius');
                                    }

                                    break;


                                case 'PASTO_KODAS':
                                        //sudarom pasto kodu array, naudosim rasydami kainas
                                        foreach ($data as $key => $kodas) {
                                            
                                            if($kodas OR $key==2 OR $key==0 OR $key==1){ // key=2 praleidziam, nes ten daznai buna 0
                                                //echo "$key => $kodas*| ";
                                                $kodai[$key]['KODAS']=str_pad($kodas,2,"0",STR_PAD_LEFT);
                                            }elseif($arBuvoKlaidaKodai=='NE'){
                                                //echo "$key => $kodas | ";
                                                $yraKlaidu = 'TAIP';
                                                $this->AddError('Nėra arba blogas pašto kodas:' . $key .'=>'. $kodas);
                                                $arBuvoKlaidaKodai='TAIP';
                                            }

                                        }//foreach

                                        if(count($kodai)<=0){
                                            $yraKlaidu = 'TAIP';
                                            $this->AddError('Nenurodytas nei vienas pašto kodas.');
                                        }
                                    break;


                                case 'PRISTAT_DIENOS_K':
                                        //sudarom pasto kodu array, naudosim rasydami kainas
                                        foreach ($data as $key => $dienosK) {
                                            if($dienosK==""){$dienosK=0;}
                                            if(is_numeric($dienosK)  OR $key==0 OR $key==1){
                                                $dienosKArr[$key]['DIENOSK']=$dienosK;
                                            }elseif($arBuvoKlaidaDienos=='NE'){
                                                $yraKlaidu = 'TAIP';
                                                $this->AddError('Nėra arba blogai nurodytos pristatymo dienos');
                                                $arBuvoKlaidaDienos='TAIP';
                                            }

                                        }//foreach

                                        if(count($dienosKArr)<=0){
                                            $yraKlaidu = 'TAIP';
                                            $this->AddError('Nenurodytas nei viena pristatymo diena.');
                                        }
                                    break;

                                case 'PRISTAT_DIENOS_K_MAX':
                                        //sudarom pasto kodu array, naudosim rasydami kainas
                                        foreach ($data as $key => $dienosKMAX) {
                                            if($dienosKMAX==""){$dienosKMAX=0;}
                                            if(is_numeric($dienosKMAX) OR $dienosk=="" OR $key==0 OR $key==1){
                                                $dienosKMAXArr[$key]['DIENOSKMAX']=$dienosKMAX;
                                            }elseif($arBuvoKlaidaDienos=='NE'){
                                                $yraKlaidu = 'TAIP';
                                                $this->AddError('Nėra arba blogai nurodytos MAX pristatymo dienos');
                                                $arBuvoKlaidaDienos='TAIP';
                                            }

                                        }//foreach

                                        if(count($dienosKMAXArr)<=0){
                                            $yraKlaidu = 'TAIP';
                                            $this->AddError('Nenurodytas nei vienas MAX pristatymo diena.');
                                        }
                                    break;


                                case 'SVORIS':
                                        $svoris="";//nunulinam
                                        

                                        if(count($kodai)==count($data)){

                                            foreach ($data as $key => $value) {
                                                
                                                $value=str_replace(' ', '', $value);//pasalinam tarpus
                                                $value=str_replace(',', '', $value);//pasalinam tarpus
                                                $value=str_replace(',', '.', $value);//pakeiciam taskus i kablelius
                                                $value=floatval($value);//pasalinam tarpus jeigu tokiu yra
                                                if($key==1){
                                                    $svoris=$value;
                                                }elseif($key==0){
                                                    //praleidziam rakta, nieko nedarom
                                                }else{
                                                    if(is_numeric($svoris) AND $svoris>0){
                                                        $kainos[$el][$key]['KODAS']=$kodai[$key]['KODAS'];
                                                        $kainos[$el][$key]['DIENOSK']=$dienosKArr[$key]['DIENOSK'];
                                                        $kainos[$el][$key]['DIENOSKMAX']=$dienosKMAXArr[$key]['DIENOSKMAX'];
                                                        $kainos[$el][$key]['SVORIS']=$svoris;

                                                        if(is_numeric($value) AND $value>0){
                                                            $kainos[$el][$key]['KAINA']=$value;
                                                        }else{
                                                            $kainos[$el][$key]['KAINA']=999999;
                                                            //$yraKlaidu = 'TAIP'; Cia kaip klaida neskaitom tik perspejam
                                                            $this->AddMessage('Buvo neteisingai įvestų, arba lygiu 0, kainų. Jos pakeistos į 999999EUR');

                                                        }
                                                        
                                                    }elseif($arBuvoKlaidaSvoris=='NE'){//end if
                                                        $yraKlaidu = 'TAIP';
                                                        $this->AddError('Neteisingai įvestas svoris. Nenurodytas svoris prieš kainų eilutę.');
                                                        $arBuvoKlaidaSvoris='TAIP';
                                                    }//end else
                                                }//end else

                                                
                                            }//foreach
                                            $el++;
                                        }else{//end if
                                            //echo "<br><br><br><hr>".count($kodai)."==".count($data)."--<br>";
                                            /*
                                            for ($i=0; $i < count($data); $i++) { 
                                                echo $i."-".$data[$i]."-<br>";
                                            }
                                            */
                                            $yraKlaidu = 'TAIP';
                                            $this->AddError('Ne pagal šabloną suformuota kainų lentele. Pašto kodų ir kainų turi būti tas pats skaičius eilutėje ');
                                        }
                                        $svoris="";//nunulinam
                                        
                                    break;

                                
                                default:
                                    # nieko nedarom
                                    break;
                            }//end swith


                            $data = array();
                            $row++;
                        }//end while
                        fclose($handle);

                    }


                    if(count($kodai)<=0){
                        $yraKlaidu = 'TAIP';
                        $this->AddError('Nenurodytas nei vienas pašto kodas.');
                    }

                    if(count($dienosKArr)<=0){
                        $yraKlaidu = 'TAIP';
                        $this->AddError('Nenurodytas nei viena pristatymo diena.');
                    }

                    if(count($dienosKMAXArr)<=0){
                        $yraKlaidu = 'TAIP';
                        $this->AddError('Nenurodytas nei viena MAX pristatymo diena.');
                    }




                }else{
                    //echo "ERROR2: " . $ext;
                    $yraKlaidu = 'TAIP';
                    $this->addError ("Failas ne .CSV formato.");
                }//end else
            }else{
                $yraKlaidu = 'TAIP';
                $this->addError ("Failo įkėlimo klaida." . $this->ErrorCodeToMessage($_FILES['kainCfile']['error']));
                //echo "ERROR1: " . $_FILES['csv']['error'];
            }


            //!!!!!! DEBUG
            //$this->var_dump($kainynas, "Kainynas");//-----------------DEBUG

            //!!!!!! DEBUG
            //$this->var_dump($kainos, "kainos elem");//-----------------DEBUG



            ///////////////////////////////////////////////////////////////////////////////////////////////////////
            // IRASOM I DB

            if($yraKlaidu == 'NE' AND count($kainynas)>0 AND count($kainos)>0 ){//rasom i DB


                //tikrinam ar nereikia istrinti senojo
                $delRez = "OK"; //pradzioje skaitom, kad su trinimu viskas ok, nes gal ir nereikes trinti
                if($this->is_ID($updateUID)){
                    $delRez = $this->delKainynas($delUID);
                }

                if($delRez != "OK"){
                    //jeigu reikejo, bet neistryne tai iseinam
                    $this->addError('Klaida. Nepavyko i6trinti seno kainyno.');
                    $rezArray['OK'] = "NOTOK";
                    $rezArray['kainynoUID'] = null;

                    return $rezArray;
                }//end if


                //raso GALVA KAINYNO
                    $Kainyndb = "CERM_Transp";
                    $insertK_arr=array();
                    //$insertK_arr[$Kainyndb]['uid']=$FPKUID;//istrinta
                    $insertK_arr[$Kainyndb]['DateIved']=date("Y-m-d H:i:s");
                    $insertK_arr[$Kainyndb]['DateUpdate']=date("Y-m-d H:i:s");
                    $insertK_arr[$Kainyndb]['Salis']=$kainynas['SALIS'];
                    $insertK_arr[$Kainyndb]['Imone']=$kainynas['IMONE'];
                    $insertK_arr[$Kainyndb]['Pavad']=$kainynas['PAVAD'];
                    $insertK_arr[$Kainyndb]['EXIM']=$kainynas['ExIm'];
                    $insertK_arr[$Kainyndb]['Budas']=$kainynas['BUDAS'];
                    $insertK_arr[$Kainyndb]['KuroMokestis']=$kainynas['KURO_MOKESTIS'];
                    $insertK_arr[$Kainyndb]['KuroMokestisTip']=$kainynas['KURO_MOKESTIS_TIP'];
                    $insertK_arr[$Kainyndb]['SaugosMokestis']=$kainynas['SAUGOS_MOK'];
                    $insertK_arr[$Kainyndb]['SaugosMokestisTip']=$kainynas['SAUGOS_MOK_TIP'];
                    //$insertK_arr[$Kainyndb]['PristatDienu']=$kainynas['PRISTAT_DIENOS'];
                    //$insertK_arr[$Kainyndb]['PristatDienuMax']=$kainynas['PRISTAT_DIENOS_MAX'];
                    $insertK_arr[$Kainyndb]['NeutralusPristat']=$kainynas['NEUTRALUS_PRIST_MOK'];
                    $insertK_arr[$Kainyndb]['NeutralusPristatTip']=$kainynas['NEUTRALUS_PRIST_MOK_TIP'];
                    $insertK_arr[$Kainyndb]['AtokiuVietuMok']=$kainynas['ATOKIU_VIETOVIU_PRIST_MOK'];
                    $insertK_arr[$Kainyndb]['AtokiuVietuTip']=$kainynas['ATOKIU_VIETOVIU_PRIST_MOK_TIP'];
                    $insertK_arr[$Kainyndb]['ImportoMok']=$kainynas['IMPORTO_MOK'];
                    $insertK_arr[$Kainyndb]['ImportoTip']=$kainynas['IMPORTO_MOK_TIP'];
                    $insertK_arr[$Kainyndb]['DaugiauNei1PakMok']=$kainynas['DAUGIAU1PAK_MOK'];
                    $insertK_arr[$Kainyndb]['DaugiauNei1PakTip']=$kainynas['DAUGIAU1PAK_MOK_TIP'];
                    $insertK_arr[$Kainyndb]['MuitinesTarpMok']=$kainynas['MUITINES_TARPININK_PASL'];
                    $insertK_arr[$Kainyndb]['MuitinesTarpTip']=$kainynas['MUITINES_TARPININK_PASL_TIP'];
                    $insertK_arr[$Kainyndb]['IsvykimoDienos']=$kainynas['ISVYKIMO_DIENOS'];
                    $insertK_arr[$Kainyndb]['Iki9']=$kainynas['IKI_9_00'];
                    $insertK_arr[$Kainyndb]['Iki9Tip']=$kainynas['IKI_9_00_TIP'];
                    $insertK_arr[$Kainyndb]['Iki10']=$kainynas['IKI_10_00'];
                    $insertK_arr[$Kainyndb]['Iki10Tip']=$kainynas['IKI_10_00_TIP'];
                    $insertK_arr[$Kainyndb]['Iki12']=$kainynas['IKI_12_00'];
                    $insertK_arr[$Kainyndb]['Iki12Tip']=$kainynas['IKI_12_00_TIP'];
                    $insertK_arr[$Kainyndb]['OnOff']='ON';
                    

                    //!!!!!! DEBUG
                    //$this->var_dump($insertK_arr, "insertK_arr array");//-----------------DEBUG

                    // optional DATA:
                    $options = array (
                        'log_data' => array( // 'log' => true,
                            'log' =>  false
                        )
                    );


                    try {
                        $mysql = DBMySql::getInstance();
                        $retKTmp = $mysql->updateData($insertK_arr, $options);
                        // TIK TESTAVIMUI $newKUID=9999;

                        if(!$this->isSqlOK($retKTmp)){
                            $this->AddError('Įvyko duomenų bazės klaida!');
                            $yraKlaidu = 'TAIP';
                        }else{
                            //pasiimam UID
                            $newKUID=$retKTmp[0];//pasiimam UID
                        }


                        

                        //////////////////////////////////////////////////////////////////
                        // JEIGU GERAI, TAI RASOM KAINYNO ELEMENTYS

                        if($this->is_ID($newKUID)){

                            $svorisNUO = 0;
                            for ($i=0; $i < count($kainos); $i++) { 
                            
                                $kainEilute = $kainos[$i];

                                $KainynEldb=array();
                                $KainynEldb = "CERM_TranspEl";
                                for ($y=2; $y < count($kainEilute)+2; $y++) { 
                                    
                                        $kainEl = $kainEilute[$y];

                                        
                                        $insertKEl_arr[$KainynEldb]['TranspUID']=$newKUID;
                                        $insertKEl_arr[$KainynEldb]['PristatDienuK']=$kainEl['DIENOSK'];
                                        $insertKEl_arr[$KainynEldb]['PristatDienuKMAX']=$kainEl['DIENOSKMAX'];
                                        $insertKEl_arr[$KainynEldb]['DataIved']=date("Y:m:d H:i:s");
                                        $insertKEl_arr[$KainynEldb]['PastKodas']=$kainEl['KODAS'];
                                        $insertKEl_arr[$KainynEldb]['SvorisNuo']= $svorisNUO;
                                        $insertKEl_arr[$KainynEldb]['SvorisIki']=$kainEl['SVORIS'];
                                        $insertKEl_arr[$KainynEldb]['Kaina']=$kainEl['KAINA'];

                                        //!!!!!! DEBUG
                                        //$this->var_dump($insertKEl_arr, "insertKEl_arr array");//-----------------DEBUG


                                        // optional DATA:
                                        $options = array (
                                            'log_data' => array( // 'log' => true,
                                                'log' =>  false
                                            )
                                        );



                                        $mysql = DBMySql::getInstance();
                                        $retKElTmp = $mysql->updateData($insertKEl_arr, $options);


                                        if(!$this->isSqlOK($retKElTmp)){
                                            $this->AddError('Įvyko duomenų bazės klaida!');
                                            $yraKlaidu = 'TAIP';
                                        }else{
                                            //nieko nedarom
                                        }//end else

                                }//for Y

                                $svorisNUO =  $kainos[$i][2]['SVORIS']+0.01;  

                            }//end for X
                        }else{//end if
                            $this->addError('Klaida įrašant duomenis. Kainynas neišsaugotas.');
                            $yraKlaidu = 'TAIP';
                        }



                    } catch (Exception $ex) {
                        $this->AddError("Duomenų bazės klaida: ".(string)$ex);
                        $yraKlaidu = 'TAIP';
                        //echo"<br><br><br><hr>".(string)$ex."<hr>";
                    }


            }else{//end if irasom i DB
                $this->addError('Klaida. Nepavyko įkelti kainyno.');
                $yraKlaidu = 'TAIP';
            }

            if($yraKlaidu == 'NE'){
                $rezArray['OK'] = "OK";
            }else{
                $rezArray['OK'] = "NOTOK";
            }
            $rezArray['kainynoUID'] = $newKUID;
            return $rezArray;
    }//end function ;


private function ErrorCodeToMessage($code) 
    { 
        switch ($code) { 
            case UPLOAD_ERR_INI_SIZE: 
                $message = "The uploaded file exceeds the upload_max_filesize directive in php.ini"; 
                break; 
            case UPLOAD_ERR_FORM_SIZE: 
                $message = "The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form";
                break; 
            case UPLOAD_ERR_PARTIAL: 
                $message = "The uploaded file was only partially uploaded"; 
                break; 
            case UPLOAD_ERR_NO_FILE: 
                $message = "No file was uploaded"; 
                break; 
            case UPLOAD_ERR_NO_TMP_DIR: 
                $message = "Missing a temporary folder"; 
                break; 
            case UPLOAD_ERR_CANT_WRITE: 
                $message = "Failed to write file to disk"; 
                break; 
            case UPLOAD_ERR_EXTENSION: 
                $message = "File upload stopped by extension"; 
                break; 

            default: 
                $message = "Unknown upload error"; 
                break; 
        } 
        return $message; 
    } 


    public function getKainynaiList ($where="", $kiekIrasu="", $nuoIraso=""){


            //uzklausa
            $mysql = DBMySql::getInstance();
            $sql = "
                    select *
                    FROM CERM_Transp 
            ";

            if($where){
                $sql = $sql." ". $where;
            }

            if(is_int($kiekIrasu)){
                $sql = " LIMIT ". $kiekIrasu;
                if(is_int($nuoIraso)){
                    $sql = ", ". $nuoIraso;
                }//end if
            }//end if

            //!!!!!! DEBUG
            //$this->var_dump($sql, "sql <hr>$sql<hr> ");//-----------------DEBUG


            $KainynuArray = $mysql->querySql($sql,1);
            
            //!!!!!! DEBUG
            //$this->var_dump($DarbuotArray, "DarbuotArray <hr>$sql<hr> ");//-----------------DEBUG

            if(is_array($KainynuArray)){
                return $KainynuArray;
            }else{
                return null;
            }

            
    }//end function ;   


    public function getKainynasData ($kainynUID){

        if($this->is_ID($kainynUID)){
             //uzklausa
            $mysql = DBMySql::getInstance();
            $sql = "
                    select *
                    FROM CERM_Transp 
                    WHERE uid='".$kainynUID."'
            ";
            $KainynasData = $mysql->querySqlOneRow($sql,1);


            $mysql = DBMySql::getInstance();
            $sqlel = "
                    select *
                    FROM CERM_TranspEl 
                    WHERE TranspUID='".$kainynUID."'
                    ORDER BY SvorisNuo, SvorisIki 
            ";
            $KainynasElData = $mysql->querySql($sqlel,1);

            $rezArray['Header']=$KainynasData;
            $rezArray['ElementArray']=$KainynasElData;
            
            //!!!!!! DEBUG
            //$this->var_dump($KainynasElData, "KainynasElData <hr>$sql<hr> ");//-----------------DEBUG

            if(is_array($rezArray['Header'])){
                return $rezArray;
            }else{
                return null;
            }
        }else{//end if UID
            return null;
        }

            
    }//end function ;   



    public function delKainynas($delUID){

        if($this->is_ID($delUID)){

        /*
                $mysql = DBMySql::getInstance();
                 $sql = "
                        SELECT  K.KuratoriusID,
                        D.Vardas,
                        D.Pavarde
                        FROM FirmuKuratoriai K
                        INNER JOIN DarbuotojaiInfo D
                        ON K.KuratoriusID = D.DarbuotojasInfoID
                        WHERE K.FirmaID='".$FirmaPragmaID['uid']."'
                        ORDER BY D.Pavarde ASC
                ";
                //$AptarnaujanciuKeyArray = $mssql->querySql($sql);
                $AptarnaujanciuKeyArray = $mysql->querySql($sql, 1);
        */


                $mysql_db = DBMySql::getInstance();


                //trinam kainas (elementus)
                $delWHEREel = "TranspUID='".$delUID."'";
                
                DEBUG::log('***** DELETE [WHERE] as string ******');
                $table_nameEl = 'CERM_TranspEl';
                $deleteEl_where_arr = array(
                    $table_nameEl => $delWHEREel,
                );
                $options = array(
                    'log_data' => array( // 'log' => true,
                        'log' => false,
                        'document_id' => ''
                    )
                );
                $retEl = $mysql_db->deleteData($deleteEl_where_arr, $options);
                DEBUG::log($ret,'deleted.$ret');
                if($this->isSqlOK($retEl)){
                    $delElOK = "OK";
                }else{
                    $delElOK = "NOTOK";
                }




                //trinam kainas (elementus)
                $delWHERE = "uid='".$delUID."'";
                
                DEBUG::log('***** DELETE [WHERE] as string ******');
                $table_name = 'CERM_Transp';
                $delete_where_arr = array(
                    $table_name => $delWHERE,
                );
                $options = array(
                    'log_data' => array( // 'log' => true,
                        'log' => false,
                        'document_id' => ''
                    )
                );
                $ret = $mysql_db->deleteData($delete_where_arr, $options);
                DEBUG::log($ret,'deleted.$ret');
                if($this->isSqlOK($ret)){
                    $delOK = "OK";
                    $this->AddMessage('Kainynas ištrintas sėkmingai.');
                }else{
                    $delOK = "NOTOK";
                    $this->AddError('Duomenų bazės klaida. Nepavyko ištrinti kainyno.');
                }

        }else{
            $delOK = "NOTOK";
            $this->AddError("Klaida duomenų perdavime. Kainynas neištrintas.");
        }


        return $delOK;
    }//end function


///////////////////////////////////////////////////////////////////////////////////////////////////////////
// TRANSPORTO PAIESKOS FUNKCIJOS
///////////////////////////////////////////////////////////////////////////////////////////////////////

    public function getVezejaiArray (){

        $mysql = DBMySql::getInstance();
        $sql = "
                select Imone
                FROM CERM_Transp 
                GROUP BY Imone
                ORDER BY Imone ASC
        ";
        $BudasArray = $mysql->querySql($sql,1);

        return $BudasArray;
    }//end function


    public function getSalysArray (){

        $mysql = DBMySql::getInstance();
        $sql = "
                select Salis
                FROM CERM_Transp 
                GROUP BY Salis
                ORDER BY Salis ASC
        ";
        $SalysArray = $mysql->querySql($sql,1);

        return $SalysArray;
    }//end function


    public function getBudasArray (){

        $mysql = DBMySql::getInstance();
        $sql = "
                select Budas
                FROM CERM_Transp 
                GROUP BY Budas
                ORDER BY Budas ASC
        ";
        $BudasArray = $mysql->querySql($sql,1);

        return $BudasArray;
    }//end function

    public function getExImArray (){

        $mysql = DBMySql::getInstance();
        $sql = "
                select ExIm
                FROM CERM_Transp 
                GROUP BY ExIm
                ORDER BY ExIm ASC
        ";
        $BudasArray = $mysql->querySql($sql,1);

        return $BudasArray;
    }//end function


    public function searchTransport ($TSearch){

        $sOK = "OK";

        if(is_array($TSearch)){

            $where = " B.OnOff = 'ON' ";

            if($TSearch['sImpExp']=="IMP"){
                $where .= " AND (B.ExIm = 'IMP' OR B.ExIm = 'UNIV') ";
            }else if($TSearch['sImpExp']=="EXP"){
                $where .= " AND (B.ExIm = 'EXP' OR B.ExIm = 'UNIV') ";
            }else{
                 $sOK = "NOTOK";
                 $this->AddError ('Būtina nurodyti ar tai importas ar eksportas ');
            }
            

            //Salis
            if($TSearch['sSalis']){
                $where .= " AND B.Salis = '".$TSearch['sSalis']."' ";
            }else{//END IF
                 $sOK = "NOTOK";
                 $this->AddError ('Būtina pasirinkti šalį. ');
            }//end else

            //Svoris
            if($TSearch['sSvoris']){
                $where .= " AND (A.SvorisNuo <= '".$TSearch['sSvoris']."'  AND  A.SvorisIki >= '".$TSearch['sSvoris']."' ) ";
            }else{//END IF
                 $sOK = "NOTOK";
                 $this->AddError ('Būtina nurodyti svorį (arba nurodytas svoris ne skaičius). ');
            }//end else



            //Kodas
            if($TSearch['sPastoKod']){
                if(strlen($TSearch['sPastoKod'])>2){
                    $Kodas2 = substr ($TSearch['sPastoKod'],0,2);
                }else{
                    $Kodas2 = $TSearch['sPastoKod'];
                }
                $where .= " AND A.PastKodas = '".$Kodas2."'   ";
            }else{//END IF
                 $sOK = "NOTOK";
                 $this->AddError ('Būtina nurodyti Pašto kodą (bent pirmus 2 skaičius) ');
            }//end else


            //Budas
            if($TSearch['sBudas']){
                $where .= " AND B.Budas = '".$TSearch['sBudas']."' ";
            }


            //Max pristatymo dienu
            if(is_numeric($TSearch['sMaxDienu']) AND $TSearch['sMaxDienu']>0){
                $TSearch['sMaxDienu']=round($TSearch['sMaxDienu']);
                $where .= " AND A.PristatDienuKMAX <= '".$TSearch['sMaxDienu']."' ";
            }elseif(!$TSearch['sMaxDienu']){
                //nieko nedarom, nera papildomu salygu paieskai
            }else{
                 $sOK = "NOTOK";
                 $this->AddError ('Pristatymas dienomis turi būti nurodytas skaičius ');
            }


            if($TSearch['sNeutralus'] == "neutralus"){
                $where .= " AND B.NeutralusPristat > 0 ";
            }

            //Iki9 val
            if($TSearch['sIkiVal']==9){
                $where .= " AND B.Iki9 > 0 ";
            }

            //Iki10 val
            if($TSearch['sIkiVal']==10){
                $where .= " AND B.Iki10 > 0 ";
            }
            //Iki12 val
            if($TSearch['sIkiVal']==12){
                $where .= " AND B.Iki12 > 0 ";
            }


            if($sOK == "OK"){
                $mysql = DBMySql::getInstance();
                $sql = "
                        select A.TranspUID, A.SvorisNuo, A.SvorisIki, A.PastKodas, A.Kaina, A.PristatDienuK, A.PristatDienuKMAX, B.*
                        FROM CERM_TranspEl AS A
                        INNER JOIN CERM_Transp AS B ON A.TranspUID=B.uid
                        WHERE ".$where."
                ";

                //echo "<br><br><br><hr>$sql<hr>";
                $duomArray = $mysql->querySql($sql,1);


                //Skaiciuojam kaina
                if(count($duomArray)>0){
                    foreach ($duomArray as $key => $value) {


                        switch ($value['KuroMokestis']) {
                            case 'value':
                                # code...
                                break;
                            
                            default:
                                # code...
                                break;
                        }
                        //nunulinam
                        $paskaiciuotaKaina = $value['Kaina'];

                        

                        if(is_numeric($value['KuroMokestis'])){
                            if($value['KuroMokestisTip']=="KOEF"){
                                $paskaiciuotaKaina = $paskaiciuotaKaina + (($value['Kaina'] * $value['KuroMokestis'])-$value['Kaina']);
                                $duomArray[$key]['KuroMokestisEUR'] = round (($value['Kaina'] * $value['KuroMokestis']-$value['Kaina']), 2);
                            }elseif($value['KuroMokestisTip']=="EUR"){
                                $paskaiciuotaKaina = $paskaiciuotaKaina + $value['KuroMokestis'];
                                $duomArray[$key]['KuroMokestisEUR'] = round ($value['KuroMokestis'], 2);
                            }
                        }
                        
                        //echo "<br><br><BR>-------------<br>";
                        //var_dump($TSearch);
                        if(is_numeric($value['SaugosMokestis'])){
                            if($value['SaugosMokestisTip']=="KOEF"){
                                $paskaiciuotaKaina = $paskaiciuotaKaina + (($value['Kaina'] * $value['SaugosMokestis'])-$value['Kaina']);
                                $duomArray[$key]['SaugosMokestisEUR'] = round (($value['Kaina'] * $value['SaugosMokestis']-$value['Kaina']), 2);

                            }elseif($value['SaugosMokestisTip']=="EUR"){
                                $paskaiciuotaKaina = $paskaiciuotaKaina + $value['SaugosMokestis'];
                                $duomArray[$key]['SaugosMokestisEUR'] = round ($value['SaugosMokestis'], 2);
                            }elseif($value['SaugosMokestisTip']=="EURKG"){
//!!!!! prideti po saugos mokesti prie kiekvieno KG iki 200KG, toliau jau lieka stabilus pridedamas 200*saugos_mokestis
                                if($value['Imone']=='TNT'){
                                    if($TSearch['sSvoris']<=200){$tmpSvoris=$TSearch['sSvoris'];}else{$tmpSvoris=200;}
                                    $paskaiciuotaKaina = $paskaiciuotaKaina + ($tmpSvoris * $value['SaugosMokestis']);
                                    $duomArray[$key]['SaugosMokestisEUR'] = round ($value['SaugosMokestis']*$tmpSvoris, 2);
                                }else{
                                    $paskaiciuotaKaina = $paskaiciuotaKaina + ($TSearch['sSvoris'] * $value['SaugosMokestis']);
                                    $duomArray[$key]['SaugosMokestisEUR'] = round ($TSearch['sSvoris'] * $value['SaugosMokestis'], 2);
                                }
                            }
                        }

                        
                        if($TSearch['sNeutralus'] == "neutralus" AND is_numeric($value['NeutralusPristat'])){
                            if($value['NeutralusPristatTip']=="KOEF"){
                                $paskaiciuotaKaina = $paskaiciuotaKaina + (($value['Kaina'] * $value['NeutralusPristat'])-$value['Kaina']);
                                $duomArray[$key]['NeutralusPristatEUR'] = round (($value['Kaina'] * $value['NeutralusPristat']-$value['Kaina']), 2);

                            }elseif($value['NeutralusPristatTip']=="EUR"){
                                $paskaiciuotaKaina = $paskaiciuotaKaina + $value['NeutralusPristat'];
                                $duomArray[$key]['NeutralusPristatEUR'] = round ($value['NeutralusPristat'], 2);
                            }
                        }
                        
//!!!!!!!!!!!!!!!!!
                        //ATOKIU VIETU MOKESCIO KOL KAS NETAIKOM
                        /*
                        if(is_numeric($value['AtokiuVietuMok']) AND $taikytiMod=="TAIP"){
                            if($value['AtokiuVietuTip']=="KOEF"){
                                $paskaiciuotaKaina = $paskaiciuotaKaina + (($value['Kaina'] * $value['AtokiuVietuMok'])-$value['Kaina']);
                                $duomArray[$key]['AtokiuVietuMokEUR'] = round (($value['Kaina'] * $value['AtokiuVietuMok']-$value['Kaina']), 2);

                            }elseif($value['AtokiuVietuTip']=="EUR"){
                                $paskaiciuotaKaina = $paskaiciuotaKaina + $value['AtokiuVietuMok'];
                                $duomArray[$key]['AtokiuVietuMokEUR'] = round ($value['AtokiuVietuMok'], 2);
                            }
                        }
                        */
                        
                        //pritaikom importo mokescio antkaini kai yra importas ir kainynas universalus (ir importui ir exportui)
                        if($value['ExIm']=="UNIV" AND $TSearch['sImpExp']=="IMP"){
                            if(is_numeric($value['ImportoMok'])){
                                if($value['ImportoTip']=="KOEF"){
                                    $paskaiciuotaKaina = $paskaiciuotaKaina + (($value['Kaina'] * $value['ImportoMok'])-$value['Kaina']);
                                    $duomArray[$key]['ImportoMokEUR'] = round (($value['Kaina'] * $value['ImportoMok']-$value['Kaina']), 2);

                                }elseif($value['ImportoTip']=="EUR"){
                                    $paskaiciuotaKaina = $paskaiciuotaKaina + $value['ImportoMok'];
                                    $duomArray[$key]['ImportoMokEUR'] = round ($value['ImportoMok'], 2);
                                }
                            }
                        }


                        if(is_numeric($value['DaugiauNei1PakMok']) AND $TSearch['sDaug1Pak']=="DAUG1"){
                            if($value['DaugiauNei1PakTip']=="KOEF"){
                                $paskaiciuotaKaina = $paskaiciuotaKaina + (($value['Kaina'] * $value['DaugiauNei1PakMok'])-$value['Kaina']);
                                $duomArray[$key]['DaugiauNei1PakMokEUR'] = round (($value['Kaina'] * $value['DaugiauNei1PakMok']-$value['Kaina']), 2);

                            }elseif($value['DaugiauNei1PakTip']=="EUR"){
                                $paskaiciuotaKaina = $paskaiciuotaKaina + $value['DaugiauNei1PakMok'];
                                $duomArray[$key]['DaugiauNei1PakMokEUR'] = round ($value['DaugiauNei1PakMok'], 2);
                            }
                        }
                        

                        if(is_numeric($value['MuitinesTarpMok'])){
                            if($value['MuitinesTarpTip']=="KOEF"){
                                $paskaiciuotaKaina = $paskaiciuotaKaina + (($value['Kaina'] * $value['MuitinesTarpMok'])-$value['Kaina']);
                                $duomArray[$key]['MuitinesTarpMokEUR'] = round (($value['Kaina'] * $value['MuitinesTarpMok']-$value['Kaina']), 2);

                            }elseif($value['MuitinesTarpTip']=="EUR"){
                                $paskaiciuotaKaina = $paskaiciuotaKaina + $value['MuitinesTarpMok'];
                                $duomArray[$key]['MuitinesTarpMokEUR'] = round ($value['MuitinesTarpMok'], 2);
                            }
                        }
                        

                        if(is_numeric($value['Iki9']) AND  $TSearch['sIkiVal']=="9"){
                            if($value['Iki9Tip']=="KOEF"){
                                $paskaiciuotaKaina = $paskaiciuotaKaina + (($value['Kaina'] * $value['Iki9'])-$value['Kaina']);
                                $duomArray[$key]['Iki9EUR'] = round (($value['Kaina'] * $value['Iki9']-$value['Kaina']), 2);

                            }elseif($value['Iki9Tip']=="EUR"){
                                $paskaiciuotaKaina = $paskaiciuotaKaina + $value['Iki9'];
                                $duomArray[$key]['Iki9EUR'] = round ($value['Iki9'], 2);
                            }
                        }
                        

                        if(is_numeric($value['Iki10']) AND  $TSearch['sIkiVal']=="10"){
                            if($value['Iki10Tip']=="KOEF"){
                                $paskaiciuotaKaina = $paskaiciuotaKaina + (($value['Kaina'] * $value['Iki10'])-$value['Kaina']);
                                $duomArray[$key]['Iki10EUR'] = round (($value['Kaina'] * $value['Iki10']-$value['Kaina']), 2);

                            }elseif($value['Iki10Tip']=="EUR"){
                                $paskaiciuotaKaina = $paskaiciuotaKaina + $value['Iki10'];
                                $duomArray[$key]['Iki10EUR'] = round ($value['Iki10'], 2);
                            }
                        }
                        
                        
                        if(is_numeric($value['Iki12']) AND  $TSearch['sIkiVal']=="12"){
                            if($value['Iki12Tip']=="KOEF"){
                                $paskaiciuotaKaina = $paskaiciuotaKaina + (($value['Kaina'] * $value['Iki12'])-$value['Kaina']);
                                $duomArray[$key]['Iki12EUR'] = round (($value['Kaina'] * $value['Iki12']-$value['Kaina']), 2);

                            }elseif($value['Iki12Tip']=="EUR"){
                                $paskaiciuotaKaina = $paskaiciuotaKaina + $value['Iki12'];
                                $duomArray[$key]['Iki12EUR'] = round ($value['Iki12'], 2);
                            }
                        }

                        
                        $duomArray[$key]['KainaPask'] = round ($paskaiciuotaKaina, 2);
                        $duomArray[$key]['Kodas1'] = $TSearch['sPastoKod'];
                        $duomArray[$key]['Kodas2'] = $Kodas2;

                        if($paskaiciuotaKaina>9999){
                            unset($duomArray[$key]);
                        }
                    }//end foreach


                    //jeigu yra masyvas tai rusiuojam pagal kaina
                    if(is_array($duomArray) AND count($duomArray)>0){

                        usort($duomArray, function($a, $b)
                        {
                            if($a['KainaPask'] == $b['KainaPask']){
                                return 0 ; 
                            }elseif($a['KainaPask'] > $b['KainaPask']){
                                return 1 ; 
                            }else{
                                return -1 ; 
                            }
                            
                        });
                    }else{//end if is_array
                        $this->AddError ('Duomenų, atitinkančiu paieškos duomenis, nėra.');
                    }
                }else{
                    $this->AddError ('Duomenų, atitinkančiu paieškos duomenis, nėra.');
                }

            }else{

            }
        }else{//END IF
             $sOK = "NOTOK";
             $this->AddError ('Nenurodyti jokie paieškos parametrai.');
        }

        $rezArray['OK'] = $sOK;
        $rezArray['Duom'] = $duomArray;

        //!!!!!! DEBUG
        //$this->var_dump($rezArray, "rezArray -- rezArray<hr> $sql");//-----------------DEBUG


        return $rezArray;

    }//end function





 
}//end class
?>