<?php
//////////////////////////////////////////////////
//2016.05.06
// Duomenu apdorojimas kazkurio konkretaus kliento
/////////////////////////////////////////////////

error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING ^ E_DEPRECATED);
$root_path = COMMON::getRootFolder();
require_once ($root_path . "/modules/module.php");
//require_once ($root_path . "/DB/db_mssqlCERMTEST.php");
//require_once ($root_path . "../classes/PDF/vendor/autoload.php");





class CATpdf_mod extends module {
	
	//Vartotojo ID
	//public  $user_id = 0; // user ID
	//public static $sql ; // uzklausa

    public $zingsnis = 50; // kas kiek puslapiuoti

	function __construct($zingsnis = 50) {
		parent::__construct();

        $this->lipdukas['width'] = 148;
        $this->lipdukas['length'] = 104;

        $root_path = COMMON::getRootFolder();
        require_once ($root_path . "modules/skaiciuokleF1/skaiciuokleF1.mod.php");
        $this->skaiciuokleMod = new skaiciuokleF_mod();



	}//end function	








    public function sukurtiLipduka($uid, $barkodeHTML = "", $PDForMAIL = 'PDF')
    {


         echo "------------------<br>".$uid." <br> ".$barkodeHTML."<br>-------------<br>";
        $mssql = DBMSSqlCERM::getInstance();    

        $sql = "
            SELECT *
            FROM _TMS_Siuntos AS A
            LEFT JOIN _TMS_Pak AS P ON A.uid=P.SiuntaUID
            WHERE A.uid = '".$uid."' 
        ";

        $SiuntaDuomArray = $mssql->querySql($sql, 1);


        $siandien = date ("Y.m.d");

        
            $htmlCode='

            <!DOCTYPE html>
            <html class="client-nojs" lang="lt" dir="ltr">
            <head>
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
                <style>
                    body { 
                        font-family: DejaVu Sans, sans-serif, Verdana ; 
                        /* width: calc(108*2.83465)px; */
                        margin: 0px;
                        padding: 0px;
                    }
                   @page {
                       margin: 2mm;
                       width: calc(98*2.83465)px;
                   }                    
                    div.parent {
                        position: relative;
                        
                    }
            
                    #TablePDF {
                        border-collapse: collapse;
                        width: 100%; /* 148cm; */
                        padding: 0px;
                        margin: 0px;
                    }

                    #TablePDF td, #TablePDF th {
                        
                        padding: 2px;
                        padding-left: 10px;
                        font-size: 9px;
                        text-align: left;
                        background-color: #ecefee;
                    }
            
                    .hed1B{
                        font-family: sans-serif, Verdana ; 
                        font-size: 12px;
                        font-weight: bold;
                    }

                    .hed1{
                        font-family: sans-serif, Verdana ; 
                        font-size: 12px;
                        font-weight: normal;
                    }

                    .hed1B{
                        font-family: sans-serif, Verdana ; 
                        font-size: 12px; 
                        font-weight: bold;
                        
                    }

                    .hed1Big{
                        font-family: sans-serif, Verdana ; 
                        font-size: 14px;
                        font-weight: bold;
                    }

                    .hed2{
                        font-family: sans-serif, Verdana ; 
                        font-size: 10px;
                        font-weight: normal;
                    }

                    .hed3{
                        font-family: sans-serif, Verdana ; 
                        font-size: 30px;
                        font-weight: bold;
                    }

                    /*
                    #page {
                        width: 148cm;
                        height: 104cm;
                    }
                    */
                    div.absolute {
                        position: absolute;
                        width: 100%;
                        bottom: 10px;
                        
                    } 
                    
                </style>
                
                </head>
                <body>
                <div  id="page" class="parrent" style="border: 0px solid #000;">
                    <table class="TablePDF">
                        <tr>
                            <td style="width:15%;"><span class="hed1B">ORDER PARTY:</span></td>
                            <td style="width:55%;"><span class="hed1">AURIKA_LT</span></td>
                            <td style="width:20%;"><span class="hed1B">28/11/24 16:00</span></td>
                            <td style="width:10%;"></td>
                        </tr>
                        <tr>
                            <td style="width:15%;"><span class="hed1B">SENDER:</span></td>
                            <td style="width:55%;"><span class="hed1Big">AURIKA UAB</span><br><span class="hed1">CHAMIJOS G. 29F<br>LT-51333 KAINAS, KAUNO APSKRITIS kažkoks rajonas belekas dar</span></td>
                            <td style="width:20%;"><span class="hed3">PLKAT</span></td>
                            <td style="width:10%;"></td>
                        </tr>
                        <tr>
                            <td colspan="4" style="border-bottom: 1px solid #000;"></td>
                        </tr>
                        <tr>
                            <td colspan="2"><span class="hed1B">CONSIGNEE:</span><br><span class="hed1">INTERSNACK POLAND SP.Z.O.O.<br>UL. CENTRALNA 2</span><br><br><b><span class="hed1B">PL - 32-090 NIEDZWIEDZ</span></td>
                            <td colspan="2"><span class="hed3">KAT312</span></td>
                        </tr>
                        <tr>
                            <td colspan="4" style="border-bottom: 1px solid #000;"></td>
                        </tr>
                        <tr>
                            <td colspan="2"><span class="hed1B">Parcel Nr: LT000939312</span>
                            <td colspan="2"><span class="hed1B">Order Nr COLT0786384</span></td>
                        </tr>
                        <tr>
                            <td colspan="2"><span class="hed2">Description:</span></td>
                            <td colspan="2"><span class="hed2">Cust. Ref 582456375</span></td>
                        </tr>
                        <tr>
                            <td colspan="2"><span class="hed2">CO</span></td>
                            <td colspan="2"><span class="hed2">Weight 435.833 Kg</span></td>
                        </tr>
                        <tr>
                            <!-- <td colspan="4" style="text-align: center;"><span class="hed2"><img src="../../uploads/tvsLabel/barcode/test.png" /></span></td> -->
                            <td colspan="4" style="text-align: center;">
            ';
            if ($barkodeHTML){
               $htmlCode.="<div style='width: auto; padding:0px; padding-left:90px; margin: 0px; border: 0px solid #000;'>".$barkodeHTML."</div><span class='hed2' style='padding:0px; margin:0px;'>-".$uid."-</span>";
            }else{
               $htmlCode.='<img src="https://ngmod.aurika.lt/uploads/tvsLabel/barcode/test.png" / style="width:225px; heught:90px;">';
            }
            $htmlCode.='
                              
                        </td>
                        </tr>
                    </table>
                </div>
            </body>
            </html>
            
        ';

        //print ($htmlCode);
        return $htmlCode;    
    }



}//end class
?>
