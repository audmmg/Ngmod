<?php
 error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
 ini_set("display_errors", 1);

$root_path = COMMON::getRootFolder();
require_once ($root_path . "modules/module.php");

class fileUpld_mod extends module {

    function __construct() {
        parent::__construct();

    }//end function 
    


    public function upload($subDir, $SiuntaID, $uplType, $kam=''){
        /*
        $type=0;
        if(!empty($_POST['type'])){$type=$_POST['type'];}
        
        if($type==0)$folder="auditas";
        if($type==1 || $type==2)$folder="pretenzija";
        if($type==3)$folder="tiekejas";
        if($type==4)$folder="vizitas";
                
        
        if(!empty($_POST['updatenr'])){
            $nr=$folder.$_POST['updatenr'];
        }
        */

        if(!$kam){
            $kam='NaN';
        }//end if
        
        $ds          = "/";  //1
         
        $storeFolder = 'uploads';   //2
        
        if (!empty($_FILES) AND $SiuntaID) {
             
            $tempFile = $_FILES['file']['tmp_name'];          //3   
            
            if (!file_exists(COMMON::getRootFolder() . $ds. $storeFolder . $ds . $subDir)) {
                mkdir(COMMON::getRootFolder() . $ds. $storeFolder . $ds . $subDir, 0777, true);
            }    
            
            $targetPath = COMMON::getRootFolder() . $ds. $storeFolder . $ds . $subDir .$ds;  //4
            $targetPath1 = $ds. $storeFolder . $ds . $subDir .$ds;  //4
             
            $origFile = $_FILES['file']['name'];
            $ext = end((explode(".", $origFile)));

            if($subDir=='tvsLabel'){
                $rezFile = 'lam'. microtime(true)*10000 .".".$ext;
            }else if ($subDir=='tvsVazt'){
                $rezFile = 'vzt'. microtime(true)*10000 .".".$ext;
            }else{
                $rezFile = 'doc'. microtime(true)*10000 .".".$ext;
            }
            $targetFile =  $targetPath. $rezFile;  //5
         

            if(move_uploaded_file($tempFile,$targetFile)){
                        try {
                            /*
                            //Insert multiple rows:
                            //veikiantis variantas, tik disablinam, nes rasysim i siuntu lentele
                            $table_name="Uploaded";
                            $insert_arr = array();
                            $insert_arr[$table_name]['kasIkeleUID']=SESSION::getUserID();
                            $insert_arr[$table_name]['kamPriklausoUID']=$SiuntaID;
                            $insert_arr[$table_name]['kamPriklausoName']=$kam;
                            $insert_arr[$table_name]['ikeltasData']=date("Y-m-d H:i:s");
                            $insert_arr[$table_name]['dir']=addslashes($targetPath1);
                            $insert_arr[$table_name]['dabarFileName']=$rezFile;
                            $insert_arr[$table_name]['dabarFailasExt']=strtoupper($ext);
                            $insert_arr[$table_name]['ikeleFileName']=$origFile;
                            $insert_arr[$table_name]['busena']='ikeltas';
                            $insert_arr[$table_name]['Comment']='';
                            $insert_arr[$table_name]['onoff']='on';

                            // optional DATA:
                            $options = array (
                                'log_data' => array( // 'log' => true,
                                    'document_id' =>  'IT_HD_reg'
                                )
                            );
                            //!!!!!! DEBUG
                            //$this->var_dump($insert_arr, "insert_arr duom-$masina-$Date-<hr>$sql");//-----------------DEBUG

                            $mysql = DBMySql::getInstance();
                            $FileUID = $mysql->updateData($insert_arr, $options);

                            //tikrinam ar pasiseke
                            if($this->isSqlOK ($FileUID)){
                                $rezOK = 'OK';
                            }else{
                                $this->AddError('[1683]  Duomenų bazės klaida!');
                                $rezOK = 'Error';
                            }
                            
                            */


                            $wmssql = DBMSSqlCERM::getInstance();
                            if($subDir=='tvsLabel'){
                                $wsql = 'UPDATE TOP (1) _TMS_Siuntos SET
                                    LabelLink           =   \''.$rezFile.'\'
                                    WHERE  uid=\''.$SiuntaID.'\' ;
                                ';            
                                $retSQL = $wmssql->execSql($wsql, 1);
                                $rezOK = 'OK';
                                
                            }else if ($subDir=='tvsVazt'){
                                $wsql = 'UPDATE TOP (1) _TMS_Siuntos SET
                                    VaztLink           =   \''.$rezFile.'\'
                                    WHERE  uid=\''.$SiuntaID.'\' ;
                                ';            
                                $retSQL = $wmssql->execSql($wsql, 1);
                                $rezOK = 'OK';

                            }else{
                                //nerasom niekur kolkas

                                $rezOK = 'NOTOK';
                            }

                            //echo "<hr>$wsql<hr>";


                        } catch (Exception $ex) {
                            $this->AddError("errorUploading " + (string)$ex);
                            $ret = null;
                            $rezOK = 'Error';
                        }
                            
            }else{//end if
                $rezOK = 'Error';
                $this->AddError("errorMoving file ");
            }
        }else{//end if files
            $rezOK = 'Error';
            $this->AddError("error NO file ");
        }//end else

        $actionMessage = $this->getErrorArrayAsStr();
        $rez['error']=$rezOK;
        $rez['responseText']=$actionMessage;
        $rez['Dir']=$targetPath;
        $rez['File']=$rezFile;
        $rez['FileUID']=$FileUID[0];

        return $rez;       
    }//end function
    



    //priregistruoja uploadintus failus prie kazko
    public function regUploadetFile ($uFileUID, $kamPriklausoUID, $kamPriklausoName){

        if($this->is_ID($uFileUID) AND $this->is_ID($kamPriklausoUID)){

                        try {
                            //Insert multiple rows:
                            $table_name="Uploaded";


                            $insert_arr = array();
                            $insert_arr[$table_name]['uid']=$uFileUID;
                            $insert_arr[$table_name]['kamPriklausoUID']=$kamPriklausoUID;
                            $insert_arr[$table_name]['kamPriklausoName']=$kamPriklausoName;

                            // optional DATA:
                            $options = array (
                                'log_data' => array( // 'log' => true,
                                    'document_id' =>  'Uploaded'
                                )
                            );
                            
                            //!!!!!! DEBUG
                            //$this->var_dump($insert_arr, "insert_arr duom-$masina-$Date-<hr>$sql");//-----------------DEBUG

                            $mysql = DBMySql::getInstance();
                            $FileUID = $mysql->updateData($insert_arr, $options);

                            //tikrinam ar pasiseke
                            if($this->isSqlOK ($FileUID)){
                                $rezOK = 'OK';
                            }else{
                                $this->AddError('[1683]  Duomenų bazės klaida!');
                                $rezOK = 'ErrorDB';
                            }//end else

                        } catch (Exception $ex) {
                            $this->AddError((string)$ex);
                            $FileUID = null;
                            $rezOK = 'Error Exception';
                        }



        }else{//end if
            $this->AddError('[1143]  Neteisingi pateikti duomenys!');
            $rezOK = 'Error1';
        }


        return $rezOK;
    }//end function
    
    //------------------------------------
}//end class1
?>