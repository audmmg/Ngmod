<?php
error_reporting(E_ALL ^ E_NOTICE);
require_once dirname(__FILE__) . '/../../DB/db_mssqlCERM.php';
require_once dirname(__FILE__) . '/../../DB/db_mssqlCERMTEST.php';
require_once dirname(__FILE__) . '/../../DB/db_mssqlNAV.php';
//////////////////////////////////////////////////
//2014.10.15
// Perdaromu FPK modulis
/////////////////////////////////////////////////

// testuojam cat 2025-01-23 - PS 441884 SO 407190 (buvo realiai issiustas 2022-03-17 siuntos Nr49140)
// testuojam CAt 2025-03-12 - PS 518505 SO 484986 (buvo realiai issiusta 2024-03-28 siuntos NR 100712)

$root_path = COMMON::getRootFolder();
require_once ($root_path . "modules/module.php");
require_once ($root_path . '/classes/TVSconfig.php');

//require_once ($root_path . "modules/db_mysql.php");

/* TESTAVIMUI
B.off__ref = '148672' - 5sluoksne
B.off__ref = '189050' - 4sluoksnis su laku
B.off__ref = '209748' - 3sluoksniai su laku
B.off__ref = '190762' - 2sluoksniai su laku
B.off__ref = '114374' - 1sluoksniai su laku
*/
class tvs_mod extends module {


    //public $KPGProductTypeIDArray = array ('100001', '100002','100004','100005','100006','100007','100008','100009','100010','100011','100012','100013','100014','100015','300267','300268','300269','300270','300271','300272','300274','300275','300276','300277','300278','300279','300280','300281','300282','300283','300284','300285','300286','300287','300288','300289','300290','300291','300292');

    function __construct() {
        parent::__construct();

    }//end function 





/*20190905 A. Ramonas
Isveda lista pagal paieskos parametrus (sandelui)
Sarasas SalesOrderiu pakavimui (skirta sandeliui)
*/
public function getOrderList($SearchDuom){
    $OrderList = array();

    $qry = "
        SELECT TOP 1000 
            A.lyn__ref,
            A.lbn__ref AS PackingSlip,
            A.vrz__tst AS Shipped, /* 0-NotApplicable; 1-Not yet ready tro ship, N-ToDoo, Y-Done, Z-Returned */
            A.lev__tst AS DeliveryStatus, /* N-Not delivered */
            A.fac__tst AS InvoiceStatus, /* 0- Not yet invoiced; N- To invoice; W- In process, Y - Invoiced */
            A.levb_dat AS DateForPackingSlip,
            A.lvb__lay AS PackingSlipLayout,
            A.bst__ref, 
            A.afg__ref,
            A.ord__ref,
            C.naam____ AS ClientName,

            CASE
                WHEN A.tstval03='1000' THEN 'KEG'
                WHEN A.tstval03='2000' THEN 'KPG'
                WHEN A.tstval03='3000' THEN 'ETK1'
                ELSE 'Unknown'
            END AS 'ShippedFrom',

            CASE
                WHEN A.tstval04='500' THEN 'Not printed'
                WHEN A.tstval04='1000' THEN 'Printed'
                ELSE 'Unknown'
            END AS 'PickingSlipPrinted',

            CASE
                WHEN A.tstval06='500' THEN 'Not printed'
                WHEN A.tstval06='1000' THEN 'Printed'
                ELSE 'Unknown'
            END AS 'DeliveryNotePrinted',

            CASE
                WHEN A.trn__srt='1'
                THEN C.naam____
                ELSE L.lev_loc1 
            END AS 'Delivery_Company',

            A.lev__ref as TransporterID,
            A.lev__rpn AS TransporterKeyword,
            left(convert(char,A.vrzv_dat,120),10) AS 'Expected_Shipment_Date',
            left(convert(char,A.levv_dat,120),10) AS 'Expected_Delivery_Date',
            left(convert(char,A.vrz__dat,120),10) AS 'Real_Shipped_Date',
            A.b_netto_ AS 'NETTO_estimated',
            A.koloma11 AS 'NETTO_picked',
            A.aant_pak AS 'Packs_picked',
            A.aant_pal AS 'Pallets_picked',
            A.lbn__com AS 'Packing_slip_comment',
            A.lev__com AS 'ShipmentComment',
            A.levtrcom AS 'CommentAfterDelivery',
            A.trn__srt AS 'Delivery_type',  /* 0 - pristatoma į AURIKA sandėlį, 1 - pristatoma kliento pagrindiniu adresu,  2,3,4 - pristatoma kliento adresu */
            A.lok__ref AS 'Delivery_AddressID',
            CASE
                WHEN A.trn__srt='1'
                THEN C.land_ref
                ELSE L.land_ref  
            END AS 'Delivery_country_code',
            CASE
                WHEN A.trn__srt='1'
                THEN C.post_ref
                ELSE L.post_ref  
            END AS 'Delivery_post',
            CASE
                WHEN A.trn__srt='1'
                THEN C.postnaam
                ELSE L.postnaam  
            END AS 'Delivery_city',

            CASE
                WHEN A.trn__srt='1'
                THEN C.dienst__
                ELSE L.lev_loc2 
            END AS 'Delivery_department',

            CASE
                WHEN A.trn__srt='1'
                THEN C.straat__
                ELSE L.lev_loc3 
            END AS 'Delivery_street',

            CASE
                WHEN A.trn__srt='1'
                THEN C.county__
                ELSE L.county__ 
            END AS 'Delivery_County',
            CASE
                WHEN A.trn__srt='1'
                THEN C.wijk____
                ELSE L.wijk____
            END AS 'Delivery_District',

            CASE
                WHEN A.trn__srt='1'
                THEN C.telex___
                ELSE L.email___ 
            END AS 'Delivery_email',
            CASE
                WHEN A.trn__srt='1'
                THEN C.telefoon
                ELSE L.telefoon 
            END AS 'Delivery_phone',
            CASE
                WHEN A.trn__srt='1'
                THEN (O.knp__vnm + ' ' + O.knp__nam)
                ELSE (K.knp__vnm + ' ' + K.knp__nam) 
            END AS 'Delivery_contact',
            CASE
                WHEN A.trn__srt='1'
                THEN O.email___
                ELSE K.email___ 
            END AS 'Delivery_contact_email',
            CASE
                WHEN A.trn__srt='1'
                THEN O.tel_auto
                ELSE K.tel_auto 
            END AS 'Delivery_contact_phone' ,

            CASE
                WHEN A.trn__srt='4'
                THEN (O.knp__vnm + ' ' + O.knp__nam)
                ELSE ('') 
            END AS 'Pastomat_Delivery_contact',
            CASE
                WHEN A.trn__srt='4'
                THEN O.email___
                ELSE '' 
            END AS 'Pastomat_Delivery_contact_email',
            CASE
                WHEN A.trn__srt='4'
                THEN O.tel_auto
                ELSE '' 
            END AS 'Pastomat_Delivery_contact_phone' ,                              

            L.handelnr AS ClientCompanyCode,

            
            A.lyn__ref AS lyyn_ref, 
            
            A.uit__lay AS Picking, 
            A.lbn__ref AS PackingSlipFinal, 
            A.l_aantal AS InStock,
            A.l_antpak AS PikedQuontityPacks,
            A.l_antpal AS PikedQuontityPallets,
            A.b_aantal AS OrderetQuantity,
            A.b_antpak AS OrderedQuontityPacks,
            A.b_antpal AS OrderedQuontityPallets,
            A.levb_dat AS PackingSlipDate,
            A.lvb___ex AS NoOfPicPackingSlip,
            A.lvb__lay AS LayoutPackingSlip,
            A.lvb__ref AS PackingSlipComposedID,
            '----' AS delimeter,
            A.levv_dat,
            A.levvwref,
            A.leverkod,
            A.levb_dat,
            A.levtrcom,
            A.levvodat,

            /* PRODUCT DATE */
            P.afg_oms1 AS ProductName,
            P.kla__ref AS ProdClientID,
            P.kla__rpn AS ProdClientKey,
            P.commkern AS ProdComment,

            /* SIUNTU REGISTRAS */
            
            S.uid AS PakSiuntosNr,
            S.Created AS PakSiuntaSukurta,
            S.Pakuotes AS PakPakuotesStr,
            S.SvorisSum AS PakSvorisSum,

            S.KrovinysReg AS KrovinysReg,
            S.SiuntaUzregistruota AS PakSvorisSumUzreg,

            S.KurjerisReg AS KurjerisReg,
            S.VezejasUzsakyta AS KurjerisUzsakyta,
            S.KurjOrderNr AS KurjOrderNr,
            
            S.VezejasReal AS VezejasReal,
            S.AutoPatikra,
            S.AutoPatikraDate,
            S.AutoPatikraDarbuotojas,

            /* STATUSAI */
            A.fac__tst AS ToByInvoiced,
            A.dok__dat AS ToByInvoicedDate,

            (A.koloma11 + A.l_tarra_) AS GrossWeightOrdered,

            
            E.tekst_31 AS Express,
            E.prod_tyd AS Prit_10_12,

            S.Express AS SiuntExpress,
            S.Pristat1012 AS SiuntPrit_10_12,

            /*
            CASE
                WHEN S.uid>'0'
                THEN S.Express
                ELSE E.tekst_31 
            END AS 'Express' ,
            */
          
          '----' AS EndQry
            /*, A.**/
        FROM bstlyn__ AS A
        LEFT JOIN klabas__ AS C ON A.kla__ref = C.kla__ref
        LEFT JOIN levlok__ AS L ON A.lok__ref=L.lok__ref
        LEFT JOIN afgart__ AS P ON A.afg__ref=P.afg__ref
        LEFT JOIN konper__ AS K ON A.lok__ref=K.lok__ref AND L.lvknpref=K.knp__ref
        LEFT JOIN konpkl__ AS O ON A.kla__ref=O.kla__ref AND A.knp__ref=O.knp__ref
        LEFT JOIN _TMS_Keys AS TK ON A.lbn__ref=TK.PackSlipID AND TK.deleted <> 1
        LEFT JOIN _TMS_Siuntos AS S ON TK.SiuntaUID=S.uid AND S.deleted <> 1
        LEFT JOIN bstext__ AS E ON A.lyn__ref=E.lyn__ref


    ";

    /*

        WHERE 
          -- A.lbn__ref IS NOT NULL AND A.lbn__ref <> ''
          -- A.bst__ref = '274276'
          --A.bst__ref = '276974'
          -- OR A.bst__ref = '275157'
        ORDER BY A.lyn__ref DESC    
    */    



    $WHERE = "WHERE A.lbn__ref IS NOT NULL AND A.lbn__ref <>'' ";

    $yraTikslus = "N";//jeigu irasyta samataID/CalculationID/NewGamID, tai ignoruoja kai kuriuos kitus filtrus, tokius kaip data
    if($SearchDuom){

        //ShipedFrom
        if($SearchDuom['sSandelys']){
            switch ($SearchDuom['sSandelys']) {
                case 'KEG':
                    $WHERE .= " AND A.tstval03 = '1000' " ;
                    break;
                case 'KPG':
                    $WHERE .= " AND A.tstval03 = '2000' " ;
                    break;
                case 'ETK1':
                    $WHERE .= " AND A.tstval03 = '3000' " ;
                    break;
                case 'ETK':
                    $WHERE .= " AND A.tstval03 = '99999' " ;// 99999-tai bet koks skaicius, kad CERMe jo nebutu, nes siuo atveju is CERM neturi ateiti jokia info, ETK sandeliui info ateina is Navisiono
                    break;
                case 'Unknown':
                    $WHERE .= " AND ( A.tstval03 <> '1000'  AND A.tstval03 <> '2000'  AND A.tstval03 <> '3000') " ;
                    break;
                
                default:
                    # code...
                    break;
            }
            
        }//end if


        
        //PackingSlip
        if($SearchDuom['sSiuntaID']){
            $WHERE .= " AND S.uid = '".$SearchDuom['sSiuntaID']."' " ;
            $yraTikslus = "Y";
        }//end if


        //InvoiceStatus
        /*0- Not yet invoiced; N- To invoice; W- In process, Y - Invoiced */
        $StatArray = array('0', 'N', 'W', 'Y');
        if(in_array($SearchDuom['sInvStat'], $StatArray) ){
            $WHERE .= " AND A.fac__tst = '".$SearchDuom['sInvStat']."' " ;
        }//end if



        //PackingSlip
        if($SearchDuom['sPackingSlip']){
            $WHERE .= " AND A.lbn__ref = '".$SearchDuom['sPackingSlip']."' " ;
            $yraTikslus = "Y";
        }//end if


        //sOrderID 
        if($SearchDuom['sOrderID']){
            $WHERE .= " AND A.bst__ref = '".$SearchDuom['sOrderID']."' " ;
            $yraTikslus = "Y";
        }//end if


        //sOrderID 
        if($SearchDuom['sGamID']){
            $WHERE .= " AND A.sfg__ref = '".$SearchDuom['sGamID']."' " ;
            $yraTikslus = "Y";
        }//end if


        if ($yraTikslus == "N"){

            //echo "<br><br><br>".$SearchDuom['sSiuntosBus']."<hr>";
            //ar registruota, neregistruota, issiusta
            if($SearchDuom['sSiuntosBus']=='SiuntOut'){//uzregistruota TVSe ir issiusta (zalia)
                $WHERE .= " AND S.KrovinysReg = 'Y ' " ;
                //$yraTikslus = "Y";
            }else if ($SearchDuom['sSiuntosBus']=='SiuntReg'){////tik uzregistruota TVSe
                $WHERE .= " AND (S.uid > 0  AND (S.KrovinysReg  IS NULL OR S.KrovinysReg=''))" ;
            }else if ($SearchDuom['sSiuntosBus']=='SiuntNeReg'){//tik neuzregistruotos TVSe
                $WHERE .= " AND (S.uid IS NULL OR S.uid='') " ;
            }else{
                //visos siuntos, nieko nedarom
            }


            if ($SearchDuom['sDatNuo'] AND $SearchDuom['sDatIki'] ){
                $WHERE .= " AND ( A.vrzv_dat >= '".$SearchDuom['sDatNuo']."' AND  A.vrzv_dat <= '".$SearchDuom['sDatIki']."') " ;
            }else{
                $SearchDuom['sDatNuo'] = date("Y-m-d 00:00");//siandien pradzia
                $SearchDuom['sDatIki'] = date("Y-m-d 23:59");//siandien pabaiga
                $WHERE .= " AND ( A.vrzv_dat >= '".$SearchDuom['sDatNuo']."' AND  A.vrzv_dat <= '".$SearchDuom['sDatIki']."') " ;
            }
        }

        //sOrderID 
        /* 20211006 pakeista i zemiau esancia
        S.VezejasReal
        if($SearchDuom['sVezejas']){
            switch ($SearchDuom['sVezejas']) {
                case 'VENIPAK':
                    $WHERE .= " AND (A.lev__rpn = 'VENIPAK' OR A.lev__rpn = 'VENIPAK TR') " ;
                    break;
                case 'SCHENKER':
                    $WHERE .= " AND (A.lev__rpn = 'SCHENKER' OR A.lev__rpn = 'SCHENKER TR') " ;
                    break;
                case 'UPS':
                    $WHERE .= " AND (A.lev__rpn = 'UPS' OR A.lev__rpn = 'UPS TR') " ;
                    break;
                case 'KLIENTO TR':
                    $WHERE .= " AND (A.lev__rpn = 'KLIENTO TR' OR A.lev__rpn = 'KLIENTO') " ;
                    break;
                case 'AURIKA':
                    $WHERE .= " AND (A.lev__rpn = 'AURIKA' OR A.lev__rpn = 'AURIKA TR') " ;
                    break;
                case 'KITA':
                    $WHERE .= " AND A.lev__rpn NOT IN ('VENIPAK', 'VENIPAK TR', 'KLIENTO TR', 'KLIENTO', 'AURIKA', 'AURIKA TR') " ;
                    break;
                
                default:
                    # code...
                    break;
            }
            // $WHERE .= " AND A.lev__rpn LIKE '%".$SearchDuom['sVezejas']."%' " ;
        }//end if
        */

        
        if($SearchDuom['sVezejas']){
            switch ($SearchDuom['sVezejas']) {
                case 'VENIPAK':
                    $WHERE .= " AND (S.VezejasReal = 'VENIPAK' OR ((S.VezejasReal = '' OR  S.VezejasReal IS NULL) AND (A.lev__rpn = 'VENIPAK' OR A.lev__rpn = 'VENIPAK TR'))) " ;
                    break;
                case 'SCHENKER':
                    $WHERE .= " AND (S.VezejasReal = 'SCHENKER' OR ((S.VezejasReal = '' OR  S.VezejasReal IS NULL) AND (A.lev__rpn = 'SCHENKER' OR A.lev__rpn = 'SCHENKER TR'))) " ;
                    break;
                case 'UPS':
                    $WHERE .= " AND (S.VezejasReal = 'UPS' OR ((S.VezejasReal = '' OR  S.VezejasReal IS NULL) AND (A.lev__rpn = 'UPS' OR A.lev__rpn = 'UPS TR'))) " ;
                    break;
                case 'ACE':
                    $WHERE .= " AND (S.VezejasReal = 'ACE' OR ((S.VezejasReal = '' OR  S.VezejasReal IS NULL) AND (A.lev__rpn = 'ACE' OR A.lev__rpn = 'ACE TR'))) " ;
                    break;
                case 'DHL':
                    $WHERE .= " AND (S.VezejasReal = 'DHL' OR ((S.VezejasReal = '' OR  S.VezejasReal IS NULL) AND (A.lev__rpn = 'DHL' OR A.lev__rpn = 'DHL TR'))) " ;
                    break;
                case 'CAT':
                    $WHERE .= " AND (S.VezejasReal = 'CAT' OR ((S.VezejasReal = '' OR  S.VezejasReal IS NULL) AND (A.lev__rpn = 'CAT' OR A.lev__rpn = 'CAT TR'))) " ;
                    break;
                case 'Continexus':
                    $WHERE .= " AND (S.VezejasReal = 'Continexus' OR ((S.VezejasReal = '' OR  S.VezejasReal IS NULL) AND (A.lev__rpn = 'Continexus' OR A.lev__rpn = 'Continexus TR'))) " ;
                    break;
                case 'DSV':
                    $WHERE .= " AND (S.VezejasReal = 'DSV' OR ((S.VezejasReal = '' OR  S.VezejasReal IS NULL) AND (A.lev__rpn = 'DSV' OR A.lev__rpn = 'DSV TR'))) " ;
                    break;
                case 'KLIENTO TR':
                    $WHERE .= " AND (A.lev__rpn = 'KLIENTO TR' OR A.lev__rpn = 'KLIENTO') " ;
                    break;
                case 'AURIKA':
                    $WHERE .= " AND (A.lev__rpn = 'AURIKA' OR A.lev__rpn = 'AURIKA TR') " ;
                    break;
                case 'KITA':
                    $WHERE .= " AND A.lev__rpn NOT IN ('VENIPAK', 'VENIPAK TR', 'KLIENTO TR', 'KLIENTO', 'AURIKA', 'AURIKA TR', 'SCHENKER', 'UPS', 'ACE', 'DHL', 'CAT', 'Continexus', 'DSV') ";
                    //$WHERE .= " AND S.VezejasReal NOT IN ('VENIPAK', 'VENIPAK TR', 'KLIENTO TR', 'KLIENTO', 'AURIKA', 'AURIKA TR', 'SCHENKER', 'UPS', 'ACE', 'DHL', 'CAT', 'Continexus', 'DSV') ";
                    break;
                
                default:
                    # code...
                    break;
            }
            // $WHERE .= " AND A.lev__rpn LIKE '%".$SearchDuom['sVezejas']."%' " ;
        }//end if

        if($SearchDuom['sKlientas']){
            $WHERE .= " AND C.naam____ LIKE '%".$SearchDuom['sKlientas']."%' " ;
        }//end if


        if($SearchDuom['sSaliesKodas']){
            $WHERE .= " AND '".$SearchDuom['sSaliesKodas']."' = CASE
                                                                    WHEN A.trn__srt='1' THEN C.land_ref
                                                                    ELSE L.land_ref  
                                                                END 

            " ;
        }//end if



    }//end if SearchDuom

    

    $qry .= $WHERE;

//echo "<br><br><br><hr>$qry</hr>";

    // PERFORMUOJAM QRY jeigu reikia dar ieskoti ir pagal adresa, nes is ankstesnes negalime padaryti paieskos
    if($SearchDuom['sAdresas']){
        
        $qryWithAdressSearch = "
            SELECT * 
            FROM (".$qry.") AS X
            WHERE 
                X.Delivery_post LIKE '%".$SearchDuom['sAdresas']."%' 
                OR 
                X.Delivery_city LIKE '%".$SearchDuom['sAdresas']."%' 
                OR 
                X.Delivery_department LIKE '%".$SearchDuom['sAdresas']."%' 
                OR 
                X.Delivery_street LIKE '%".$SearchDuom['sAdresas']."%' 
                OR 
                X.Delivery_County LIKE '%".$SearchDuom['sAdresas']."%' 
                OR 
                X.Delivery_District LIKE '%".$SearchDuom['sAdresas']."%' 
        ";
        
/*
        $qryWithAdressSearch = "
            SELECT X.* 
            FROM (".$qry.") AS X
        ";
*/

        $qry =  $qryWithAdressSearch;

        $ORDER = ' ORDER BY X.PackingSlip DESC'; 
    }else{//end if
        $ORDER = ' ORDER BY A.lbn__ref DESC'; 
    }

    
    $qry .= $ORDER; /* " ORDER  BY  A.NewGamUID DESC"; */




    //Nuskaitom Orderius
    if($SearchDuom['sSandelys']!='ETK'){ // neimam info is CERM jeigu sandelys yra ETK, nes tada info ateina tik is Navisiono
        $mssql = DBMSSqlCERM::getInstance();
        $OrderListTemp = $mssql->querySql($qry, 1);
    }
    

    //echo "<br><br><br><hr>$qry<hr>";
    //!!!!!! DEBUG
    //$this->var_dump($OrderListTemp, "OrderListTemp <hr>$qry<hr> ");//-----------------DEBUG



    $CBVal = $SearchDuom['CB'];
    $CB=array();
    if($CBVal){
        foreach ($CBVal as $keyCB => $valueCB) {
            $CB[]=$keyCB;
        }
    }

    /* tvarkom struktura */
    $OrderList = array();
    if($OrderListTemp){
        foreach ($OrderListTemp as $key => $OrdDate) {
            $OrderList[$OrdDate['PackingSlip']]['PackingSlip']=$OrdDate['PackingSlip'];
            $OrderList[$OrdDate['PackingSlip']]['Expected_Shipment_Date']=$OrdDate['Expected_Shipment_Date'];
            $OrderList[$OrdDate['PackingSlip']]['Expected_Delivery_Date']=$OrdDate['Expected_Delivery_Date'];
            $OrderList[$OrdDate['PackingSlip']]['Real_Shipped_Date']=$OrdDate['Real_Shipped_Date'];

            $OrderList[$OrdDate['PackingSlip']]['DeliveryStatus']=$OrdDate['DeliveryStatus'];
            $OrderList[$OrdDate['PackingSlip']]['InvoiceStatus']=$OrdDate['InvoiceStatus'];
            $OrderList[$OrdDate['PackingSlip']]['bst__ref']=$OrdDate['bst__ref'];
            $OrderList[$OrdDate['PackingSlip']]['ClientName']=$OrdDate['ClientName'];
            $OrderList[$OrdDate['PackingSlip']]['ShippedFrom']=$OrdDate['ShippedFrom'];
            $OrderList[$OrdDate['PackingSlip']]['Delivery_Company']=$OrdDate['Delivery_Company'];
            $OrderList[$OrdDate['PackingSlip']]['TransporterID']=$OrdDate['TransporterID'];
            $OrderList[$OrdDate['PackingSlip']]['TransporterKeyword']=$OrdDate['TransporterKeyword'];

            if($OrdDate['TransporterID']=='201454' OR  $OrdDate['TransporterID']=='201008' OR $OrdDate['TransporterID']=='200181'  OR $OrdDate['TransporterID']=='201451' OR $OrdDate['TransporterID']=='200170'){//jeigu VENIPAK arba KLIENTO TR tai taip ir paliekam
                $OrderList[$OrdDate['PackingSlip']]['TransporterKeywordWeb']=$OrdDate['TransporterKeyword'];
            }else{
                $cou = array('LT', 'LV', 'EE');
                if(in_array($OrdDate['Delivery_country_code'], $cou)){
                    $OrderList[$OrdDate['PackingSlip']]['TransporterKeywordWeb']='KITA LT';
                }else{
                    $OrderList[$OrdDate['PackingSlip']]['TransporterKeywordWeb']='KITA';
                }
            }

            $OrderList[$OrdDate['PackingSlip']]['Packs_picked']=$OrdDate['Packs_picked'];
            $OrderList[$OrdDate['PackingSlip']]['Pallets_picked']=$OrdDate['Pallets_picked'];
            $OrderList[$OrdDate['PackingSlip']]['PikedQuontityPacks']=$OrdDate['PikedQuontityPacks'];
            $OrderList[$OrdDate['PackingSlip']]['PikedQuontityPallets']=$OrdDate['PikedQuontityPallets'];
            
            
            $OrderList[$OrdDate['PackingSlip']]['OrderedQuontityPacks']=$OrdDate['OrderedQuontityPacks'];
            $OrderList[$OrdDate['PackingSlip']]['OrderedQuontityPallets']=$OrdDate['OrderedQuontityPallets'];

            $OrderList[$OrdDate['PackingSlip']]['Packing_slip_comment']=$OrdDate['Packing_slip_comment'];
            $OrderList[$OrdDate['PackingSlip']]['ShipmentComment']=$OrdDate['ShipmentComment'];
            $OrderList[$OrdDate['PackingSlip']]['CommentAfterDelivery']=$OrdDate['CommentAfterDelivery'];
            
            $OrderList[$OrdDate['PackingSlip']]['Delivery_type']=$OrdDate['Delivery_type'];
            $OrderList[$OrdDate['PackingSlip']]['Delivery_AddressID']=$OrdDate['Delivery_AddressID'];
            $OrderList[$OrdDate['PackingSlip']]['Delivery_country_code']=$OrdDate['Delivery_country_code'];
            $OrderList[$OrdDate['PackingSlip']]['Delivery_post']=$OrdDate['Delivery_post'];


            
            if($OrdDate['Delivery_department']){
                $OrderList[$OrdDate['PackingSlip']]['Delivery_street']=$OrdDate['Delivery_department'].', '.$OrdDate['Delivery_street'];
            }else{
                $OrderList[$OrdDate['PackingSlip']]['Delivery_street']=$OrdDate['Delivery_street'];
            }

            if($OrdDate['Delivery_District']){
                $OrderList[$OrdDate['PackingSlip']]['Delivery_city']=$OrdDate['Delivery_District'].', '.$OrdDate['Delivery_city'];
            }else{
                $OrderList[$OrdDate['PackingSlip']]['Delivery_city']=$OrdDate['Delivery_city'];
            }
            
            if($OrdDate['Delivery_County']){
                $OrderList[$OrdDate['PackingSlip']]['Delivery_city']=$OrderList[$OrdDate['PackingSlip']]['Delivery_city'].', '.$OrdDate['Delivery_County'];
            }

            

            $OrderList[$OrdDate['PackingSlip']]['Delivery_County']=$OrdDate['Delivery_County'];
            $OrderList[$OrdDate['PackingSlip']]['Delivery_District']=$OrdDate['Delivery_District'];

            $OrderList[$OrdDate['PackingSlip']]['Delivery_email']=$OrdDate['Delivery_email'];
            $OrderList[$OrdDate['PackingSlip']]['Delivery_phone']=$OrdDate['Delivery_phone'];
            $OrderList[$OrdDate['PackingSlip']]['Delivery_contact']=$OrdDate['Delivery_contact'];
            $OrderList[$OrdDate['PackingSlip']]['Delivery_contact_email']=$OrdDate['Delivery_contact_email'];
            $OrderList[$OrdDate['PackingSlip']]['Delivery_contact_phone']=$OrdDate['Delivery_contact_phone'];
            $OrderList[$OrdDate['PackingSlip']]['PackingSlipDate']=$OrdDate['PackingSlipDate'];
            $OrderList[$OrdDate['PackingSlip']]['PackingSlipComposedID']=$OrdDate['PackingSlipComposedID'];

            $OrderList[$OrdDate['PackingSlip']]['PakSiuntosNr']=$OrdDate['PakSiuntosNr'];
            $OrderList[$OrdDate['PackingSlip']]['PakSiuntaSukurta']=$OrdDate['PakSiuntaSukurta'];
            $OrderList[$OrdDate['PackingSlip']]['PakPakuotesStr']=$OrdDate['PakPakuotesStr'];
            $OrderList[$OrdDate['PackingSlip']]['PakSvorisSum']=$OrdDate['PakSvorisSum'];

            $OrderList[$OrdDate['PackingSlip']]['KrovinysReg']=$OrdDate['KrovinysReg'];
            $OrderList[$OrdDate['PackingSlip']]['PakSvorisSum']=$OrdDate['PakSvorisSum'];

            $OrderList[$OrdDate['PackingSlip']]['KurjerisReg']=$OrdDate['KurjerisReg'];
            $OrderList[$OrdDate['PackingSlip']]['KurjerisUzsakyta']=$OrdDate['KurjerisUzsakyta'];
            $OrderList[$OrdDate['PackingSlip']]['KurjOrderNr']=$OrdDate['KurjOrderNr'];

            $OrderList[$OrdDate['PackingSlip']]['VezejasReal']=$OrdDate['VezejasReal'];

            $OrderList[$OrdDate['PackingSlip']]['ToByInvoiced']=$OrdDate['ToByInvoiced'];
            $OrderList[$OrdDate['PackingSlip']]['ToByInvoicedDate']=$OrdDate['ToByInvoicedDate'];


            $OrderList[$OrdDate['PackingSlip']]['Express']= strtoupper($OrdDate['Express']);
            $OrderList[$OrdDate['PackingSlip']]['Prit_10_12']=$OrdDate['Prit_10_12'];
            $OrderList[$OrdDate['PackingSlip']]['SiuntExpress']= strtoupper($OrdDate['SiuntExpress']);
            $OrderList[$OrdDate['PackingSlip']]['SiuntPrit_10_12']=$OrdDate['SiuntPrit_10_12'];

            $OrderList[$OrdDate['PackingSlip']]['AutoPatikra']=$OrdDate['AutoPatikra'];
            $OrderList[$OrdDate['PackingSlip']]['AutoPatikraDate']=substr($OrdDate['AutoPatikraDate'], 0, 16);
            $OrderList[$OrdDate['PackingSlip']]['AutoPatikraDarbuotojas']=$OrdDate['AutoPatikraDarbuotojas'];
            
           

            $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['lyn__ref']=$OrdDate['lyn__ref'];
            $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['ord__ref']=$OrdDate['ord__ref'];
            $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['ProductID']=$OrdDate['afg__ref'];
            $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['ProductName']=$OrdDate['ProductName'];
            $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['ProdClientID']=$OrdDate['ProdClientID'];
            $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['ProdClientKey']=$OrdDate['ProdClientKey'];
            $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['ProdComment']=$OrdDate['ProdComment'];
            $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['InStock']=$OrdDate['InStock'];
            $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['OrderetQuantity']=$OrdDate['OrderetQuantity'];
            $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['GrossWeightOrdered']=$OrdDate['GrossWeightOrdered'];
            

            
            if (in_array($OrdDate['PackingSlip'], $CB)) {
                $OrderList[$OrdDate['PackingSlip']]['Checked']='CHECKED';
            }else{
                $OrderList[$OrdDate['PackingSlip']]['Checked']='';
            }
            
            



        }//end foreach
    }//end if

    //!!!!!! DEBUG
    //$this->var_dump($SearchDuom, "SearchDuom <hr>$qry_<hr> ");//-----------------DEBUG

    //!!!!!! DEBUG
    //$this->var_dump($OrderList, "OrderList <hr>$qry<hr> ");//-----------------DEBUG



    //***********************************************************************************************
    // PRIDEDAM NAVISION DUOMENYS
    //


    if($OrderListTemp AND $SearchDuom['sSiuntaID']){//jeigu ieskom pagal siuntos UID ir jau ja radom CERME, tai nebeieskom Navisione, nes nebus viena siunta ir ten ir ten
        $NAV_siuntuArray = array();
    }else{
        $NAV_siuntuArray = $this->NAV_Siuntos($SearchDuom);
    }

    //!!!!!! DEBUG
    //$this->var_dump($NAV_siuntuArray, "+++NAV_siuntuArray <hr>$qry__<hr> ");//-----------------DEBUG

    //NAV duomenys integruojam i bendra array (kuri gavom auksciau is CERM)
    //Derinam gautus duomenys is NAVISIONO prie CERMiniu duomenu - suvienodinam struktura
    /* tvarkom struktura - suvienodinam su siuntu duomenimis paimtais is CERM */
    
    if($NAV_siuntuArray){
        foreach ($NAV_siuntuArray as $key => $OrdDate) {

            //si duomenu struktura turi buti identiska su auksciau esancia struktura

            $OrderList[$OrdDate['No_']]['PackingSlip']=$OrdDate['No_'];
            $OrderList[$OrdDate['PackingSlip']]['Expected_Shipment_Date']=$OrdDate['Shipment Date'];
            $OrderList[$OrdDate['PackingSlip']]['Expected_Delivery_Date']='';//$OrdDate['Expected_Delivery_Date'];
            $OrderList[$OrdDate['PackingSlip']]['Real_Shipped_Date']=$OrdDate['Shipment Date'];

            if($OrdDate['APGDVSSendToDVS']==1){
                $OrderList[$OrdDate['PackingSlip']]['DeliveryStatus']='Y';
            }else{
                $OrderList[$OrdDate['PackingSlip']]['DeliveryStatus']='N';
            }
            
            $OrderList[$OrdDate['PackingSlip']]['InvoiceStatus']='';//$OrdDate['InvoiceStatus'];
            $OrderList[$OrdDate['PackingSlip']]['bst__ref']=$OrdDate['No_'];//$OrdDate['bst__ref'];
            $OrderList[$OrdDate['PackingSlip']]['ClientName']=$OrdDate['Bill-to Name'];
            $OrderList[$OrdDate['PackingSlip']]['ShippedFrom']='ETK';
            $OrderList[$OrdDate['PackingSlip']]['Delivery_Company']=$OrdDate['Bill-to Name'];

            switch ($OrdDate['Shipment Method Code']) {
                case 'VENIPAK':
                    $OrdDate['TransporterID']='201008';
                    break;
                case 'SCHENKER':
                    $OrdDate['TransporterID']='201451';
                    break;
                case 'KLIENTO TR':
                    $OrdDate['TransporterID']='200181';
                    break;
                
                default:
                    $OrdDate['TransporterID']='';
                    break;
            }
            $OrderList[$OrdDate['PackingSlip']]['TransporterID']=$OrdDate['TransporterID'];
            $OrderList[$OrdDate['PackingSlip']]['TransporterKeyword']=$OrdDate['Shipment Method Code']; /// VENIPAK, DHL, ....
            $OrderList[$OrdDate['PackingSlip']]['TransporterKeywordWeb']=$OrdDate['Shipment Method Code'];
            /*
            if($OrdDate['TransporterID']=='201454' OR  $OrdDate['TransporterID']=='201008' OR $OrdDate['TransporterID']=='200181'  OR $OrdDate['TransporterID']=='201451' OR $OrdDate['TransporterID']=='200170'){//jeigu VENIPAK arba KLIENTO TR tai taip ir paliekam
                $OrderList[$OrdDate['PackingSlip']]['TransporterKeywordWeb']=$OrdDate['TransporterKeyword'];
            }else{
                $cou = array('LT', 'LV', 'EE');
                if(in_array($OrdDate['Delivery_country_code'], $cou)){
                    $OrderList[$OrdDate['PackingSlip']]['TransporterKeywordWeb']='KITA LT';
                }else{
                    $OrderList[$OrdDate['PackingSlip']]['TransporterKeywordWeb']='KITA';
                }
            }
            */

            $OrderList[$OrdDate['PackingSlip']]['Packs_picked']='1'; //$OrdDate['Packs_picked'];
            $OrderList[$OrdDate['PackingSlip']]['Pallets_picked']=''; //$OrdDate['Pallets_picked'];
            $OrderList[$OrdDate['PackingSlip']]['PikedQuontityPacks']='1'; //$OrdDate['PikedQuontityPacks'];
            $OrderList[$OrdDate['PackingSlip']]['PikedQuontityPallets']=''; //$OrdDate['PikedQuontityPallets'];
            
            
            $OrderList[$OrdDate['PackingSlip']]['OrderedQuontityPacks']='1'; //$OrdDate['OrderedQuontityPacks'];
            $OrderList[$OrdDate['PackingSlip']]['OrderedQuontityPallets']=''; //$OrdDate['OrderedQuontityPallets'];

            $OrderList[$OrdDate['PackingSlip']]['Packing_slip_comment']=''; //$OrdDate['Packing_slip_comment'];
            $OrderList[$OrdDate['PackingSlip']]['ShipmentComment']=''; //$OrdDate['ShipmentComment'];
            $OrderList[$OrdDate['PackingSlip']]['CommentAfterDelivery']=''; //$OrdDate['CommentAfterDelivery'];
            
            $OrderList[$OrdDate['PackingSlip']]['Delivery_type']='2';/* 0 - pristatoma į AURIKA sandėlį, 1 - pristatoma kliento pagrindiniu adresu,  2,3,4 - pristatoma kliento adresu */
            $OrderList[$OrdDate['PackingSlip']]['Delivery_AddressID']=''; //$OrdDate['Delivery_AddressID'];
            $OrderList[$OrdDate['PackingSlip']]['Delivery_country_code']=$OrdDate['Ship-to Country_Region Code'];
            $OrderList[$OrdDate['PackingSlip']]['Delivery_post']=$OrdDate['Ship-to Post Code'];
            if($OrdDate['Ship-to Address 2']){
                $OrderList[$OrdDate['PackingSlip']]['Delivery_street']=$OrdDate['Ship-to Address'].', '.$OrdDate['Ship-to Address 2'];
            }else{
                $OrderList[$OrdDate['PackingSlip']]['Delivery_street']=$OrdDate['Ship-to Address'];
            }
            $OrderList[$OrdDate['PackingSlip']]['Delivery_city']=$OrdDate['Ship-to City'];
            $OrderList[$OrdDate['PackingSlip']]['Delivery_County']=$OrdDate['Ship-to Country_Region Code'];
            $OrderList[$OrdDate['PackingSlip']]['Delivery_District']='';

            $OrderList[$OrdDate['PackingSlip']]['Delivery_email']=$OrdDate['Sell-to E-Mail'];
            $OrderList[$OrdDate['PackingSlip']]['Delivery_phone']=$OrdDate['Sell-to Phone No_'];
            $OrderList[$OrdDate['PackingSlip']]['Delivery_contact']='';
            $OrderList[$OrdDate['PackingSlip']]['Delivery_contact_email']=$OrdDate['Sell-to E-Mail'];
            $OrderList[$OrdDate['PackingSlip']]['Delivery_contact_phone']=$OrdDate['Sell-to Phone No_'];
            $OrderList[$OrdDate['PackingSlip']]['PackingSlipDate']=$OrdDate['Shipment Date'];
            $OrderList[$OrdDate['PackingSlip']]['PackingSlipComposedID']='';//$OrdDate['PackingSlipComposedID'];
            
            //-----****************** IS TVS
            $OrderList[$OrdDate['PackingSlip']]['PakSiuntosNr']=$OrdDate['PakSiuntosNr'];
            $OrderList[$OrdDate['PackingSlip']]['PakSiuntaSukurta']=$OrdDate['PakSiuntaSukurta'];
            $OrderList[$OrdDate['PackingSlip']]['PakPakuotesStr']=$OrdDate['PakPakuotesStr'];
            $OrderList[$OrdDate['PackingSlip']]['PakSvorisSum']=$OrdDate['PakSvorisSum'];

            $OrderList[$OrdDate['PackingSlip']]['KrovinysReg']=$OrdDate['KrovinysReg'];
            $OrderList[$OrdDate['PackingSlip']]['PakSvorisSum']=$OrdDate['PakSvorisSum'];

            $OrderList[$OrdDate['PackingSlip']]['KurjerisReg']=$OrdDate['KurjerisReg'];
            $OrderList[$OrdDate['PackingSlip']]['KurjerisUzsakyta']=$OrdDate['KurjerisUzsakyta'];
            $OrderList[$OrdDate['PackingSlip']]['KurjOrderNr']=$OrdDate['KurjOrderNr'];

            $OrderList[$OrdDate['PackingSlip']]['VezejasReal']=$OrdDate['VezejasReal'];

            $OrderList[$OrdDate['PackingSlip']]['ToByInvoiced']=''; // $OrdDate['ToByInvoiced'];
            $OrderList[$OrdDate['PackingSlip']]['ToByInvoicedDate']=''; // $OrdDate['ToByInvoicedDate'];


            $OrderList[$OrdDate['PackingSlip']]['Express']= strtoupper($OrdDate['Express']);
            $OrderList[$OrdDate['PackingSlip']]['Prit_10_12']=$OrdDate['Prit_10_12'];
            $OrderList[$OrdDate['PackingSlip']]['SiuntExpress']= strtoupper($OrdDate['SiuntExpress']);
            $OrderList[$OrdDate['PackingSlip']]['SiuntPrit_10_12']=$OrdDate['SiuntPrit_10_12'];
            
           
            /* 2021-11-30
            $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['lyn__ref']=''; // $OrdDate['lyn__ref'];
            $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['ord__ref']=''; // $OrdDate['ord__ref'];
            $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['ProductID']=''; // $OrdDate['afg__ref'];
            $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['ProductName']=''; // $OrdDate['ProductName'];
            $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['ProdClientID']=''; // $OrdDate['ProdClientID'];
            $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['ProdClientKey']=''; // $OrdDate['ProdClientKey'];
            $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['ProdComment']=''; // $OrdDate['ProdComment'];
            $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['InStock']=''; // $OrdDate['InStock'];
            $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['OrderetQuantity']=''; // $OrdDate['OrderetQuantity'];
            $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['GrossWeightOrdered']=''; // $OrdDate['GrossWeightOrdered'];
            */
            
            if (in_array($OrdDate['PackingSlip'], $CB)) {
                $OrderList[$OrdDate['PackingSlip']]['Checked']='CHECKED';
            }else{
                $OrderList[$OrdDate['PackingSlip']]['Checked']='';
            }
            

        }//end foreach
    }//end if


    //!!!!!! DEBUG
    //$this->var_dump($OrderList, "OrderList---- <hr>$qry_<hr> ");//-----------------DEBUG






    return $OrderList;
}//end function



//nuskaito siuntas is NAV ir is TVS ir apjungia duomenys i viena masyva
public function NAV_Siuntos($SearchDuom){

    /*
    SearchDuom
          'sSiuntaID' => string '' (length=0)
          'sOrderID' => string '339112' (length=6)
          'sPackingSlip' => string '' (length=0)
          'sInvStat' => string '' (length=0)
          'sSandelys' => string 'KEG' (length=3)
          'sDatNuo' => string '2021-11-29' (length=10)
          'sDatIki' => string '2021-11-29' (length=10)
          'sVezejas' => string 'VENIPAK' (length=7)
          'sKlientas' => string 'inter' (length=5)
          'sSaliesKodas' => string 'de' (length=2)
          'sAdresas' => string 'Sodų g. ' (length=9)
          'sSiuntosBus' => string '' (length=0)
          'CB' => null    
    */

    //Jeigu yra paieskoje SiuntosID tai pirma paziurim TVSe ir papildom paieska ka reikia pasiimti is NAVISION
    //surandam TVE tokia siunta ir pagal tai patikrinam ar ji ir NAV sandelio ir tada atitinkamai koki ORDERI reikia paimt
    $ieskoti = 'TAIP';// ieskom visais atvejais iskyrus tada kai ieskoma pagal siuntos numeri ir jo nera TVSe, tada nereikia nieko ieskoti ir NAV 
    if($SearchDuom['sSiuntaID']){
        $searchThisOrder = $this->getSiuntaDuomFromTVS($SearchDuom['sSiuntaID']);

        $SearchDuom['sPackingSlipArray']=array();


        if($searchThisOrder){
            foreach ($searchThisOrder as $key => $tvsSiunt) {
                if($tvsSiunt['uid']==$SearchDuom['sSiuntaID'] AND $tvsSiunt['Sandelys']=='ETK' AND $tvsSiunt['deleted']==0){
                    $SearchDuom['sPackingSlipArray'][]=$tvsSiunt['NAVOrder'];
                    //echo "<hr>2222 ".$tvsSiunt['uid']."=".$searchThisOrder['sSiuntaID']." AND ".$tvsSiunt['Sandelys']."=='ETK' AND ".$tvsSiunt['deleted']." ==0 ";
                }else{//end if
                    //echo "<hr>333 ".$tvsSiunt['uid']."=".$searchThisOrder['sSiuntaID']." AND ".$tvsSiunt['Sandelys']."=='ETK' AND ".$tvsSiunt['deleted']." ==0 ";
                }
            }//end foreach
            
        }else{
            //jeigu ieskom pagal siuntos numeri ETK sandelyje bet jo nera TVSe, tai ir NAV DB neieskom nieko, nes nebus nieko
            $ieskoti = 'NE';
        }
    }//end if



    //nusiskaitom NAVISION siuntu duomenys pagal paieskos parametrus
    $iTVS = '1'; // Cia pazymim, kad i TVS imtu tik siuntas kurios paruostos siuntimui
    if($ieskoti == 'TAIP'){// ieskom visais atvejais iskyrus tada kai ieskoma pagal siuntos numeri ir jo nera TVSe, tada nereikia nieko ieskoti ir NAV 
        $thisNAVOrders = $this->getOrderToShipFromNAVNew ($SearchDuom, $iTVS);
    }

    //!!!!!! DEBUG
    //echo "<br><br><br><br>******************";
    //$this->var_dump($SearchDuom['sPackingSlipArray'], "-++++SearchDuom['sPackingSlipArray'] <hr>$qryP<hr> ");//-----------------DEBUG





    /* Nuskaitom duomenys is TVS ir apjungiam su NAV duomenimis */
    
    $NAVOrders = array();
    if($thisNAVOrders){
        //Pagal gautus duomenys pasiimam duomenys is TVS ar si siunta jau buvo siusta
        $NAV_keyArray = array();
        foreach ($thisNAVOrders as $key => $NAVOrder) {
            $NAV_keyArray[]=$NAVOrder['No_'];
        }//end foreach

        $SQL_TVS = "
        SELECT 
            /*
            '9' + RIGHT(A.NAVOrder ,6) AS PackingSlip,
            A.NAVOrder AS NAVOrder,
            */
            A.NAVOrder AS PackingSlip, 
            S.uid AS PakSiuntosNr,
            S.Created AS PakSiuntaSukurta,
            S.Pakuotes AS PakPakuotesStr,
            S.SvorisSum AS PakSvorisSum,

            S.KrovinysReg AS KrovinysReg,
            S.SiuntaUzregistruota AS PakSvorisSumUzreg,

            S.KurjerisReg AS KurjerisReg,
            S.VezejasUzsakyta AS KurjerisUzsakyta,
            S.KurjOrderNr AS KurjOrderNr,
            
            S.VezejasReal AS VezejasReal,

            S.Express AS SiuntExpress,
            S.Pristat1012 AS SiuntPrit_10_12

        FROM _TMS_keys AS A
        JOIN _TMS_Siuntos AS S ON A.SiuntaUID = S.UID
        /* JOIN _TMS_Pak AS C ON C.SiuntaUID = S.UID */
        WHERE A.deleted=0 AND A.NAVOrder IN ('" . implode('\',\'', $NAV_keyArray) . "')
        ";

        $mssql = DBMSSqlCERM::getInstance();
        //Jau uzsakytu NAVISION siuntu duomenu dalis TVS lenteleje (tas kas is NAV jau pateko i TVS)
        $NAVOrderListNAV = $mssql->querySql($SQL_TVS, 1);

    //!!!!!! DEBUG
    //$this->var_dump($NAVOrderListNAV, "-++++NAVOrderListNAV <hr>$SQL_TVS<hr> ");//-----------------DEBUG

        //Kad lengviau butu susieti, tai perbegam per array ir KEY pakeiciam i NAV Order Nr
        $NAVOrderListTVS = array();
        if($NAVOrderListNAV){//
            foreach ($NAVOrderListNAV as $key1 => $NAVTVSUzsak) {
                $NAVOrderListTVS[$NAVTVSUzsak['PackingSlip']]=$NAVTVSUzsak;
            }
        }
        unset($NAVOrderListNAV);//atlaisvinam atminti

        //Prijungiam NAV ir TVS duomenys i viena masyva
        foreach ($thisNAVOrders as $keyNO => $valueNO) {
            $siuntaTinkaPagalPaieska = 'N';//pradine busena
            if($SearchDuom['sSiuntosBus']=='SiuntOut'){//uzregistruota TVSe ir issiusta (zalia)
                //$WHERE .= " AND S.KrovinysReg = 'Y ' " ;
                if($NAVOrderListTVS[$valueNO['No_']]['KrovinysReg']=='Y ' AND $NAVOrderListTVS[$valueNO['No_']]['PakSiuntosNr']){
                    $siuntaTinkaPagalPaieska = 'Y';//jeigu reikia tik issiustu siuntu ir si yra tokia tai ja imam
                }
            }else if ($SearchDuom['sSiuntosBus']=='SiuntReg'){////tik uzregistruota TVSe
                //$WHERE .= " AND (S.uid > 0  AND (S.KrovinysReg  IS NULL OR S.KrovinysReg=''))" ;
                if($NAVOrderListTVS[$valueNO['No_']]['KrovinysReg']=='  ' AND $NAVOrderListTVS[$valueNO['No_']]['PakSiuntosNr']){
                    $siuntaTinkaPagalPaieska = 'Y';//jeigu reikia tik registruotu TVS bet dar neissiust (yra siuntos numeris TVS bet nera pozymio, kad issiusta)
                }
            }else if ($SearchDuom['sSiuntosBus']=='SiuntNeReg'){//tik neuzregistruotos TVSe
                //$WHERE .= " AND (S.uid IS NULL OR S.uid='') " ;
                if(!$NAVOrderListTVS[$valueNO['No_']]['PakSiuntosNr']){
                    $siuntaTinkaPagalPaieska = 'Y';//jeigu reikia tik registruotu TVS bet dar neissiust (yra siuntos numeris TVS bet nera pozymio, kad issiusta)
                }
            }else{
                $siuntaTinkaPagalPaieska = 'Y'; // jeigu nieko nenurodyta busenu filtre, tai imam visas siuntas
            }

//echo ("<br><br><br> BUSENA:*" .$NAVOrderListTVS[$valueNO['No_']]['KrovinysReg']."* -- ".$NAVOrderListTVS[$valueNO['No_']]['PakSiuntosNr']. " *** " . $siuntaTinkaPagalPaieska . " +++" .$SearchDuom['sSiuntosBus'] ."###");

            if ($siuntaTinkaPagalPaieska == 'Y'){
                $NAVOrders[$valueNO['No_']] = $valueNO;

                $NAVOrders[$valueNO['No_']] = $valueNO;
                $NAVOrders[$valueNO['No_']]['PackingSlip'] = $valueNO['No_'];
                $NAVOrders[$valueNO['No_']]['PakSiuntosNr'] = $NAVOrderListTVS[$valueNO['No_']]['PakSiuntosNr'];
                $NAVOrders[$valueNO['No_']]['PakSiuntaSukurta'] = $NAVOrderListTVS[$valueNO['No_']]['PakSiuntaSukurta'];
                $NAVOrders[$valueNO['No_']]['PakPakuotesStr'] = $NAVOrderListTVS[$valueNO['No_']]['PakPakuotesStr'];
                $NAVOrders[$valueNO['No_']]['PakSvorisSum'] = $NAVOrderListTVS[$valueNO['No_']]['PakSvorisSum'];

                $NAVOrders[$valueNO['No_']]['KrovinysReg'] = $NAVOrderListTVS[$valueNO['No_']]['KrovinysReg'];
                $NAVOrders[$valueNO['No_']]['PakSvorisSumUzreg'] = $NAVOrderListTVS[$valueNO['No_']]['PakSvorisSumUzreg'];

                $NAVOrders[$valueNO['No_']]['KurjerisReg'] = $NAVOrderListTVS[$valueNO['No_']]['KurjerisReg'];
                $NAVOrders[$valueNO['No_']]['KurjerisUzsakyta'] = $NAVOrderListTVS[$valueNO['No_']]['KurjerisUzsakyta'];
                $NAVOrders[$valueNO['No_']]['KurjOrderNr'] = $NAVOrderListTVS[$valueNO['No_']]['KurjOrderNr'];

                $NAVOrders[$valueNO['No_']]['VezejasReal'] = $NAVOrderListTVS[$valueNO['No_']]['VezejasReal'];

                $NAVOrders[$valueNO['No_']]['SiuntExpress'] = $NAVOrderListTVS[$valueNO['No_']]['SiuntExpress'];
                $NAVOrders[$valueNO['No_']]['SiuntPrit_10_12'] = $NAVOrderListTVS[$valueNO['No_']]['SiuntPrit_10_12'];
            }//end if 
            
        }//end foreach
        //!!!!!! DEBUG
        //$this->var_dump($NAVOrders, "*****NAVOrders <hr>$SQL_TVS<hr> ");//-----------------DEBUG

    }//end if



    return $NAVOrders; //sis masyvas dar neatitinka duomenu is CERM strukturos ... reikia atskiro suvienodinimo, ji darom primineje funkcijoje po pasikreipimo i sia

}//end function




/* Naudojama isvesti LISTA orderiu is NAVISION 
Siuo metu modernizuojama ir NENAUDOJAMA kol nebus padaryta iki galo, vietoje jos naudojama sena funkcija auksciau su panasiu pavadinimu
*/
public function NAV_SiuntosNewFun__($SearchDuom){

    /*
    SearchDuom
          'sSiuntaID' => string '' (length=0)
          'sOrderID' => string '339112' (length=6)
          'sPackingSlip' => string '' (length=0)
          'sInvStat' => string '' (length=0)
          'sSandelys' => string 'KEG' (length=3)
          'sDatNuo' => string '2021-11-29' (length=10)
          'sDatIki' => string '2021-11-29' (length=10)
          'sVezejas' => string 'VENIPAK' (length=7)
          'sKlientas' => string 'inter' (length=5)
          'sSaliesKodas' => string 'de' (length=2)
          'sAdresas' => string 'Sodų g. ' (length=9)
          'sSiuntosBus' => string '' (length=0)
          'CB' => null    
    */


        //Formuojam WHERE is_TMS_Siuntos
        $WHERE = " WHERE S.deleted=0 AND S.Sandelys = 'ETK' ";

        if($SearchDuom['sSiuntaID']){
            $WHERE .= " AND S.uid = ".$SearchDuom['sSiuntaID']." ";
        }

        if($SearchDuom['sOrderID']){
            $WHERE .= " AND A.PackSlipID = '".$SearchDuom['sOrderID']."' ";
        }

        if($SearchDuom['sPackingSlip']){
            $WHERE .= " AND A.PackSlipID = '".$SearchDuom['sPackingSlip']."' ";
        }

        /* Cia sandelys visada tik ETK
        if($SearchDuom['sSandelys']){
            $WHERE .= " AND S.Sandelys = '".$SearchDuom['sSandelys']."' ";
        }
        */

        if($SearchDuom['sDatNuo']){
            $WHERE .= " AND S.Created >= '".$SearchDuom['sDatNuo']." 00:00:00.000' ";
        }

        if($SearchDuom['sDatIki']){
            $WHERE .= " AND S.Created <= '".$SearchDuom['sDatIki']." 23:59:59.000' ";
        }

        if($SearchDuom['sVezejas']){
            $WHERE .= " AND  (S.VezejasCermShort = '".$SearchDuom['sVezejas']."' OR S.VezejasCermShort = '".$SearchDuom['VezejasReal']."') ";
        }

        if($SearchDuom['sKlientas']){
            $WHERE .= " AND S.Gavejas LIKE '%".$SearchDuom['sKlientas']."%' ";
        }

        if($SearchDuom['sSaliesKodas']){
            $WHERE .= " AND S.Gavejas = '".$SearchDuom['SaliesKodas']."' ";
        }

        if($SearchDuom['sAdresas']){
            $WHERE .= " AND S.Adresas LIKE '%".$SearchDuom['sAdresas']."%' ";
        }

        if($SearchDuom['sSaliesKodas']){
            $WHERE .= " AND S.Gavejas = '".$SearchDuom['SaliesKodas']."' ";
        }

        //TODO paieska pagal siuntos busena

        $SQL_TVS = "
        SELECT 
            /*
            '9' + RIGHT(A.NAVOrder ,6) AS PackingSlip,
            A.NAVOrder AS NAVOrder,
            */
            A.NAVOrder AS PackingSlip, 
            S.uid AS PakSiuntosNr,
            S.Created AS PakSiuntaSukurta,
            S.Pakuotes AS PakPakuotesStr,
            S.SvorisSum AS PakSvorisSum,

            S.KrovinysReg AS KrovinysReg,
            S.SiuntaUzregistruota AS PakSvorisSumUzreg,

            S.KurjerisReg AS KurjerisReg,
            S.VezejasUzsakyta AS KurjerisUzsakyta,
            S.KurjOrderNr AS KurjOrderNr,
            
            S.VezejasReal AS VezejasReal,

            S.Express AS SiuntExpress,
            S.Pristat1012 AS SiuntPrit_10_12

        FROM _TMS_Siuntos AS S
        JOIN _TMS_keys AS A ON A.SiuntaUID = S.UID
        $WHERE 
        ";

        /* JOIN _TMS_Pak AS C ON C.SiuntaUID = S.UID */
        /* WHERE A.deleted=0 AND A.NAVOrder IN ('" . implode('\',\'', $NAV_keyArray) . "') */
        
        //NUSKAITOM VISAS ETK SIUNTAS IS TVS (jau registruotas) pagal paieska
        $mssql = DBMSSqlCERM::getInstance();
        //Jau uzsakytu NAVISION siuntu duomenu dalis TVS lenteleje (tas kas is NAV jau pateko i TVS)
        $NAVOrderListFromTVSNAV = $mssql->querySql($SQL_TVS, 1);


        //Kad lengviau butu susieti, tai perbegam per array ir KEY pakeiciam i NAV Order Nr
        $NAVOrderListTVS = array();
        $OrderNavArrayInTVS = array();
        if($NAVOrderListFromTVSNAV){//
            foreach ($NAVOrderListFromTVSNAV as $key1 => $NAVTVSUzsak) {
                $NAVOrderListTVS[$NAVTVSUzsak['PackingSlip']]=$NAVTVSUzsak;
                $OrderNavArrayInTVS[]=$NAVTVSUzsak['PackingSlip'];
            }
        }
        unset($NAVOrderListFromTVSNAV);//atlaisvinam atminti

    //!!!!!! DEBUG
    $this->var_dump($NAVOrderListTVS, "-++++NAVOrderListTVS <hr>$SQL_TVS<hr> ");//-----------------DEBUG

    //!!!!!! DEBUG
    $this->var_dump($OrderNavArrayInTVS, "-++11++OrderNavArrayInTVS <hr>$SQL_TVS<hr> ");//-----------------DEBUG



    //nusiskaitom NAVISION siuntu duomenys pagal paieskos parametrus (ir naujos ir jau registruotos)
    $iTVS = '1'; // Cia pazymim, kad i TVS imtu tik siuntas kurios paruostos siuntimui
    $thisNAVOrders = $this->getOrderToShipFromNAVnew ($SearchDuom, $OrderNavArrayInTVS);

    //!!!!!! DEBUG
    //echo "<br><br><br><br>******************";
    //$this->var_dump($thisNAVOrders, "-++++thisNAVOrders <hr>$qryP<hr> ");//-----------------DEBUG
    
    $NAVOrders = array();
    if($thisNAVOrders){
        //Pagal gautus duomenys pasiimam duomenys is TVS ar si siunta jau buvo siusta
        $NAV_keyArray = array();
        foreach ($thisNAVOrders as $key => $NAVOrder) {
            $NAV_keyArray[]=$NAVOrder['No_'];
        }//end foreach


        //Prijungiam NAV ir TVS duomenys i viena masyva
        foreach ($thisNAVOrders as $keyNO => $valueNO) {
            $siuntaTinkaPagalPaieska = 'N';//pradine busena
            if($SearchDuom['sSiuntosBus']=='SiuntOut'){//uzregistruota TVSe ir issiusta (zalia)
                //$WHERE .= " AND S.KrovinysReg = 'Y ' " ;
                if($NAVOrderListTVS[$valueNO['No_']]['KrovinysReg']=='Y ' AND $NAVOrderListTVS[$valueNO['No_']]['PakSiuntosNr']){
                    $siuntaTinkaPagalPaieska = 'Y';//jeigu reikia tik issiustu siuntu ir si yra tokia tai ja imam
                }
            }else if ($SearchDuom['sSiuntosBus']=='SiuntReg'){////tik uzregistruota TVSe
                //$WHERE .= " AND (S.uid > 0  AND (S.KrovinysReg  IS NULL OR S.KrovinysReg=''))" ;
                if($NAVOrderListTVS[$valueNO['No_']]['KrovinysReg']=='  ' AND $NAVOrderListTVS[$valueNO['No_']]['PakSiuntosNr']){
                    $siuntaTinkaPagalPaieska = 'Y';//jeigu reikia tik registruotu TVS bet dar neissiust (yra siuntos numeris TVS bet nera pozymio, kad issiusta)
                }
            }else if ($SearchDuom['sSiuntosBus']=='SiuntNeReg'){//tik neuzregistruotos TVSe
                //$WHERE .= " AND (S.uid IS NULL OR S.uid='') " ;
                if(!$NAVOrderListTVS[$valueNO['No_']]['PakSiuntosNr']){
                    $siuntaTinkaPagalPaieska = 'Y';//jeigu reikia tik registruotu TVS bet dar neissiust (yra siuntos numeris TVS bet nera pozymio, kad issiusta)
                }
            }else{
                $siuntaTinkaPagalPaieska = 'Y'; // jeigu nieko nenurodyta busenu filtre, tai imam visas siuntas
            }

//echo ("<br><br><br> BUSENA:*" .$NAVOrderListTVS[$valueNO['No_']]['KrovinysReg']."* -- ".$NAVOrderListTVS[$valueNO['No_']]['PakSiuntosNr']. " *** " . $siuntaTinkaPagalPaieska . " +++" .$SearchDuom['sSiuntosBus'] ."###");

            if ($siuntaTinkaPagalPaieska == 'Y'){
                $NAVOrders[$valueNO['No_']] = $valueNO;

                $NAVOrders[$valueNO['No_']] = $valueNO;
                $NAVOrders[$valueNO['No_']]['PackingSlip'] = $valueNO['No_'];
                $NAVOrders[$valueNO['No_']]['PakSiuntosNr'] = $NAVOrderListTVS[$valueNO['No_']]['PakSiuntosNr'];
                $NAVOrders[$valueNO['No_']]['PakSiuntaSukurta'] = $NAVOrderListTVS[$valueNO['No_']]['PakSiuntaSukurta'];
                $NAVOrders[$valueNO['No_']]['PakPakuotesStr'] = $NAVOrderListTVS[$valueNO['No_']]['PakPakuotesStr'];
                $NAVOrders[$valueNO['No_']]['PakSvorisSum'] = $NAVOrderListTVS[$valueNO['No_']]['PakSvorisSum'];

                $NAVOrders[$valueNO['No_']]['KrovinysReg'] = $NAVOrderListTVS[$valueNO['No_']]['KrovinysReg'];
                $NAVOrders[$valueNO['No_']]['PakSvorisSumUzreg'] = $NAVOrderListTVS[$valueNO['No_']]['PakSvorisSumUzreg'];

                $NAVOrders[$valueNO['No_']]['KurjerisReg'] = $NAVOrderListTVS[$valueNO['No_']]['KurjerisReg'];
                $NAVOrders[$valueNO['No_']]['KurjerisUzsakyta'] = $NAVOrderListTVS[$valueNO['No_']]['KurjerisUzsakyta'];
                $NAVOrders[$valueNO['No_']]['KurjOrderNr'] = $NAVOrderListTVS[$valueNO['No_']]['KurjOrderNr'];

                $NAVOrders[$valueNO['No_']]['VezejasReal'] = $NAVOrderListTVS[$valueNO['No_']]['VezejasReal'];

                $NAVOrders[$valueNO['No_']]['SiuntExpress'] = $NAVOrderListTVS[$valueNO['No_']]['SiuntExpress'];
                $NAVOrders[$valueNO['No_']]['SiuntPrit_10_12'] = $NAVOrderListTVS[$valueNO['No_']]['SiuntPrit_10_12'];
            }//end if 
            
        }//end foreach
        //!!!!!! DEBUG
        //$this->var_dump($NAVOrders, "*****NAVOrders <hr>$SQL_TVS<hr> ");//-----------------DEBUG

    }//end if



    return $NAVOrders; //sis masyvas dar neatitinka duomenu is CERM strukturos ... reikia atskiro suvienodinimo, ji darom primineje funkcijoje po pasikreipimo i sia

}//end function



public function getSiuntaDuomFromTVS($SiuntaID){
    if($SiuntaID){

        $qry = "
            SELECT           
                *
            FROM _TMS_Siuntos  AS A
            LEFT JOIN _TMS_Keys AS B ON A.uid=B.SiuntaUID
            WHERE uid = '".$SiuntaID."'

        ";

        $mssql = DBMSSqlCERM::getInstance();
        //$RezDuom = $mssql->querySql($qry, 1);
        $RezArray = $mssql->querySql($qry, 1);
        //!!!!!! DEBUG
        //$this->var_dump($RezArray, "RezArray <hr>$qry<hr> ");//-----------------DEBUG

    }//end if

    return $RezArray;
}//end function





/*20190925 A. Ramonas

*/
public function getOrderData($SelectedID){
    $RezDuom = array();

    //$this->var_dump($SelectedID, "SelectedID <hr>$qry<hr> ");

    if($this->is_ID($SelectedID)){
    $qry = "
        SELECT TOP 1000
            A.lyn__ref,
            A.lbn__ref AS PackingSlip,
            A.vrz__tst AS Shipped, /* 0-NotApplicable; 1-Not yet ready tro ship, N-ToDoo, Y-Done, Z-Returned */
            A.lev__tst AS DeliveryStatus, /* N-Not delivered */
            A.fac__tst AS InvoiceStatus, /* 0- Not yet invoiced; N- To invoice; W- In process, Y - Invoiced */
            A.levb_dat,
            A.bst__ref, 
            A.afg__ref,
            C.naam____ AS ClientName,

            /* LS, 2LS */
            C.kla__ref AS LS_ClientID,
            C.straat__ AS LS_Street,
            C.land_ref AS LS_LandRef,
            C.county__ AS LS_Gyvenviete, /*Apskritis*/
            C.post_ref AS LS_PostCode,
            C.postnaam AS LS_Miestas,
            C.telefoon AS LS_Telefonas,
            C.telefax_ AS LS_Faksas,
            C.telex___ AS LS_Email,

            CASE
                WHEN A.tstval03='1000' THEN 'KEG'
                WHEN A.tstval03='2000' THEN 'KPG'
                WHEN A.tstval03='3000' THEN 'ETK1'
                ELSE 'Unknown'
            END AS 'ShippedFrom',

            CASE
                WHEN A.trn__srt='1'
                THEN C.naam____
                ELSE L.lev_loc1 
            END AS 'Delivery_Company',

            A.lev__ref as TransporterID,
            A.lev__rpn AS TransporterKeyword,
            left(convert(char,A.vrzv_dat,120),10) AS 'Expected_Shipment_Date',
            left(convert(char,A.levv_dat,120),10) AS 'Expected_Delivery_Date',
            left(convert(char,A.vrz__dat,120),10) AS 'Real_Shipped_Date',
            A.b_netto_ AS 'NETTO_estimated',
            A.koloma11 AS 'NETTO_picked',
            A.aant_pak AS 'Packs_picked',
            A.aant_pal AS 'Pallets_picked',
            A.lbn__com AS 'Packing_slip_comment',
            A.levtrcom AS 'Delivery_comment',
            A.trn__srt AS 'Delivery_type',  /* 0 - pristatoma į AURIKA sandėlį, 1 - pristatoma kliento pagrindiniu adresu,  2,3,4 - pristatoma kliento adresu */
            A.lok__ref AS 'Delivery_AddressID',
            CASE
                WHEN A.trn__srt='1'
                THEN C.land_ref
                ELSE L.land_ref  
            END AS 'Delivery_country_code',
            CASE
                WHEN A.trn__srt='1'
                THEN C.post_ref
                ELSE L.post_ref  
            END AS 'Delivery_post',
            CASE
                WHEN A.trn__srt='1'
                THEN C.postnaam
                ELSE L.postnaam  
            END AS 'Delivery_city',

            CASE
                WHEN A.trn__srt='1'
                THEN C.dienst__
                ELSE L.lev_loc2 
            END AS 'Delivery_department',

            CASE
                WHEN A.trn__srt='1'
                THEN C.straat__
                ELSE L.lev_loc3 
            END AS 'Delivery_street',

            CASE
                WHEN A.trn__srt='1'
                THEN C.county__
                ELSE L.county__ 
            END AS 'Delivery_County',
            CASE
                WHEN A.trn__srt='1'
                THEN C.wijk____
                ELSE L.wijk____
            END AS 'Delivery_District',

            CASE
                WHEN A.trn__srt='1'
                THEN C.telex___
                ELSE L.email___ 
            END AS 'Delivery_email',
            CASE
                WHEN A.trn__srt='1'
                THEN C.telefoon
                ELSE L.telefoon 
            END AS 'Delivery_phone',
            CASE
                WHEN A.trn__srt='1'
                THEN (O.knp__vnm + ' ' + O.knp__nam)
                ELSE (K.knp__vnm + ' ' + K.knp__nam) 
            END AS 'Delivery_contact',
            CASE
                WHEN A.trn__srt='1'
                THEN O.email___
                ELSE K.email___ 
            END AS 'Delivery_contact_email',
            CASE
                WHEN A.trn__srt='1'
                THEN O.tel_auto
                ELSE K.tel_auto 
            END AS 'Delivery_contact_phone' ,


            CASE
                WHEN A.trn__srt='4'
                THEN (O.knp__vnm + ' ' + O.knp__nam)
                ELSE ('') 
            END AS 'Pastomat_Delivery_contact',
            CASE
                WHEN A.trn__srt='4'
                THEN O.email___
                ELSE '' 
            END AS 'Pastomat_Delivery_contact_email',
            CASE
                WHEN A.trn__srt='4'
                THEN O.tel_auto
                ELSE '' 
            END AS 'Pastomat_Delivery_contact_phone' ,                  


            L.handelnr AS ClientCompanyCode,

            
            A.lyn__ref AS lyyn_ref, 
            
            A.uit__lay AS Picking, 
            A.lbn__ref AS PackingSlipFinal, 
            A.l_antpak AS PikedQuontityPacks,
            A.l_antpal AS PikedQuontityPallets,
            A.b_antpak AS OrderedQuontityPacks,
            A.b_antpal AS OrderedQuontityPallets,

            A.levb_dat AS PackingSlipDate,
            A.lvb___ex AS NoOfPicPackingSlip,
            A.lvb__lay AS LayoutPackingSlip,
            A.lvb__ref AS PackingSlipComposedID,
            '----',

            A.kla__ref AS ClientID,


            A.levv_dat,
            A.levvwref,
            A.leverkod,
            A.levb_dat,
            A.levtrcom,
            A.levvodat
            
            
            /*, A.**/
        FROM bstlyn__ AS A
        LEFT JOIN klabas__ AS C ON A.kla__ref = C.kla__ref
        LEFT JOIN levlok__ AS L ON A.lok__ref=L.lok__ref
        LEFT JOIN konper__ AS K ON A.lok__ref=K.lok__ref AND L.lvknpref=K.knp__ref
        LEFT JOIN konpkl__ AS O ON A.kla__ref=O.kla__ref AND A.knp__ref=O.knp__ref

        WHERE A.lbn__ref = '".$SelectedID."'

    ";

        //Nuskaitom NewGam
        
        $mssql = DBMSSqlCERM::getInstance();
        //$RezDuom = $mssql->querySql($qry, 1);
        $RezDuom = $mssql->querySqlOneRow($qry, 1);
        //!!!!!! DEBUG
        //$this->var_dump($RezDuom, "RezDuom <hr>$qry<hr> ");//-----------------DEBUG


        $RefArrayString = $this->getLynRefArray ($RezDuom['bst__ref']);
        $LynRefArrayString = $RefArrayString['LynRefString'];

        //pasiimam svorius
        if($LynRefArrayString){
            /*
            $qryRealSvoriai = "
                select  SUM(lyn__ref_nett) as lyn__ref_nett, SUM(lyn__ref_brutt) as lyn__ref_brutt
                FROM
                    (select sku__ref AS SKU, CONVERT(float, ISNULL(inhoud01,0)) as lyn__ref_nett, CONVERT(float, ISNULL(inhoud02, 0)) as lyn__ref_brutt 
                    from afgsku__ 
                    where  toestand in ('2', '3') AND lyn__ref != '' AND lyn__ref IN (".$LynRefArrayString.")  AND  afg__ref in (select afg__ref from afgart__ where prkl_ref in (select prkl_ref from prodkl__ where omschr_8 = 'ROLLS'))
                    UNION
                    select box__ref AS SKU, CONVERT(float, ISNULL(inhoud01,0)) as 'lyn__ref_nett', CONVERT(float, ISNULL(inhoud02, 0)) as 'lyn__ref_brutt'
                    from afgbox__ 
                    where  box__ref in (select box__ref from afgsku__ where toestand in ('2', '3') AND lyn__ref != '' AND lyn__ref IN (".$LynRefArrayString.") AND  afg__ref in (select afg__ref from afgart__ where prkl_ref in (select prkl_ref from prodkl__ where omschr_8 = 'BOXES')))
                ) A

            ";
            */

            $qryRealSvoriai = "

                select SUM(lbn__ref_brutt) as lbn__ref_brutt
                from (
                select SUM(CONVERT(float, ISNULL(inhoud02,0))) as lbn__ref_brutt
                from afgsku__ 
                where lyn__ref in (
                  select lyn__ref
                  from bstlyn__
                  where lbn__ref = '".$RezDuom['PackingSlip']."' and afg__ref in (select afg__ref from afgart__ where prkl_ref in (select prkl_ref from prodkl__ where omschr_8 = 'ROLLS')))
                UNION
                select SUM(CONVERT(float, ISNULL(inhoud02,0))) as lbn__ref_brutt
                from afgbox__ 
                where box__ref in (
                  select box__ref 
                  from afgsku__
                  where lyn__ref in (
                    select lyn__ref
                    from bstlyn__
                    where lbn__ref = '".$RezDuom['PackingSlip']."' and afg__ref in (select afg__ref from afgart__ where prkl_ref in (select prkl_ref from prodkl__ where omschr_8 = 'BOXES'))))) A            
            ";


            //Nuskaitom NewGam
            
            //$mssql = DBMSSqlCERM::getInstance();
            $RezDuomSvoriai = $mssql->querySqlOneRow($qryRealSvoriai, 1);

            $qrySvorioKorekc = "
                select top 1 extgew__/1000 AS SvorioKorekcija from bstlyn__ where lbn__ref = '".$RezDuom['PackingSlip']."'
            ";
            $RezDuomSvoriaiKorekcija = $mssql->querySqlOneRow($qrySvorioKorekc, 1);

            //!!!!!! DEBUG
            //$this->var_dump($RezDuomSvoriai, "RezDuomSvoriai <hr>$qryRealSvoriai<hr> ");//-----------------DEBUG

            $RezDuomSvoriai['SvorioKorekcija']=$RezDuomSvoriaiKorekcija['SvorioKorekcija'];
            $RezDuomSvoriai['GalutinisBrutto']=$RezDuomSvoriai['lbn__ref_brutt'] + $RezDuomSvoriaiKorekcija['SvorioKorekcija'];
        }//end if


        $RezDuom['SVORIAI'] = $RezDuomSvoriai;
        $RezDuom['JOBS'] = $RefArrayString['OrdRefString'];
        $RezDuom['GAMS'] = $RefArrayString['ProdRefString'];
        //!!!!!! DEBUG
        //$this->var_dump($RezDuom, "RezDuom <hr>$qry<hr> ");//-----------------DEBUG



    }

    return $RezDuom;
}//end function





public function getPackCERMData($PackingSlipArray){

        $PackingSlipStrArray = "'" . implode("','", $PackingSlipArray)."'";

        $qry = "
            SELECT TOP 1000
                A.lyn__ref,
                A.lbn__ref AS PackingSlip,
                /*'1111' AS PackingSlip,*/ /* NEUTRAL TEST cia tik neutralumo testavimui */
                A.vrz__tst AS Shipped, /* 0-NotApplicable; 1-Not yet ready tro ship, N-ToDoo, Y-Done, Z-Returned */
                A.lev__tst AS DeliveryStatus, /* N-Not delivered */
                A.fac__tst AS InvoiceStatus, /* 0- Not yet invoiced; N- To invoice; W- In process, Y - Invoiced */
                A.levb_dat,
                A.bst__ref,
                A.ord__ref, 
                A.afg__ref,

                /* ShiptmentDelivery datos 20210719 pagal JIRA SCHENKER siuntos tipui nustatyti */
                A.vrzv_dat AS ExpectedShipmentDate,
                A.vrzv_uur AS ExpectedShipmentTime,
                A.levv_dat AS ExpectedDeliveryDate,
                A.levv_uur AS ExpectedDeliveryTime,
                
                C.naam____ AS ClientName,
                /* LS, 2LS */
                C.kla__ref AS LS_ClientID,
                C.straat__ AS LS_Street,
                C.land_ref AS LS_LandRef,
                C.county__ AS LS_Gyvenviete, /*Apskritis*/
                C.post_ref AS LS_PostCode,
                C.postnaam AS LS_Miestas,
                C.telefoon AS LS_Telefonas,
                C.telefax_ AS LS_Faksas,
                C.telex___ AS LS_Email,
                (O.knp__vnm + ' ' + O.knp__nam) AS LS_Contact,
                O.email___ AS LS_ContactEmail,
                O.tel_auto AS LS_ContactPhone,


                CASE
                    WHEN A.tstval03='1000' THEN 'KEG'
                    WHEN A.tstval03='2000' THEN 'KPG'
                    WHEN A.tstval03='3000' THEN 'ETK1'
                    ELSE 'Unknown'
                END AS 'ShippedFrom',

                A.lok__ref AS 'Delivery_CompanyID',

                CASE
                    WHEN A.trn__srt='1'
                    THEN C.naam____
                    ELSE L.lev_loc1 
                END AS 'Delivery_Company',

                 L.handelnr AS ClientCompanyCode,

                A.lev__ref as TransporterID,
                A.lev__rpn AS TransporterKeyword,
                left(convert(char,A.vrzv_dat,120),10) AS 'Expected_Shipment_Date',
                left(convert(char,A.levv_dat,120),10) AS 'Expected_Delivery_Date',

                A.aant_pak AS 'Packs_picked',
                A.aant_pal AS 'Pallets_picked',
                A.lbn__com AS 'Packing_slip_comment',
                A.levtrcom AS 'Delivery_comment',
                A.trn__srt AS 'Delivery_type',  /* 0 - pristatoma į AURIKA sandėlį, 1 - pristatoma kliento pagrindiniu adresu,  2,3,4 - pristatoma kliento adresu */
                /* A.lok__ref AS 'Delivery_AddressID',*/
                CASE
                    WHEN A.trn__srt='1'
                    THEN C.kla__ref
                    ELSE L.lok__ref  
                END AS 'Delivery_AddressID',

                CASE
                    WHEN A.trn__srt='1'
                    THEN C.land_ref
                    ELSE L.land_ref  
                END AS 'Delivery_country_code',
                CASE
                    WHEN A.trn__srt='1'
                    THEN C.post_ref
                    ELSE L.post_ref  
                END AS 'Delivery_post',
                CASE
                    WHEN A.trn__srt='1'
                    THEN C.postnaam
                    ELSE L.postnaam  
                END AS 'Delivery_city',

                CASE
                    WHEN A.trn__srt='1'
                    THEN C.dienst__
                    ELSE L.lev_loc2 
                END AS 'Delivery_department', /* visada eina pries street */

                CASE
                    WHEN A.trn__srt='1'
                    THEN C.straat__
                    ELSE L.lev_loc3 
                END AS 'Delivery_street',

                CASE
                    WHEN A.trn__srt='1'
                    THEN C.county__
                    ELSE L.county__ 
                END AS 'Delivery_County',
                CASE
                    WHEN A.trn__srt='1'
                    THEN C.wijk____
                    ELSE L.wijk____
                END AS 'Delivery_District',

                CASE
                    WHEN A.trn__srt='1'
                    THEN C.telex___
                    ELSE L.email___ 
                END AS 'Delivery_email',
                CASE
                    WHEN A.trn__srt='1'
                    THEN C.telefoon
                    ELSE L.telefoon 
                END AS 'Delivery_phone',
                CASE
                    WHEN A.trn__srt='1'
                    THEN (O.knp__vnm + ' ' + O.knp__nam)
                    ELSE (K.knp__vnm + ' ' + K.knp__nam) 
                END AS 'Delivery_contact',
                CASE
                    WHEN A.trn__srt='1'
                    THEN O.email___
                    ELSE K.email___  + ' ' + K.emailpkp
                END AS 'Delivery_contact_email',
                CASE
                    WHEN A.trn__srt='1'
                    THEN O.tel_auto
                    ELSE K.telefoon + ' ' + K.tel_auto  + ' ' + K.tel__pkp
                END AS 'Delivery_contact_phone' ,

                CASE
                    WHEN A.trn__srt='4'
                    THEN (O.knp__vnm + ' ' + O.knp__nam)
                    ELSE ('') 
                END AS 'Pastomat_Delivery_contact',
                CASE
                    WHEN A.trn__srt='4'
                    THEN O.email___
                    ELSE '' 
                END AS 'Pastomat_Delivery_contact_email',
                CASE
                    WHEN A.trn__srt='4'
                    THEN O.tel_auto
                    ELSE '' 
                END AS 'Pastomat_Delivery_contact_phone' ,                  

               
                A.uit__lay AS Picking, 
                A.lbn__ref AS PackingSlipFinal, 
                A.l_antpak AS PikedQuontityPacks,
                A.l_antpal AS PikedQuontityPallets,
                A.b_antpak AS OrderedQuontityPacks,
                A.b_antpal AS OrderedQuontityPallets,

                A.levb_dat AS PackingSlipDate,
                A.lvb___ex AS NoOfPicPackingSlip,
                A.lvb__lay AS LayoutPackingSlip,
                A.lvb__ref AS PackingSlipComposedID,

                /* PRODUCT DATE */
                P.afg_oms1 AS ProductName,
                P.kla__ref AS ProdClientID,
                P.kla__rpn AS ProdClientKey,
                P.commkern AS ProdComment,

                /* NEUTRALUMO DUOMENYS */
                A.lok__ref, 
                A.knplkref, 
                A.knp__ref, 
                A.kla__ref,

                /* Expres ir 10/12 val */
                E.tekst_31 AS Express, /*express if Y */
                E.prod_tyd AS PristatymasIki, /* if 10-iki 10 val, 12- iki 12 val */
                -- '12' AS PristatymasIki, /* if 10-iki 10 val, 12- iki 12 val */

                /* 10/12prie kliento, Liftas, 4 rankos */
                /* Apra6ymas https://conf.aurika.lt/pages/viewpage.action?pageId=70303881 */
                L.trncom_1 AS PristatymasIkiPagalAdr, /* 10/12 prie kliento, turi mazesni prioriteta nei aukciau esantis E.prod_tyd AS PristatymasIki, */
                L.trncom_2 AS Liftas, /* Gali buti tik 'Liftas' arba 'liftas' */
                L.trncom_3 AS KetRankos /* Gali buti tik '4 rankos' */

                /*, A.**/
            FROM bstlyn__ AS A
            LEFT JOIN klabas__ AS C ON A.kla__ref = C.kla__ref
            LEFT JOIN levlok__ AS L ON A.lok__ref=L.lok__ref
            LEFT JOIN afgart__ AS P ON A.afg__ref=P.afg__ref
            /* LEFT JOIN konper__ AS K ON A.lok__ref=K.lok__ref AND L.lvknpref=K.knp__ref */
            LEFT JOIN konper__ AS K ON A.lok__ref=K.lok__ref AND A.knplkref=K.knp__ref
            LEFT JOIN konpkl__ AS O ON A.kla__ref=O.kla__ref AND A.knp__ref=O.knp__ref
            LEFT JOIN bstext__ AS E ON A.lyn__ref = E.lyn__ref

            WHERE A.lbn__ref IN (".$PackingSlipStrArray.") 
            /* WHERE A.bst__ref IN ('309570')*/  /* 2LS neutralumo testavimas */
            /*WHERE A.bst__ref IN ('307324')*/   /* LS neutralumo testavimas */
            

        ";

            //Nuskaitom NewGam
            
            $mssql = DBMSSqlCERM::getInstance();
            $RezDuomTmp = $mssql->querySql($qry, 1);


            //!!!!!! DEBUG
            $this->var_dump($RezDuomTmp, "RezDuom <hr>$qry<hr> ");//-----------------DEBUG

    return  $RezDuomTmp;

}//end function



public function getPackNAVData($PackingSlipArray){


    if($PackingSlipArray){
            $PackingSlipStrArray = "'" . implode("','", $PackingSlipArray)."'";

            //var_dump ($PackingSlipStrArray);

            $mssqlNAV = DBMSSqlNAV::getInstance();



            $qryP = "
                SELECT TOP 100 
                      'ETK' AS FromSystem
                      ,H.[Document Type] /*-> 1 */
                      ,H.[No_] AS 'PackingSlip' /* -> Užsakymo NR */
                      ,'' AS 'Invoice' /* -> Užsakymo NR naujas po Orderio uzdarymo*/
                      ,CONVERT(DATE, H.[Shipment Date]) AS 'Expected_Shipment_Date'/* -> Išvežimo data */
                      ,CONVERT(DATE, H.[Shipment Date]) AS 'Expected_Delivery_Date'/* -> Išvežimo data */

                      ,H.[No_] AS 'bst__ref' 

                      ,H.[Bill-to Name] AS 'ClientName'/* -> Kliento pavadinimas */
                      ,H.[Bill-to Customer No_] AS 'ClientID'/*-> Kliento ID */
                      ,'ETK' AS 'ShippedFrom'
                      ,H.[Location Code] AS 'Sandelys_NAV'/* sandelys */
                      ,CONCAT(H.[Ship-to Name],' ', H.[Ship-to Name 2]) AS 'Delivery_Company'
                      ,H.[Bill-to Customer No_] AS 'Delivery_CompanyID'/*-> Kliento ID */

                      ,H.[Shipment Method Code] AS 'TransporterKeyword'
                      ,1 AS 'Packs_picked'
                      ,0 AS 'Pallets_picked'
                      ,1 AS 'PikedQuontityPacks'
                      ,0 AS 'PikedQuontityPallets'
                      ,1 AS 'OrderedQuontityPacks'
                      ,0 AS 'OrderedQuontityPallets'
                      ,'' AS 'Packing_slip_comment'
                      ,'' AS 'DeliveryComment'
                      ,'' AS 'CommentAfterDelivery'
                      ,'' AS 'Delivery_type'
                      ,'' AS 'Delivery_AddressID'
                      ,H.[Ship-to Country_Region Code] AS 'Delivery_country_code'/* -> Pristatymo salies kodas */
                      ,'' AS 'Delivery_County'/* -> Pristatymo salies kodas */
                      ,'' AS 'Delivery_District'
                      ,H.[Ship-to Post Code] AS 'Delivery_post'/* -> Pristatymo pasto kodas */
                      ,H.[Ship-to City] AS 'Delivery_city' /* -> Pristatymo miestas */
                      /*,CONCAT( H.[Ship-to Address], ' ', H.[Ship-to Address 2] ) AS 'Delivery_street'*/
                      ,H.[Ship-to Address] AS 'Delivery_street'
                      ,H.[Ship-to Address 2]  AS 'Delivery_PickUp_ID'


                      ,H.[Sell-to E-Mail] AS 'Delivery_email'/* -> el. Paštas (būtina) */
                      ,H.[Sell-to Phone No_] AS 'Delivery_phone'/* -> Kliento kontaktinis Tel. Nr; Gavėjo asmens Tel Nr */
                      ,'' AS 'Delivery_contact'
                      ,'' AS 'Delivery_contact_email'
                      ,'' AS 'Delivery_contact_phone'
                      ,'' AS 'Delivery_department'
                      ,'' AS 'PackingSlipDate'
                      ,'' AS 'PackingSlipComposedID'
                      ,H.[Your Reference] /* Galima pildyti kaip papildomą info */
                      
                      /* -> Numatomas vežėjas */
                      ,H.[Status] AS 'RedyToShip'/* -> 1 Laukas pažymintis, kad užsakymą galima siųsti (paruoštas siuntimui) */

                      /* Neutralumo duomenys*/
                       ,'' AS lok__ref
                        ,'' AS knplkref
                        ,'' AS knp__ref 
                        ,'' AS kla__ref

                        /* Expres ir 10/12 val */
                        ,'' AS Express /*express if Y */
                        ,'' AS PristatymasIki /* if 10-iki 10 val, 12- iki 12 val */

                        /* 10/12prie kliento, Liftas, 4 rankos */
                        /* Apra6ymas https://conf.aurika.lt/pages/viewpage.action?pageId=70303881 */
                        ,'' AS PristatymasIkiPagalAdr /* 10/12 prie kliento, turi mazesni prioriteta nei aukciau esantis E.prod_tyd AS PristatymasIki, */
                        ,'' AS Liftas /* Gali buti tik 'Liftas' arba 'liftas' */
                        ,'' AS KetRankos /* Gali buti tik '4 rankos' */

                      
                      /* ,'-------' */
                      ,COUNT(H.[No_]) AS ProdKiekisNAV
                      ,SUM(L.[Gross Weight]) AS SUM_Gross /*-> Svoris brutto*/
                      ,SUM(L.[Net Weight]) AS SUM_Net/*-> Svoris netto   */
                      ,'32' AS 'Plotis' /* Visada vienodas, nes nera duomenu apie dezutes matmenys */
                      ,'23.5' AS 'Ilgis'
                      ,'19' AS 'Aukstis'
                      /* ,'-------' */
                      ,S.[APGDVSSendToDVS] /*-> Išsiųsta į DVS*/
                      ,S.[APGDVSSendToDVSDateTime] /*-> Išsiųsta į DVS data laikas  */
                      ,S.[APGDVSTerminaCode] AS Terminal_Code /* Terminalo ID */
                      ,AD.[Address 2] AS TerminalImCode /* Terminalo imones kodas, ji reikia irasyti i XML jeigu siunciama per terminala vietoje imones kodo*/
                      /* ,'-------' */
                      /* ,* */
                  FROM [AURIKA CERM\$Sales Header] AS H
                  LEFT JOIN [AURIKA CERM\$Sales Line] AS L ON H.[Document Type] = L.[Document Type] AND H.[No_] = L.[Document No_]
                  LEFT JOIN [AURIKA CERM\$Sales Header\$478bcd1e-cac5-4def-9017-2ecd670bc386] AS S ON H.[Document Type] = S.[Document Type] AND H.[No_] = S.[No_]
                  LEFT JOIN [AURIKA CERM\$Ship-to Address] AS AD ON AD.[Customer No_]='VENIPAK_TERMINAL' AND AD.[Code]=S.[APGDVSTerminaCode]
                  WHERE 
                    /* 
                                        H.[No_] LIKE 'UZS%'
                    AND [Status] = 1 
                    AND H.[Shipment Method Code] != 'PASIIMA'
                    AND 
                    */
                                        /* H.No_ IN ('UZS024280','UZS024373') */
                    H.[No_] IN (".$PackingSlipStrArray.") 


                  GROUP BY 
                        H.[Document Type]
                        ,H.[No_]
                        ,H.[Bill-to Customer No_]
                        ,H.[Bill-to Name] /* -> Kliento pavadinimas */
                        ,H.[Sell-to Phone No_] /* -> Kliento kontaktinis Tel. Nr; Gavėjo asmens Tel Nr */
                        ,H.[Sell-to E-Mail] /* -> el. Paštas (būtina) */
                        ,H.[Your Reference] /* Galima pildyti kaip papildomą info */
                        ,H.[Ship-to Name] /* -> Gavėjo asmens Vardas */
                        ,H.[Ship-to Name 2]
                        ,H.[Ship-to Address] /* -> Pristatymo adresas (gatve, namo nr,...)*/
                        ,H.[Ship-to Address 2]
                        ,H.[Ship-to City] /* -> Pristatymo miestas */
                        ,H.[Ship-to Post Code] /* -> Pristatymo pasto kodas */
                        ,H.[Ship-to Country_Region Code] /* -> Pristatymo salies kodas */

                        ,H.[Shipment Date] /* -> Išvežimo data */
                        ,H.[Shipment Method Code] /* -> Numatomas vežėjas */
                        ,H.[Status] /* -> 1 Laukas pažymintis, kad užsakymą galima siųsti (paruoštas siuntimui) */
                        ,H.[Location Code] /* sandelys */
                      
                        /*
                        ,'Plotis' 
                        ,'Ilgis'  
                        ,'Aukstis'
                        */
                      
                        ,S.[APGDVSSendToDVS] /*-> Išsiųsta į DVS*/
                        ,S.[APGDVSSendToDVSDateTime] /*-> Išsiųsta į DVS data laikas  */
                        ,S.[APGDVSTerminaCode]
                        ,AD.[Address 2]


UNION


                SELECT TOP 100 
                      'ETK' AS FromSystem
                      ,'1' AS [Document Type] /*-> 1 */
                      ,H.[Order No_] AS 'PackingSlip' /* -> Užsakymo NR */
                      ,H.[No_] AS 'Invoice' /* -> Užsakymo NR naujas po Orderio uzdarymo*/
                      ,CONVERT(DATE, H.[Shipment Date]) AS 'Expected_Shipment_Date'/* -> Išvežimo data */
                      ,CONVERT(DATE, H.[Shipment Date]) AS 'Expected_Delivery_Date'/* -> Išvežimo data */

                      ,H.[No_] AS 'bst__ref' 

                      ,H.[Bill-to Name] AS 'ClientName'/* -> Kliento pavadinimas */
                      ,H.[Bill-to Customer No_] AS 'ClientID'/*-> Kliento ID */
                      ,'ETK' AS 'ShippedFrom'
                      ,H.[Location Code] AS 'Sandelys_NAV'/* sandelys */
                      ,CONCAT(H.[Ship-to Name],' ', H.[Ship-to Name 2]) AS 'Delivery_Company'
                      ,H.[Bill-to Customer No_] AS 'Delivery_CompanyID'/*-> Kliento ID */

                      ,H.[Shipment Method Code] AS 'TransporterKeyword'
                      ,1 AS 'Packs_picked'
                      ,0 AS 'Pallets_picked'
                      ,1 AS 'PikedQuontityPacks'
                      ,0 AS 'PikedQuontityPallets'
                      ,1 AS 'OrderedQuontityPacks'
                      ,0 AS 'OrderedQuontityPallets'
                      ,'' AS 'Packing_slip_comment'
                      ,'' AS 'DeliveryComment'
                      ,'' AS 'CommentAfterDelivery'
                      ,'' AS 'Delivery_type'
                      ,'' AS 'Delivery_AddressID'
                      ,H.[Ship-to Country_Region Code] AS 'Delivery_country_code'/* -> Pristatymo salies kodas */
                      ,'' AS 'Delivery_County'/* -> Pristatymo salies kodas */
                      ,'' AS 'Delivery_District'
                      ,H.[Ship-to Post Code] AS 'Delivery_post'/* -> Pristatymo pasto kodas */
                      ,H.[Ship-to City] AS 'Delivery_city' /* -> Pristatymo miestas */
                      /*,CONCAT( H.[Ship-to Address], ' ', H.[Ship-to Address 2] ) AS 'Delivery_street'*/
                      ,H.[Ship-to Address] AS 'Delivery_street'
                      ,H.[Ship-to Address 2]  AS 'Delivery_PickUp_ID'


                      ,H.[Sell-to E-Mail] AS 'Delivery_email'/* -> el. Paštas (būtina) */
                      ,H.[Sell-to Phone No_] AS 'Delivery_phone'/* -> Kliento kontaktinis Tel. Nr; Gavėjo asmens Tel Nr */
                      ,'' AS 'Delivery_contact'
                      ,'' AS 'Delivery_contact_email'
                      ,'' AS 'Delivery_contact_phone'
                      ,'' AS 'Delivery_department'
                      ,'' AS 'PackingSlipDate'
                      ,'' AS 'PackingSlipComposedID'
                      ,H.[Your Reference] /* Galima pildyti kaip papildomą info */
                      
                      /* -> Numatomas vežėjas */
                      ,'1' AS 'RedyToShip'/* -> 1 Laukas pažymintis, kad užsakymą galima siųsti (paruoštas siuntimui) */

                      /* Neutralumo duomenys*/
                       ,'' AS lok__ref
                        ,'' AS knplkref
                        ,'' AS knp__ref 
                        ,'' AS kla__ref

                        /* Expres ir 10/12 val */
                        ,'' AS Express /*express if Y */
                        ,'' AS PristatymasIki /* if 10-iki 10 val, 12- iki 12 val */

                        /* 10/12prie kliento, Liftas, 4 rankos */
                        /* Apra6ymas https://conf.aurika.lt/pages/viewpage.action?pageId=70303881 */
                        ,'' AS PristatymasIkiPagalAdr /* 10/12 prie kliento, turi mazesni prioriteta nei aukciau esantis E.prod_tyd AS PristatymasIki, */
                        ,'' AS Liftas /* Gali buti tik 'Liftas' arba 'liftas' */
                        ,'' AS KetRankos /* Gali buti tik '4 rankos' */

                      
                      /* ,'-------' */
                      ,COUNT(H.[No_]) AS ProdKiekisNAV
                      ,SUM(L.[Gross Weight]) AS SUM_Gross /*-> Svoris brutto*/
                      ,SUM(L.[Net Weight]) AS SUM_Net/*-> Svoris netto   */
                      ,'32' AS 'Plotis' /* Visada vienodas, nes nera duomenu apie dezutes matmenys */
                      ,'23.5' AS 'Ilgis'
                      ,'19' AS 'Aukstis'
                      /* ,'-------' */
                      ,S.[APGDVSSendToDVS] /*-> Išsiųsta į DVS*/
                      ,S.[APGDVSSendToDVSDateTime] /*-> Išsiųsta į DVS data laikas  */
                      ,S.[APGDVSTerminaCode] AS Terminal_Code /* Terminalo ID */
                      ,AD.[Address 2] AS TerminalImCode /* Terminalo imones kodas, ji reikia irasyti i XML jeigu siunciama per terminala vietoje imones kodo*/
                      /* ,'-------' */
                      /* ,* */
                  FROM [AURIKA CERM\$Sales Invoice Header] AS H
                  LEFT JOIN [AURIKA CERM\$Sales Invoice Line] AS L ON  H.[No_] = L.[Document No_]
                  LEFT JOIN [AURIKA CERM\$Sales Invoice Header\$478bcd1e-cac5-4def-9017-2ecd670bc386] AS S ON H.[No_] = S.[No_]
                  LEFT JOIN [AURIKA CERM\$Ship-to Address] AS AD ON AD.[Customer No_]='VENIPAK_TERMINAL' AND AD.[Code]=S.[APGDVSTerminaCode]
                  WHERE 
                    
                   /* H.[Order No_] IN ('UZS024287','UZS024373','UZS024369') */
                    H.[Order No_] IN (".$PackingSlipStrArray.") 

                  GROUP BY 
                                                H.[Order No_]
                        ,H.[No_]
                        ,H.[Bill-to Customer No_]
                        ,H.[Bill-to Name] /* -> Kliento pavadinimas */
                        ,H.[Sell-to Phone No_] /* -> Kliento kontaktinis Tel. Nr; Gavėjo asmens Tel Nr */
                        ,H.[Sell-to E-Mail] /* -> el. Paštas (būtina) */
                        ,H.[Your Reference] /* Galima pildyti kaip papildomą info */
                        ,H.[Ship-to Name] /* -> Gavėjo asmens Vardas */
                        ,H.[Ship-to Name 2]
                        ,H.[Ship-to Address] /* -> Pristatymo adresas (gatve, namo nr,...)*/
                        ,H.[Ship-to Address 2]
                        ,H.[Ship-to City] /* -> Pristatymo miestas */
                        ,H.[Ship-to Post Code] /* -> Pristatymo pasto kodas */
                        ,H.[Ship-to Country_Region Code] /* -> Pristatymo salies kodas */

                        ,H.[Shipment Date] /* -> Išvežimo data */
                        ,H.[Shipment Method Code] /* -> Numatomas vežėjas */
                        
                        ,H.[Location Code] /* sandelys */
                      
                        /*
                        ,'Plotis' 
                        ,'Ilgis'  
                        ,'Aukstis'
                        */
                      
                        ,S.[APGDVSSendToDVS] /*-> Išsiųsta į DVS*/
                        ,S.[APGDVSSendToDVSDateTime] /*-> Išsiųsta į DVS data laikas  */
                        ,S.[APGDVSTerminaCode]
                        ,AD.[Address 2]

                      

                ";
            $RezDuomTmp = $mssqlNAV->querySql($qryP, 1);

             //var_dump ($qryP);

            //jeigu tai siunta i pastomata, tai sukeiciam imones koda i pickup koda
            if($RezDuomTmp){
                foreach ($RezDuomTmp as $key => $value) {
                    if($value['TransporterKeyword']=='PICKUP VEN'){
                        $RezDuomTmp[$key]['Delivery_CompanyID']=$value['Delivery_PickUp_ID'];
                    }//end if
                }//end foreach
            }//end if

            //!!!!!! DEBUG
            //$this->var_dump($RezDuomTmp, "RezDuomTmpNAV <hr>$qry<hr> ");//-----------------DEBUG


    }else{
        $RezDuomTmp = array();
    }

            //!!!!!! DEBUG
            //$this->var_dump($RezDuomTmp, "RezDuomTmpNAV <hr>$qry<hr> ");//-----------------DEBUG


    return $RezDuomTmp;
    
}//end function





/*20190925 A. Ramonas

*/
public function getPackData($PackingSlipArray){
    $RezDuom = array();

    var_dump($PackingSlipArray);

    if($PackingSlipArray){

        //tikrinam ar CERM ar NAVISION ir atitinkamai paimam nuskaitymo funkcija

        $CERMDB = 0;//kiek yra CERM ir kiek pairinkta siuntu is NAV
        $NAVDB = 0;
        foreach ($PackingSlipArray as $key => $value1) {
            if(substr($value1, 0, 3)=='UZS'){$NAVDB++;}
            if(is_numeric(substr($value1, 0, 3))){$CERMDB++;}
        }//end foreach


        //TIKRINAM AR REIKIA SURINKTI DUOMENYS IS VIENO SANDELIO PACKINGSLIPU, JEIGU IS SKIRTINGU, TAI RASOM< KAD KLAIDA
        //Jeigu is vieno sandelio visi packing slipai, tai nusiskaitom duomenis (Array)
        $SkirtingosDB = 'OK'; //pradine reiksme
        if($CERMDB>0 AND $NAVDB==0){
            //kreipiames i duomenu nuskaityma is CERM DB
            $RezDuomTmp = '';
            $RezDuomTmp = $this->getPackCERMData($PackingSlipArray);
        }elseif($CERMDB==0 AND $NAVDB>0){
            //kreipiames i duomenu nuskaityma is NAVISION DB
            $RezDuomTmp = $this->getPackNAVData($PackingSlipArray);
        }elseif($CERMDB>0 AND $NAVDB>0){
            //KLAIDA, pasirinktos siuntos is skirtingu DB
            $SkirtingosDB = 'ERROR1'; //parinktos siuntos is skirtingu sandeliu ir DB, taip negali buti
        }elseif($CERMDB==0 AND $NAVDB==0){
            //KLAIDA - nepasirinkta nei viena tinkama siunta
            $SkirtingosDB = 'ERROR2'; //nepasirinkta nei viena siunta su zinomu sandeliu
        }else{
            //KITA KLAIDA
            $SkirtingosDB = 'ERROR3'; //nezinomas atvejis
        }

        //echo "**********************$CERMDB*** $NAVDB ****************";
        //!!!!!! DEBUG
        $this->var_dump($RezDuomTmp, "RezDuomTmp////// <hr>$qryNeutral<hr> ");//-----------------DEBUG



            /* tvarkom struktura */
            $OrderList = array();
            $PackSlipStr = "";
            $VezejasStr = "";
            $ClientStr = "";
            $AdreasasStr = "";
            $ShipmentDateStr = "";
            $ShipmentFromStr = "";
            $YraKlaidu = "N";
            $KlaidaComment = "";

            $TransporterID = '';
            $ClientID = '';
            $Delivery_CompanyID = '';
            $Delivery_AddressID = '';
            $Delivery_country_code = '';
            $Delivery_city = '';
            $Delivery_post = '';

            $knplkref = ""; //neutralumui (LS 2LS) nustatyti kai schenker
            $n=0;
            $Adresai['NeutralumasYra'] = 'N';// '', 'LS', '2LS'
            

            $express = "N";
            $laikaiArray = array('10','12');
            $pristatytiIki = "";
            $PristatymasIkiPagalAdr =""; /* 10/12 prie kliento, turi mazesni prioriteta nei aukciau esantis E.prod_tyd AS PristatymasIki, */
            $Liftas = ""; /* Gali buti tik 'Liftas' arba 'liftas' */
            $KetRankos = ""; /* Gali buti tik '4 rankos' */

            $PristaLaikasDarboDienomis = 99; //pradine reiksme [agal tai skaiciuosis koki pristatymo varianta rinktis schenkeriui]

//echo "<hr> $SkirtingosDB == 'OK' <br><hr>";

            if($RezDuomTmp AND $SkirtingosDB == 'OK'){

                $SOArray = array();
                foreach ($RezDuomTmp as $key => $OrdDate) {
                    $KlaidaCommentTmp="";

                    //pazymim, jeigu bent viena siunta kaip express
                    if(strtoupper($OrdDate['Express']) == 'Y'){
                        $express = "Y";
                    }


                    //Kai nuriems klientams visada pristatymo adresas yra iki 10 val
                        //toliau pazymim, jeigu bent viena siunta turi pristatymo laika iki kada pristatyti /10, 12,...
                        //warning jei pristatymo adrese taip pat yra suvestas pristatymo laikas, pristatymo laikas imamas pagal Sales Order kortelės informaciją !!!  (bstext__.prod_tyd)

                    $visadaIki10Val = array(108656, 109443, 109197, 109724, 109801, 109514, 109727, 109272, 109726, 109527, 109243, 109156, 108495, 108965, 108540, 109319, 108579, 109051, 109899, 109739, 109464);
                    if(in_array($OrdDate['kla__ref'], $visadaIki10Val)){
                        $pristatytiIki = '10';
                    }else{
                        if(in_array($OrdDate['PristatymasIki'], $laikaiArray)){
                            if (!$pristatytiIki){
                                $pristatytiIki = $OrdDate['PristatymasIki']; //jeigu nebuvo nustatytas pristatymo laikas tai nustatom
                            }elseif($OrdDate['PristatymasIki'] < $pristatytiIki){
                                $pristatytiIki = $OrdDate['PristatymasIki']; //jeigu pristatymo laikas buvo veliau, o atejo su ankstesniu laiku tai isimenam anksciausia laikas ... pvz buvo iki 12 bet sita siunta reikia iki 10, tai isimenam iki 10
                            }
                        }
                    }//end else

                    if (in_array($OrdDate['PristatymasIkiPagalAdr'], $laikaiArray)){//jeigu prie SO nenurodytas pristatymo laikas 10/12 tai ziurim ar nenurodytas prie adreso (zemesnio prioriteto)
                        if (!$PristatymasIkiPagalAdr){
                            $PristatymasIkiPagalAdr = $OrdDate['PristatymasIkiPagalAdr']; //jeigu nebuvo nustatytas pristatymo laikas tai nustatom
                        }elseif($OrdDate['PristatymasIkiPagalAdr'] < $PristatymasIkiPagalAdr){
                            $PristatymasIkiPagalAdr = $OrdDate['PristatymasIkiPagalAdr']; //jeigu pristatymo laikas buvo veliau, o atejo su ankstesniu laiku tai isimenam anksciausia laikas ... pvz buvo iki 12 bet sita siunta reikia iki 10, tai isimenam iki 10
                        }
                    }


                    if(strtoupper($OrdDate['Liftas']) == 'LIFTAS'){
                        $Liftas = "Y";
                    }

                    if(strtoupper($OrdDate['KetRankos']) == '4 RANKOS'){
                        $KetRankos = "Y";
                    }

                    /* ShiptmentDelivery datos 20210719 pagal JIRA SCHENKER siuntos tipui nustatyti */
                    /*
                    A.vrzv_dat AS ExpectedShipmentDate,
                    A.vrzv_uur AS ExpectedShipmentTime,
                    A.levv_dat AS ExpectedDeliveryDate,
                    A.levv_uur AS ExpectedDeliveryTime,
                    */

                    //TAG20210721
                    if($OrdDate['ShippedFrom']=='ETK'){//Jeigu is sandelio etikete.lt (is NAVISION) tai nustatom max dienu
                        $PristaLaikasDarboDienomis = 9;// defaultinis didelis dienu skaicius
                    }else{
                        $PristaLaikasDarboDienomisTmp = $this->number_of_working_days($OrdDate['ExpectedShipmentDate'], $OrdDate['ExpectedDeliveryDate']);
                        if($PristaLaikasDarboDienomisTmp<$PristaLaikasDarboDienomis){
                            $PristaLaikasDarboDienomis = $PristaLaikasDarboDienomisTmp; //pasiimam trumpiausia laika is visu SO prie sio siuntinio
                        }
                    }//end else

                    //echo "<br>+-+-+-+-+-".$PristaLaikasDarboDienomis."+-+-+-+-<br>";



                    //TIKRINAM NEUTRALUMA LS IR 2LS
                    /*
                    A.lok__ref, 
                    A.knplkref, 
                    A.knp__ref, 
                    A.kla__ref
                    */         

                    /* SUTVARKOM ADRESA ... departamentus, rajonus, apylinkes 
                        department->street-> district (wijk___)-> city->  county (county___ )-> country code-> post code
                    */
                    /* DEPARTMENT VISADA EINA PRIES STREET 20200630 Editos email */
                    if($OrdDate['Delivery_department']){
                        $OrdDate['Delivery_street'] = $OrdDate['Delivery_department'].', '.$OrdDate['Delivery_street'];
                    }

                    if($OrdDate['Delivery_District']){
                        $OrdDate['Delivery_city'] = $OrdDate['Delivery_District'].', '.$OrdDate['Delivery_city'];
                    }

                    if($OrdDate['Delivery_County']){
                        $OrdDate['Delivery_city'] = $OrdDate['Delivery_city'].', '.$OrdDate['Delivery_County'];
                    }

                    
                    //pasiimam duomenys neutralumo nustatymui knp__nam ir kitus kuriu reikes, jeigu bus 2LS
                    if($OrdDate['lok__ref'] AND $OrdDate['knplkref']){
                        $qryNeutral = "
                            SELECT 
                                knp__nam, /* nustatom ar yra neutralumas LS, 2LS */
                                /* jeigu yra 2LS tai is cia imam siunteja */
                                (lok__ref+'_'+knp__ref) AS LS2_AddressID,
                                straat__ AS LS2_street,
                                land_ref AS LS2_CountryCode,
                                county__ AS LS2_Country, /*Apskritis*/
                                state___ AS LS2_State,
                                post_ref AS LS2_PostCode,
                                wijk____ AS LS2_District,
                                postnaam AS LS2_City,
                                county__ AS LS2_County,
                                telefoon + ' ' + tel_auto  + ' ' + tel__pkp AS LS2_Tel,
                                telefax_ AS LS2_Fax,
                                email___  + ' ' + emailpkp AS LS2_email,
                                dienst_1 AS LS2_Siuntejas,
                                knp__vnm AS LS2_ContactPerson
                            FROM konper__
                            WHERE lok__ref = '".$OrdDate['lok__ref']."' AND knp__ref = '".$OrdDate['knplkref']."'
                        ";
                        $mssql = DBMSSqlCERM::getInstance();
                        $NeutralumasTmp = $mssql->querySqlOneRow($qryNeutral, 1);

                        /* sutvarkom adresus (rajonus, apylinkes) */
                        if($NeutralumasTmp['LS2_District']){
                            $NeutralumasTmp['LS2_City'] = $NeutralumasTmp['LS2_District'] .', '. $NeutralumasTmp['LS2_City'];
                        }
                        if($NeutralumasTmp['LS2_County']){
                            $NeutralumasTmp['LS2_City'] = $NeutralumasTmp['LS2_City'] .', '. $NeutralumasTmp['LS2_County'];
                        }
                    }else{
                        $NeutralumasTmp = array();
                    }

                    //!!!!!! DEBUG
                    $this->var_dump($NeutralumasTmp, "NeutralumasTmp <hr>$qryNeutral<hr> ");//-----------------DEBUG



                    if($OrdDate['TransporterKeyword']=='PICKUP VEN'){//jeigu is NAV ir nurodyta, kad tai i VENIPAK pastomata
                        $Det_ArIPastomata = 'PICKUP';
                    }else{
                        $Det_ArIPastomata = '';
                    }
                    

                    /* ************* 2LS dvigubas neutralumas ************* */    
                    if(strpos(strtoupper($NeutralumasTmp['knp__nam']),'2LS')!== false){

                        //TURIM DVIGUBA NEUTRALUMA
                        $Adresai['NeutralumasYra'] = '2LS';

                        /* SCHIPER */
                        //siunteja (All4Labels) imam is bstlyn->klabas->contacts
                        $Adresai['SHIPPER']['Yra'] = 'Y';
                        $Adresai['SHIPPER']['contactPerson']['email'] = trim ($NeutralumasTmp['LS2_email']);
                        $Adresai['SHIPPER']['name1'] = $NeutralumasTmp['LS2_Siuntejas'];
                        $Adresai['SHIPPER']['name2'] = '';
                        $Adresai['SHIPPER']['customerAddressIdentifier'] = trim ($NeutralumasTmp['LS2_AddressID']);
                        $Adresai['SHIPPER']['email'] = trim ($NeutralumasTmp['LS2_email']);
                        $Adresai['SHIPPER']['fax'] = trim ($NeutralumasTmp['LS2_Fax']);
                        $Adresai['SHIPPER']['industry'] = "AUTOMOTIVE";
                        $Adresai['SHIPPER']['locationType'] = "PHYSICAL";
                        $Adresai['SHIPPER']['mobilePhone'] = trim ($NeutralumasTmp['LS2_Tel']);
                        $Adresai['SHIPPER']['personType']="COMPANY"; // COMPANY, PERSON
                        $Adresai['SHIPPER']['phone'] = trim ($NeutralumasTmp['LS2_Tel']);
                        $Adresai['SHIPPER']['poBox']="POBOX";
                        $Adresai['SHIPPER']['postalCode'] = trim ($NeutralumasTmp['LS2_PostCode']);
                        $Adresai['SHIPPER']['stateCode'] = ''; /* $NeutralumasTmp['']; */
                        $Adresai['SHIPPER']['stateName'] = ''; /* $NeutralumasTmp['']; */
                        $Adresai['SHIPPER']['preferredLanguage'] = '';
                        $Adresai['SHIPPER']['schenkerAddressId'] = '';
                        $Adresai['SHIPPER']['street'] = $NeutralumasTmp['LS2_street'];
                        $Adresai['SHIPPER']['street2'] = '';
                        $Adresai['SHIPPER']['city'] = $NeutralumasTmp['LS2_City'];
                        $Adresai['SHIPPER']['countryCode'] = trim ($NeutralumasTmp['LS2_CountryCode']);
                        $Adresai['SHIPPER']['type'] = "SHIPPER";//"PICKUP"
                        $Adresai['SHIPPER']['AdreasasFullStr'] = $Adresai['SHIPPER']['street'].", ".$Adresai['SHIPPER']['city'].", ".$Adresai['SHIPPER']['countryCode'].", ".$Adresai['SHIPPER']['postalCode'];

                        $Adresai['SHIPPER']['tableFrom'] = 'konper__';
                        $Adresai['SHIPPER']['imoneID'] = $NeutralumasTmp['LS2_AddressID'];
                        $Adresai['SHIPPER']['imoneAdresasID'] = $NeutralumasTmp['LS2_AddressID'];


                        /* Musu sandelio adresas*/
                        /*
                        $Adresai['PICKUP']['Yra'] = 'N';
                        $Adresai['PICKUP']['contactPerson']['email'] = '';
                        $Adresai['PICKUP']['name1'] = '';
                        $Adresai['PICKUP']['name2'] = '';
                        $Adresai['PICKUP']['customerAddressIdentifier'] = '';
                        $Adresai['PICKUP']['email'] = '';
                        $Adresai['PICKUP']['fax'] = '';
                        $Adresai['PICKUP']['industry'] = "AUTOMOTIVE";
                        $Adresai['PICKUP']['locationType'] = "PHYSICAL";
                        $Adresai['PICKUP']['mobilePhone'] = '';
                        $Adresai['PICKUP']['customerAddressIdentifier'] = '';
                        $Adresai['PICKUP']['personType']="COMPANY"; // COMPANY, PERSON
                        $Adresai['PICKUP']['phone'] = '';
                        $Adresai['PICKUP']['poBox']="POBOX";
                        $Adresai['PICKUP']['postalCode'] = '';
                        $Adresai['PICKUP']['stateCode'] = '';
                        $Adresai['PICKUP']['stateName'] = '';
                        $Adresai['PICKUP']['preferredLanguage'] = '';
                        $Adresai['PICKUP']['schenkerAddressId'] = '';
                        $Adresai['PICKUP']['street'] = '';
                        $Adresai['PICKUP']['street2'] = '';
                        $Adresai['PICKUP']['city'] = '';
                        $Adresai['PICKUP']['countryCode'] = '';
                        $Adresai['PICKUP']['type'] = "PICKUP";//"PICKUP"
                        */

                        /* Galutinio gavejo adresas (imones)*/
                        if($OrdDate['lok__ref']){

                            $qry2 = "
                                SELECT 
                                    kla__ref AS TevoKlientoID,
                                    lok__ref AS AdresoID, 
                                    lev_loc1 AS ClientName,
                                    lev_loc2 AS ContactPerson,
                                    lev_loc3 AS Street,
                                    wijk____ AS District, /* rajonas */
                                    land_ref AS LandRef,
                                    county__ AS County, /*Apskritis*/
                                    state___ AS State,
                                    post_ref AS PostCode,
                                    postnaam AS City,
                                    telefoon AS Tel,
                                    email___ AS Email
                                    -- , *
                                FROM levlok__
                                -- pvz WHERE lok__ref = '402115'
                                WHERE lok__ref = '".$OrdDate['lok__ref']."'                            
                            ";
                            $ConsigneeAdr = $mssql->querySqlOneRow($qry2, 1);
                            if($ConsigneeAdr){

                                /* sutvarkom adresus (rajonus, apylinkes) */
                                if($ConsigneeAdr['District']){
                                    $ConsigneeAdr['City'] = $ConsigneeAdr['District'] .', '. $ConsigneeAdr['City'];
                                }
                                if($ConsigneeAdr['County']){
                                    $ConsigneeAdr['City'] = $ConsigneeAdr['City'] .', '. $ConsigneeAdr['County'];
                                }


                                $Adresai['CONSIGNEE']['Yra'] = 'Y';

                                $Adresai['CONSIGNEE']['contactPerson']['name'] = $ConsigneeAdr['ContactPerson'];
                                $Adresai['CONSIGNEE']['contactPerson']['email'] = trim ($ConsigneeAdr['Email']);
                                $Adresai['CONSIGNEE']['contactPerson']['phone'] ='';

                                $Adresai['CONSIGNEE']['name1'] = $ConsigneeAdr['ClientName'];
                                $Adresai['CONSIGNEE']['name2'] = '';
                                $Adresai['CONSIGNEE']['customerAddressIdentifier'] = $ConsigneeAdr['AdresoID'];
                                $Adresai['CONSIGNEE']['email'] = trim ($ConsigneeAdr['Email']);
                                $Adresai['CONSIGNEE']['fax'] = '';
                                $Adresai['CONSIGNEE']['industry'] = "AUTOMOTIVE";
                                $Adresai['CONSIGNEE']['locationType'] = "PHYSICAL";
                                $Adresai['CONSIGNEE']['mobilePhone'] = trim ($ConsigneeAdr['Tel']);
                                $Adresai['CONSIGNEE']['personType']="COMPANY"; // COMPANY, PERSON
                                $Adresai['CONSIGNEE']['phone'] = trim ($ConsigneeAdr['Tel']);
                                $Adresai['CONSIGNEE']['poBox']="POBOX";
                                $Adresai['CONSIGNEE']['postalCode'] = trim ($ConsigneeAdr['PostCode']);
                                $Adresai['CONSIGNEE']['stateCode'] = ''; //$ConsigneeAdr[''];
                                $Adresai['CONSIGNEE']['stateName'] = ''; //$ConsigneeAdr['Rajonas'];
                                $Adresai['CONSIGNEE']['preferredLanguage'] = '';
                                $Adresai['CONSIGNEE']['schenkerAddressId'] = '';
                                $Adresai['CONSIGNEE']['street'] = $ConsigneeAdr['Street'];
                                $Adresai['CONSIGNEE']['street2'] = ''; //$ConsigneeAdr['Rajonas'];
                                $Adresai['CONSIGNEE']['city'] = $ConsigneeAdr['City'];
                                $Adresai['CONSIGNEE']['countryCode'] = $ConsigneeAdr['LandRef'];
                                $Adresai['CONSIGNEE']['type'] = "CONSIGNEE";//"PICKUP"

                                $Adresai['CONSIGNEE']['tableFrom'] = 'levlok__';
                                $Adresai['CONSIGNEE']['imoneID'] = $ConsigneeAdr['AdresoID'];
                                $Adresai['CONSIGNEE']['imoneAdresasID'] = $ConsigneeAdr['AdresoID'];


                            }else{
                                $Adresai['CONSIGNEE']['Yra'] = 'N';
                                $Adresai['CONSIGNEE']['tableFrom'] = '';
                                $Adresai['CONSIGNEE']['imoneID'] = '';
                                $Adresai['CONSIGNEE']['imoneAdresasID'] = '';

                            }


                        }else{//
                            //KLAIDA... nera gavejo adreso
                            $Adresai['CONSIGNEE']['Yra'] = 'N';
                            $Adresai['CONSIGNEE']['tableFrom'] = '';
                            $Adresai['CONSIGNEE']['imoneID'] = '';
                            $Adresai['CONSIGNEE']['imoneAdresasID'] = '';

                        }



                        /* DELIVERY - all4Labels */
                        $Adresai['DELIVERY']['Yra'] = 'Y';
                
                        $Adresai['DELIVERY']['contactPerson']['name'] = $OrdDate['LS_Contact'];
                        $Adresai['DELIVERY']['contactPerson']['email'] = trim ($OrdDate['LS_ContactEmail']);
                        $Adresai['DELIVERY']['contactPerson']['phone'] =trim ($OrdDate['LS_ContactPhone']);
                        $Adresai['DELIVERY']['name1'] = $OrdDate['ClientName'];
                        $Adresai['DELIVERY']['name2'] = '';
                        $Adresai['DELIVERY']['customerAddressIdentifier'] = $OrdDate['LS_ClientID'];
                        $Adresai['DELIVERY']['email'] = trim ($OrdDate['LS_Email']);
                        $Adresai['DELIVERY']['fax'] = trim ($OrdDate['LS_Faksas']);
                        $Adresai['DELIVERY']['industry'] = "AUTOMOTIVE";
                        $Adresai['DELIVERY']['locationType'] = "PHYSICAL";
                        $Adresai['DELIVERY']['mobilePhone'] = trim ($OrdDate['LS_Telefonas']);
                        $Adresai['DELIVERY']['personType']="COMPANY"; // COMPANY, PERSON
                        $Adresai['DELIVERY']['phone'] = trim ($OrdDate['LS_Telefonas']);
                        $Adresai['DELIVERY']['poBox']="POBOX";
                        $Adresai['DELIVERY']['postalCode'] = trim ($OrdDate['LS_PostCode']);
                        $Adresai['DELIVERY']['stateCode'] = '';
                        $Adresai['DELIVERY']['stateName'] = '';
                        $Adresai['DELIVERY']['preferredLanguage'] = '';
                        $Adresai['DELIVERY']['schenkerAddressId'] = ''; /*$OrdDate['Delivery_AddressID'];*/
                        $Adresai['DELIVERY']['street'] = $OrdDate['LS_Street'];
                        $Adresai['DELIVERY']['street2'] = $OrdDate['LS_Gyvenviete'];
                        $Adresai['DELIVERY']['city'] = $OrdDate['LS_Miestas'];
                        $Adresai['DELIVERY']['countryCode'] = $OrdDate['LS_LandRef'];
                        $Adresai['DELIVERY']['type'] = "DELIVERY";//"PICKUP"
                        $Adresai['DELIVERY']['AdreasasFullStr'] = $Adresai['DELIVERY']['street'].", ".$Adresai['DELIVERY']['city'].", ".$Adresai['DELIVERY']['countryCode'].", ".$Adresai['DELIVERY']['postalCode'];

                        $Adresai['DELIVERY']['tableFrom'] = 'klabas__';
                        $Adresai['DELIVERY']['imoneID'] = $OrdDate['LS_ClientID'];
                        $Adresai['DELIVERY']['imoneAdresasID'] = $OrdDate['LS_ClientID'];



                        $n++;
                    /* ************* LS paprastas neutralumas *********************************************************************************** */
                    }elseif(strpos(strtoupper($NeutralumasTmp['knp__nam']),'LS')!== false){


                        //turim NEUTRALUMA
                        $Adresai['NeutralumasYra'] = 'LS';
                        /*
                            SHIPPER - All4labels
                            PICKUP - Aurika sandelys
                            CONSIGNEE - gavejas
                        */


                        /* SCHIPER */
                        //siunteja (All4Labels) imam is bstlyn->klabas->contacts
                        $Adresai['SHIPPER']['Yra'] = 'Y';
                        $Adresai['SHIPPER']['contactPerson']['email'] = trim ($OrdDate['LS_Email']);
                        $Adresai['SHIPPER']['name1'] = $OrdDate['ClientName'];
                        $Adresai['SHIPPER']['name2'] = '';
                        $Adresai['SHIPPER']['customerAddressIdentifier'] = $OrdDate['LS_ClientID'];
                        $Adresai['SHIPPER']['email'] = trim ($OrdDate['LS_Email']);
                        $Adresai['SHIPPER']['fax'] = $OrdDate['LS_Faksas'];
                        $Adresai['SHIPPER']['industry'] = "AUTOMOTIVE";
                        $Adresai['SHIPPER']['locationType'] = "PHYSICAL";
                        $Adresai['SHIPPER']['mobilePhone'] = trim ($OrdDate['LS_Telefonas']);
                        $Adresai['SHIPPER']['personType']="COMPANY"; // COMPANY, PERSON
                        $Adresai['SHIPPER']['phone'] = trim ($OrdDate['LS_Telefonas']);
                        $Adresai['SHIPPER']['poBox']="POBOX";
                        $Adresai['SHIPPER']['postalCode'] = trim ($OrdDate['LS_PostCode']);
                        $Adresai['SHIPPER']['stateCode'] = '';
                        $Adresai['SHIPPER']['stateName'] = '';
                        $Adresai['SHIPPER']['preferredLanguage'] = '';
                        $Adresai['SHIPPER']['schenkerAddressId'] = ''; /*$OrdDate['Delivery_AddressID'];*/
                        $Adresai['SHIPPER']['street'] = $OrdDate['LS_Street'];
                        $Adresai['SHIPPER']['street2'] = $OrdDate['LS_Gyvenviete'];
                        $Adresai['SHIPPER']['city'] = $OrdDate['LS_Miestas'];
                        $Adresai['SHIPPER']['countryCode'] = $OrdDate['LS_LandRef'];
                        $Adresai['SHIPPER']['type'] = "SHIPPER";//"PICKUP"
                        $Adresai['SHIPPER']['AdreasasFullStr'] = $Adresai['SHIPPER']['street'].", ".$Adresai['SHIPPER']['city'].", ".$Adresai['SHIPPER']['countryCode'].", ".$Adresai['SHIPPER']['postalCode'];

                        $Adresai['SHIPPER']['tableFrom'] = 'klabas__';
                        $Adresai['SHIPPER']['imoneID'] = $OrdDate['LS_ClientID'];
                        $Adresai['SHIPPER']['imoneAdresasID'] = $OrdDate['LS_ClientID'];


                        /* Musu sandelio adresas*/
                        /* nustatysim schenker objekte */
                        /*
                        $Adresai['PICKUP']['Yra'] = 'N';
                        $Adresai['PICKUP']['contactPerson']['email'] = '';
                        $Adresai['PICKUP']['name1'] = '';
                        $Adresai['PICKUP']['name2'] = '';
                        $Adresai['PICKUP']['customerAddressIdentifier'] = '';
                        $Adresai['PICKUP']['email'] = '';
                        $Adresai['PICKUP']['fax'] = '';
                        $Adresai['PICKUP']['industry'] = "AUTOMOTIVE";
                        $Adresai['PICKUP']['locationType'] = "PHYSICAL";
                        $Adresai['PICKUP']['mobilePhone'] = '';
                        $Adresai['PICKUP']['personType']="COMPANY"; // COMPANY, PERSON
                        $Adresai['PICKUP']['phone'] = '';
                        $Adresai['PICKUP']['poBox']="POBOX";
                        $Adresai['PICKUP']['postalCode'] = '';
                        $Adresai['PICKUP']['stateCode'] = '';
                        $Adresai['PICKUP']['stateName'] = '';
                        $Adresai['PICKUP']['preferredLanguage'] = '';
                        $Adresai['PICKUP']['schenkerAddressId'] = '';
                        $Adresai['PICKUP']['street'] = '';
                        $Adresai['PICKUP']['street2'] = '';
                        $Adresai['PICKUP']['city'] = '';
                        $Adresai['PICKUP']['countryCode'] = '';
                        $Adresai['PICKUP']['type'] = "PICKUP";//"PICKUP"
                        */

                        /* Galutinio gavejo adresas (imones)*/
                        if($OrdDate['lok__ref']){

                            $qry1 = "
                                SELECT 
                                    kla__ref AS TevoKlientoID,
                                    lok__ref AS AdresoID, 
                                    lev_loc1 AS ClientName,
                                    lev_loc2 AS lev_loc2,
                                    lev_loc3 AS Street,
                                    wijk____ AS District, /*Rajonas*/
                                    land_ref AS LandRef,
                                    county__ AS County, /*Apskritis*/
                                    state___ AS State,
                                    post_ref AS PostCode,
                                    postnaam AS City,
                                    telefoon AS Tel,
                                    email___ AS Email,
                                    lev_loc3 AS Street

                                    -- , *
                                FROM levlok__
                                -- pvz WHERE lok__ref = '402115'
                                WHERE lok__ref = '".$OrdDate['lok__ref']."'                            
                            ";
                            $ConsigneeAdr = $mssql->querySqlOneRow($qry1, 1);
                            if($ConsigneeAdr){

                                /* sutvarkom adresus (rajonus, apylinkes) */
                                if($ConsigneeAdr['District']){
                                    $ConsigneeAdr['City'] = $ConsigneeAdr['District'] .', '. $ConsigneeAdr['City'];
                                }
                                if($ConsigneeAdr['County']){
                                    $ConsigneeAdr['City'] = $ConsigneeAdr['City'] .', '. $ConsigneeAdr['County'];
                                }



                                
                                $Adresai['CONSIGNEE']['Yra'] = 'Y';

                                $Adresai['CONSIGNEE']['contactPerson']['name'] = '';
                                $Adresai['CONSIGNEE']['contactPerson']['email'] = trim ($ConsigneeAdr['Email']);
                                $Adresai['CONSIGNEE']['contactPerson']['phone'] ='';

                                $Adresai['CONSIGNEE']['name1'] = $ConsigneeAdr['ClientName'];
                                $Adresai['CONSIGNEE']['name2'] = '';
                                $Adresai['CONSIGNEE']['customerAddressIdentifier'] = $ConsigneeAdr['AdresoID'];
                                $Adresai['CONSIGNEE']['email'] = trim ($ConsigneeAdr['Email']);
                                $Adresai['CONSIGNEE']['fax'] = '';
                                $Adresai['CONSIGNEE']['industry'] = "AUTOMOTIVE";
                                $Adresai['CONSIGNEE']['locationType'] = "PHYSICAL";
                                $Adresai['CONSIGNEE']['mobilePhone'] = trim ($ConsigneeAdr['Tel']);
                                $Adresai['CONSIGNEE']['personType']="COMPANY"; // COMPANY, PERSON
                                $Adresai['CONSIGNEE']['phone'] = trim ($ConsigneeAdr['Tel']);
                                $Adresai['CONSIGNEE']['poBox']="POBOX";
                                $Adresai['CONSIGNEE']['postalCode'] = trim ($ConsigneeAdr['PostCode']);
                                $Adresai['CONSIGNEE']['stateCode'] = ''; //$ConsigneeAdr['ClientName'];
                                $Adresai['CONSIGNEE']['stateName'] = ''; //$ConsigneeAdr['Rajonas'];
                                $Adresai['CONSIGNEE']['preferredLanguage'] = '';
                                $Adresai['CONSIGNEE']['schenkerAddressId'] = '';
                                $Adresai['CONSIGNEE']['street'] = $ConsigneeAdr['Street'];
                                $Adresai['CONSIGNEE']['street2'] = $ConsigneeAdr['Rajonas'];/// ????? ar tikrai tas laukas
                                $Adresai['CONSIGNEE']['city'] = $ConsigneeAdr['City'];
                                $Adresai['CONSIGNEE']['countryCode'] = $ConsigneeAdr['LandRef'];
                                $Adresai['CONSIGNEE']['type'] = "CONSIGNEE";//"PICKUP"

                                $Adresai['CONSIGNEE']['tableFrom'] = 'levlok__';
                                $Adresai['CONSIGNEE']['imoneID'] = $ConsigneeAdr['AdresoID'];
                                $Adresai['CONSIGNEE']['imoneAdresasID'] = $ConsigneeAdr['AdresoID'];


                            }else{
                                $Adresai['CONSIGNEE']['Yra'] = 'N';
                                $Adresai['CONSIGNEE']['tableFrom'] = '';
                                $Adresai['CONSIGNEE']['imoneID'] = '';
                                $Adresai['CONSIGNEE']['imoneAdresasID'] = '';

                            }
                        }else{//
                            //KLAIDA... nera gavejo adreso
                            $Adresai['CONSIGNEE']['Yra'] = 'N';
                            $Adresai['CONSIGNEE']['tableFrom'] = '';
                            $Adresai['CONSIGNEE']['imoneID'] = '';
                            $Adresai['CONSIGNEE']['imoneAdresasID'] = '';
                        }


                        /* DELIVERY - su LS cia tuscia */
                        $Adresai['DELIVERY']['Yra'] = 'N';
                        $Adresai['DELIVERY']['contactPerson']['email'] = '';
                        $Adresai['DELIVERY']['name1'] = '';
                        $Adresai['DELIVERY']['name2'] = '';
                        $Adresai['DELIVERY']['customerAddressIdentifier'] = '';
                        $Adresai['DELIVERY']['email'] = '';
                        $Adresai['DELIVERY']['fax'] = '';
                        $Adresai['DELIVERY']['industry'] = "AUTOMOTIVE";
                        $Adresai['DELIVERY']['locationType'] = "PHYSICAL";
                        $Adresai['DELIVERY']['mobilePhone'] = '';
                        $Adresai['DELIVERY']['personType']="COMPANY"; // COMPANY, PERSON
                        $Adresai['DELIVERY']['phone'] = '';
                        $Adresai['DELIVERY']['poBox']="POBOX";
                        $Adresai['DELIVERY']['postalCode'] = '';
                        $Adresai['DELIVERY']['stateCode'] = '';
                        $Adresai['DELIVERY']['stateName'] = '';
                        $Adresai['DELIVERY']['preferredLanguage'] = '';
                        $Adresai['DELIVERY']['schenkerAddressId'] = ''; /*$OrdDate['Delivery_AddressID'];*/
                        $Adresai['DELIVERY']['street'] = '';
                        $Adresai['DELIVERY']['street2'] = '';
                        $Adresai['DELIVERY']['city'] = '';
                        $Adresai['DELIVERY']['countryCode'] = '';
                        $Adresai['DELIVERY']['type'] = "DELIVERY";//"PICKUP"
                        $Adresai['DELIVERY']['AdreasasFullStr'] = ''; //$Adresai['DELIVERY']['street'].", ".$Adresai['DELIVERY']['city'].", ".$Adresai['DELIVERY']['countryCode'].", ".$Adresai['DELIVERY']['postalCode'];

                        $Adresai['DELIVERY']['tableFrom'] = '';
                        $Adresai['DELIVERY']['imoneID'] = '';
                        $Adresai['DELIVERY']['imoneAdresasID'] = '';



                        $n++;



                    }elseif(strpos(strtoupper($NeutralumasTmp['knp__nam']),'PICKUP')!== false){
                        /* ***************************************** PASTOMATAI  siuntiniams be neutralumo *************************************************** */
                        $Adresai['NeutralumasYra'] = '';//

                        $Det_ArIPastomata = 'PICKUP';
                        /* AURIKA, kaip imone, ne kaip sandelys, cia dabar nepildom, pildysim schenker_mod */
                        $Adresai['SHIPPER']['Yra'] = 'N';
                        $Adresai['SHIPPER']['contactPerson']['email'] = '';
                        $Adresai['SHIPPER']['name1'] = '';
                        $Adresai['SHIPPER']['name2'] = '';
                        $Adresai['SHIPPER']['customerAddressIdentifier'] = '';
                        $Adresai['SHIPPER']['email'] = '';
                        $Adresai['SHIPPER']['fax'] = '';
                        $Adresai['SHIPPER']['industry'] = "AUTOMOTIVE";
                        $Adresai['SHIPPER']['locationType'] = "PHYSICAL";
                        $Adresai['SHIPPER']['mobilePhone'] = '';
                        $Adresai['SHIPPER']['personType']="COMPANY"; // COMPANY, PERSON
                        $Adresai['SHIPPER']['phone'] = '';
                        $Adresai['SHIPPER']['poBox']="POBOX";
                        $Adresai['SHIPPER']['postalCode'] = '';
                        $Adresai['SHIPPER']['stateCode'] = '';
                        $Adresai['SHIPPER']['stateName'] = '';
                        $Adresai['SHIPPER']['preferredLanguage'] = '';
                        $Adresai['SHIPPER']['schenkerAddressId'] = ''; 
                        $Adresai['SHIPPER']['street'] = '';
                        $Adresai['SHIPPER']['street2'] = '';
                        $Adresai['SHIPPER']['city'] = '';
                        $Adresai['SHIPPER']['countryCode'] = '';
                        $Adresai['SHIPPER']['type'] = "SHIPPER";//"PICKUP"
                        $Adresai['SHIPPER']['AdreasasFullStr'] = ''; //$Adresai['SHIPPER']['street'].", ".$Adresai['SHIPPER']['city'].", ".$Adresai['SHIPPER']['countryCode'].", ".$Adresai['SHIPPER']['postalCode'];
                        
                        $Adresai['SHIPPER']['tableFrom'] = '';
                        $Adresai['SHIPPER']['imoneID'] = '';
                        $Adresai['SHIPPER']['imoneAdresasID'] = '';




                        /* Galutinio gavejo adresas - pasiimam is bendrojo duomenu traukimo*/
                        if($OrdDate['Delivery_AddressID'] AND $OrdDate['Delivery_country_code'] AND $OrdDate['Delivery_post'] AND $OrdDate['Delivery_city'] AND $OrdDate['Delivery_street']){
                            $Adresai['CONSIGNEE']['Yra'] = 'Y';
                        }else{
                            $Adresai['CONSIGNEE']['Yra'] = 'N';
                            $Adresai['CONSIGNEE']['YraComment'] = '';
                            if(!$OrdDate['Delivery_AddressID']){
                                $Adresai['CONSIGNEE']['YraComment'] .= " Nežinomas gavėjo adreso ID... \n";
                            }
                            if(!$OrdDate['Delivery_country_code']){
                                $Adresai['CONSIGNEE']['YraComment'] .= " Nežinomas gavėjo šalies kodas \n";
                            }
                            if(!$OrdDate['Delivery_post']){
                                $Adresai['CONSIGNEE']['YraComment'] .= " Nežinomas gavėjo pašto kodas \n";
                            }
                            if(!$OrdDate['Delivery_city']){
                                $Adresai['CONSIGNEE']['YraComment'] .= " Nežinomas gavėjo miestas \n";
                            }
                            if(!$OrdDate['Delivery_street']){
                                $Adresai['CONSIGNEE']['YraComment'] .= " Nežinomas gavėjo adresas \n";
                            }
                        }
                /*
                C.naam____ AS ClientName,
                C.kla__ref AS LS_ClientID,
                C.straat__ AS LS_Street,
                C.land_ref AS LS_LandRef,
                C.county__ AS LS_Gyvenviete, 
                C.post_ref AS LS_PostCode,
                C.postnaam AS LS_Miestas,
                C.telefoon AS LS_Telefonas,
                C.telefax_ AS LS_Faksas,
                C.telex___ AS LS_Email,
                (O.knp__vnm + ' ' + O.knp__nam) AS LS_Contact,
                O.email___ AS LS_ContactEmail,
                O.tel_auto AS LS_ContactPhone,
                */

                        //$Adresai['CONSIGNEE']['contactPerson']['name'] = $OrdDate['ClientName'];
                        //$Adresai['CONSIGNEE']['contactPerson']['email'] = trim ($OrdDate['LS_Email']);
                        //$Adresai['CONSIGNEE']['contactPerson']['phone'] = trim ($OrdDate['LS_Telefonas']);

                        $Adresai['CONSIGNEE']['contactPerson']['name'] = $OrdDate['Pastomat_Delivery_contact'];
                        $Adresai['CONSIGNEE']['contactPerson']['email'] = trim ($OrdDate['Pastomat_Delivery_contact_email']);
                        $Adresai['CONSIGNEE']['contactPerson']['phone'] = trim ($OrdDate['Pastomat_Delivery_contact_phone']);

                        $Adresai['CONSIGNEE']['name1'] = $OrdDate['Delivery_Company'];
                        $Adresai['CONSIGNEE']['name2'] = '';
                        $Adresai['CONSIGNEE']['company_code'] = $OrdDate['ClientCompanyCode'];
                        
                        $Adresai['CONSIGNEE']['customerAddressIdentifier'] = $OrdDate['Delivery_AddressID'];
                        $Adresai['CONSIGNEE']['email'] = trim ($OrdDate['LS_Email']);
                        $Adresai['CONSIGNEE']['fax'] = '';
                        $Adresai['CONSIGNEE']['industry'] = "AUTOMOTIVE";
                        $Adresai['CONSIGNEE']['locationType'] = "PHYSICAL";
                        $Adresai['CONSIGNEE']['mobilePhone'] = trim ($OrdDate['LS_Telefonas']);
                        $Adresai['CONSIGNEE']['personType']="COMPANY"; // COMPANY, PERSON
                        $Adresai['CONSIGNEE']['phone'] = trim ($OrdDate['LS_Telefonas']);
                        $Adresai['CONSIGNEE']['poBox']="POBOX";
                        $Adresai['CONSIGNEE']['postalCode'] = trim ($OrdDate['Delivery_post']);
                        $Adresai['CONSIGNEE']['stateCode'] = ''; //$ConsigneeAdr['ClientName'];
                        $Adresai['CONSIGNEE']['stateName'] = ''; //$ConsigneeAdr['Rajonas'];
                        $Adresai['CONSIGNEE']['preferredLanguage'] = '';
                        $Adresai['CONSIGNEE']['schenkerAddressId'] = '';
                        $Adresai['CONSIGNEE']['street'] = $OrdDate['Delivery_street'];
                        $Adresai['CONSIGNEE']['street2'] = '';
                        $Adresai['CONSIGNEE']['city'] = $OrdDate['Delivery_city'];
                        $Adresai['CONSIGNEE']['countryCode'] = $OrdDate['Delivery_country_code'];
                        $Adresai['CONSIGNEE']['type'] = "CONSIGNEE";//"PICKUP"


                        if($OrdDate['Delivery_type']==1){
                            $Adresai['CONSIGNEE']['tableFrom'] = "klabas__";
                            $Adresai['CONSIGNEE']['imoneID'] = $OrdDate['LS_ClientID'];
                            $Adresai['CONSIGNEE']['imoneAdresasID'] = $OrdDate['LS_ClientID'];
                        }else{
                            $Adresai['CONSIGNEE']['tableFrom'] = "levlok__";
                            $Adresai['CONSIGNEE']['imoneID'] = $OrdDate['LS_ClientID'];
                            $Adresai['CONSIGNEE']['imoneAdresasID'] = $OrdDate['Delivery_AddressID'];
                        }
                        



                        /* DELIVERY - kai ne LS - cia tuscia */
                        $Adresai['DELIVERY']['Yra'] = 'N';
                        $Adresai['DELIVERY']['contactPerson']['email'] = '';
                        $Adresai['DELIVERY']['name1'] = '';
                        $Adresai['DELIVERY']['name2'] = '';
                        $Adresai['DELIVERY']['customerAddressIdentifier'] = '';
                        $Adresai['DELIVERY']['email'] = '';
                        $Adresai['DELIVERY']['fax'] = '';
                        $Adresai['DELIVERY']['industry'] = "AUTOMOTIVE";
                        $Adresai['DELIVERY']['locationType'] = "PHYSICAL";
                        $Adresai['DELIVERY']['mobilePhone'] = '';
                        $Adresai['DELIVERY']['personType']="COMPANY"; // COMPANY, PERSON
                        $Adresai['DELIVERY']['phone'] = '';
                        $Adresai['DELIVERY']['poBox']="POBOX";
                        $Adresai['DELIVERY']['postalCode'] = '';
                        $Adresai['DELIVERY']['stateCode'] = '';
                        $Adresai['DELIVERY']['stateName'] = '';
                        $Adresai['DELIVERY']['preferredLanguage'] = '';
                        $Adresai['DELIVERY']['schenkerAddressId'] = ''; /*$OrdDate['Delivery_AddressID'];*/
                        $Adresai['DELIVERY']['street'] = '';
                        $Adresai['DELIVERY']['street2'] = '';
                        $Adresai['DELIVERY']['city'] = '';
                        $Adresai['DELIVERY']['countryCode'] = '';
                        $Adresai['DELIVERY']['type'] = "DELIVERY";//"PICKUP"
                        $Adresai['DELIVERY']['AdreasasFullStr'] = ''; //$Adresai['DELIVERY']['street'].", ".$Adresai['DELIVERY']['city'].", ".$Adresai['DELIVERY']['countryCode'].", ".$Adresai['DELIVERY']['postalCode'];

                        $Adresai['DELIVERY']['tableFrom'] = '';
                        $Adresai['DELIVERY']['imoneID'] = '';
                        $Adresai['DELIVERY']['imoneAdresasID'] = '';



                        $n++;

                    }else{//end elseif
                        /* ***************************************** paprastiems  siuntiniams be neutralumo *************************************************** */

                        $Adresai['NeutralumasYra'] = 'NE';//nera neitralumo

                        /* AURIKA, kaip imone, ne kaip sandelys, cia dabar nepildom, pildysim schenker_mod */
                        $Adresai['SHIPPER']['Yra'] = 'N';
                        $Adresai['SHIPPER']['contactPerson']['email'] = '';
                        $Adresai['SHIPPER']['name1'] = '';
                        $Adresai['SHIPPER']['name2'] = '';
                        $Adresai['SHIPPER']['customerAddressIdentifier'] = '';
                        $Adresai['SHIPPER']['email'] = '';
                        $Adresai['SHIPPER']['fax'] = '';
                        $Adresai['SHIPPER']['industry'] = "AUTOMOTIVE";
                        $Adresai['SHIPPER']['locationType'] = "PHYSICAL";
                        $Adresai['SHIPPER']['mobilePhone'] = '';
                        $Adresai['SHIPPER']['personType']="COMPANY"; // COMPANY, PERSON
                        $Adresai['SHIPPER']['phone'] = '';
                        $Adresai['SHIPPER']['poBox']="POBOX";
                        $Adresai['SHIPPER']['postalCode'] = '';
                        $Adresai['SHIPPER']['stateCode'] = '';
                        $Adresai['SHIPPER']['stateName'] = '';
                        $Adresai['SHIPPER']['preferredLanguage'] = '';
                        $Adresai['SHIPPER']['schenkerAddressId'] = ''; 
                        $Adresai['SHIPPER']['street'] = '';
                        $Adresai['SHIPPER']['street2'] = '';
                        $Adresai['SHIPPER']['city'] = '';
                        $Adresai['SHIPPER']['countryCode'] = '';
                        $Adresai['SHIPPER']['type'] = "SHIPPER";//"PICKUP"
                        $Adresai['SHIPPER']['AdreasasFullStr'] = ''; //$Adresai['SHIPPER']['street'].", ".$Adresai['SHIPPER']['city'].", ".$Adresai['SHIPPER']['countryCode'].", ".$Adresai['SHIPPER']['postalCode'];
                        
                        $Adresai['SHIPPER']['tableFrom'] = '';
                        $Adresai['SHIPPER']['imoneID'] = '';
                        $Adresai['SHIPPER']['imoneAdresasID'] = '';


                        /* Musu sandelio adresas*/
                        /* nustatysim schenker objekte */
                        /*
                        $Adresai['PICKUP']['Yra'] = 'N';
                        $Adresai['PICKUP']['contactPerson']['email'] = '';
                        $Adresai['PICKUP']['name1'] = '';
                        $Adresai['PICKUP']['name2'] = '';
                        $Adresai['PICKUP']['customerAddressIdentifier'] = '';
                        $Adresai['PICKUP']['email'] = '';
                        $Adresai['PICKUP']['fax'] = '';
                        $Adresai['PICKUP']['industry'] = "AUTOMOTIVE";
                        $Adresai['PICKUP']['locationType'] = "PHYSICAL";
                        $Adresai['PICKUP']['mobilePhone'] = '';
                        $Adresai['PICKUP']['personType']="COMPANY"; // COMPANY, PERSON
                        $Adresai['PICKUP']['phone'] = '';
                        $Adresai['PICKUP']['poBox']="POBOX";
                        $Adresai['PICKUP']['postalCode'] = '';
                        $Adresai['PICKUP']['stateCode'] = '';
                        $Adresai['PICKUP']['stateName'] = '';
                        $Adresai['PICKUP']['preferredLanguage'] = '';
                        $Adresai['PICKUP']['schenkerAddressId'] = '';
                        $Adresai['PICKUP']['street'] = '';
                        $Adresai['PICKUP']['street2'] = '';
                        $Adresai['PICKUP']['city'] = '';
                        $Adresai['PICKUP']['countryCode'] = '';
                        $Adresai['PICKUP']['type'] = "PICKUP";//"PICKUP"
                        */

                        /*
                    $OrderList[$OrdDate['PackingSlip']]['DeliveryStatus']=$OrdDate['DeliveryStatus'];
                    $OrderList[$OrdDate['PackingSlip']]['InvoiceStatus']=$OrdDate['InvoiceStatus'];
                    $OrderList[$OrdDate['PackingSlip']]['bst__ref']=$OrdDate['bst__ref'];
                    $OrderList[$OrdDate['PackingSlip']]['ClientName']=$OrdDate['ClientName'];
                    $OrderList[$OrdDate['PackingSlip']]['ClientID']=$OrdDate['kla__ref'];
                    $OrderList[$OrdDate['PackingSlip']]['ShippedFrom']=$OrdDate['ShippedFrom'];
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_Company']=$OrdDate['Delivery_Company'];
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_CompanyID']=$OrdDate['Delivery_CompanyID'];
                    
                    $OrderList[$OrdDate['PackingSlip']]['TransporterID']=$OrdDate['TransporterID'];
                    $OrderList[$OrdDate['PackingSlip']]['TransporterKeyword']=$OrdDate['TransporterKeyword'];
                    $OrderList[$OrdDate['PackingSlip']]['Packs_picked']=$OrdDate['Packs_picked'];
                    $OrderList[$OrdDate['PackingSlip']]['Pallets_picked']=$OrdDate['Pallets_picked'];

                    $OrderList[$OrdDate['PackingSlip']]['PikedQuontityPacks']=$OrdDate['PikedQuontityPacks'];
                    $OrderList[$OrdDate['PackingSlip']]['PikedQuontityPallets']=$OrdDate['PikedQuontityPallets'];
                    $OrderList[$OrdDate['PackingSlip']]['OrderedQuontityPacks']=$OrdDate['OrderedQuontityPacks'];
                    $OrderList[$OrdDate['PackingSlip']]['OrderedQuontityPallets']=$OrdDate['OrderedQuontityPallets'];

                    $OrderList[$OrdDate['PackingSlip']]['Packing_slip_comment'].=$OrdDate['Packing_slip_comment'].' ';
                    $OrderList[$OrdDate['PackingSlip']]['DeliveryComment'].=$OrdDate['DeliveryComment'].' ';
                    $OrderList[$OrdDate['PackingSlip']]['CommentAfterDelivery'].=$OrdDate['CommentAfterDelivery'].' ';
                    
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_type']=$OrdDate['Delivery_type'];
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_AddressID']=$OrdDate['Delivery_AddressID'];
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_country_code']=$OrdDate['Delivery_country_code'];
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_post']=$OrdDate['Delivery_post'];

                    $OrderList[$OrdDate['PackingSlip']]['Delivery_city']=$OrdDate['Delivery_city'];
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_street']=$OrdDate['Delivery_street'];
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_email']=$OrdDate['Delivery_email'];
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_phone']=$OrdDate['Delivery_phone'];
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_contact']=$OrdDate['Delivery_contact'];
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_contact_email']=$OrdDate['Delivery_contact_email'];
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_contact_phone']=$OrdDate['Delivery_contact_phone'];
                    $OrderList[$OrdDate['PackingSlip']]['PackingSlipDate']=$OrdDate['PackingSlipDate'];
                    $OrderList[$OrdDate['PackingSlip']]['PackingSlipComposedID']=$OrdDate['PackingSlipComposedID'];
                        */

//var_dump($OrdDate);

                        /* Galutinio gavejo adresas - pasiimam is bendrojo duomenu traukimo*/
                        if(($OrdDate['Delivery_AddressID'] OR $OrdDate['ShippedFrom']=='ETK') AND $OrdDate['Delivery_country_code'] AND $OrdDate['Delivery_post'] AND $OrdDate['Delivery_city'] AND $OrdDate['Delivery_street']){
                            $Adresai['CONSIGNEE']['Yra'] = 'Y';
                        }else{
                            $Adresai['CONSIGNEE']['Yra'] = 'N';
                            $Adresai['CONSIGNEE']['YraComment'] = '';
                            if(!$OrdDate['Delivery_AddressID'] AND $OrdDate['ShippedFrom']!='ETK'){
                                $Adresai['CONSIGNEE']['YraComment'] .= " Nežinomas gavėjo adreso ID \n";
                            }
                            if(!$OrdDate['Delivery_country_code']){
                                $Adresai['CONSIGNEE']['YraComment'] .= " Nežinomas gavėjo šalies kodas \n";
                            }
                            if(!$OrdDate['Delivery_post']){
                                $Adresai['CONSIGNEE']['YraComment'] .= " Nežinomas gavėjo pašto kodas \n";
                            }
                            if(!$OrdDate['Delivery_city']){
                                $Adresai['CONSIGNEE']['YraComment'] .= " Nežinomas gavėjo miestas \n";
                            }
                            if(!$OrdDate['Delivery_street']){
                                $Adresai['CONSIGNEE']['YraComment'] .= " Nežinomas gavėjo adresas \n";
                            }
                        }

                        $Adresai['CONSIGNEE']['contactPerson']['name'] = $OrdDate['Delivery_contact'];
                        $Adresai['CONSIGNEE']['contactPerson']['email'] = trim ($OrdDate['Delivery_contact_email']);
                        $Adresai['CONSIGNEE']['contactPerson']['phone'] = trim ($OrdDate['Delivery_contact_phone']);

                        $Adresai['CONSIGNEE']['name1'] = $OrdDate['Delivery_Company'];
                        $Adresai['CONSIGNEE']['name2'] = '';
                        $Adresai['CONSIGNEE']['customerAddressIdentifier'] = $OrdDate['Delivery_AddressID'];
                        $Adresai['CONSIGNEE']['email'] = trim ($OrdDate['Delivery_email']);
                        $Adresai['CONSIGNEE']['fax'] = '';
                        $Adresai['CONSIGNEE']['industry'] = "AUTOMOTIVE";
                        $Adresai['CONSIGNEE']['locationType'] = "PHYSICAL";
                        $Adresai['CONSIGNEE']['mobilePhone'] = trim ($OrdDate['Delivery_contact_phone']);
                        $Adresai['CONSIGNEE']['personType']="COMPANY"; // COMPANY, PERSON
                        $Adresai['CONSIGNEE']['phone'] = trim ($OrdDate['Delivery_phone']);
                        $Adresai['CONSIGNEE']['poBox']="POBOX";
                        $Adresai['CONSIGNEE']['postalCode'] = trim ($OrdDate['Delivery_post']);
                        $Adresai['CONSIGNEE']['stateCode'] = ''; //$ConsigneeAdr['ClientName'];
                        $Adresai['CONSIGNEE']['stateName'] = ''; //$ConsigneeAdr['Rajonas'];
                        $Adresai['CONSIGNEE']['preferredLanguage'] = '';
                        $Adresai['CONSIGNEE']['schenkerAddressId'] = '';
                        $Adresai['CONSIGNEE']['street'] = $OrdDate['Delivery_street'];
                        $Adresai['CONSIGNEE']['street2'] = '';
                        $Adresai['CONSIGNEE']['city'] = $OrdDate['Delivery_city'];
                        $Adresai['CONSIGNEE']['countryCode'] = $OrdDate['Delivery_country_code'];
                        $Adresai['CONSIGNEE']['type'] = "CONSIGNEE";//"PICKUP"


                        if($OrdDate['Delivery_type']==1){
                            $Adresai['CONSIGNEE']['tableFrom'] = "klabas__";
                            $Adresai['CONSIGNEE']['imoneID'] = $OrdDate['LS_ClientID'];
                            $Adresai['CONSIGNEE']['imoneAdresasID'] = $OrdDate['LS_ClientID'];
                        }else{
                            $Adresai['CONSIGNEE']['tableFrom'] = "levlok__";
                            $Adresai['CONSIGNEE']['imoneID'] = $OrdDate['LS_ClientID'];
                            $Adresai['CONSIGNEE']['imoneAdresasID'] = $OrdDate['Delivery_AddressID'];
                        }
                        
//var_dump($Adresai['CONSIGNEE']);


                        /* DELIVERY - kai ne LS - cia tuscia */
                        $Adresai['DELIVERY']['Yra'] = 'N';
                        $Adresai['DELIVERY']['contactPerson']['email'] = '';
                        $Adresai['DELIVERY']['name1'] = '';
                        $Adresai['DELIVERY']['name2'] = '';
                        $Adresai['DELIVERY']['customerAddressIdentifier'] = '';
                        $Adresai['DELIVERY']['email'] = '';
                        $Adresai['DELIVERY']['fax'] = '';
                        $Adresai['DELIVERY']['industry'] = "AUTOMOTIVE";
                        $Adresai['DELIVERY']['locationType'] = "PHYSICAL";
                        $Adresai['DELIVERY']['mobilePhone'] = '';
                        $Adresai['DELIVERY']['personType']="COMPANY"; // COMPANY, PERSON
                        $Adresai['DELIVERY']['phone'] = '';
                        $Adresai['DELIVERY']['poBox']="POBOX";
                        $Adresai['DELIVERY']['postalCode'] = '';
                        $Adresai['DELIVERY']['stateCode'] = '';
                        $Adresai['DELIVERY']['stateName'] = '';
                        $Adresai['DELIVERY']['preferredLanguage'] = '';
                        $Adresai['DELIVERY']['schenkerAddressId'] = ''; /*$OrdDate['Delivery_AddressID'];*/
                        $Adresai['DELIVERY']['street'] = '';
                        $Adresai['DELIVERY']['street2'] = '';
                        $Adresai['DELIVERY']['city'] = '';
                        $Adresai['DELIVERY']['countryCode'] = '';
                        $Adresai['DELIVERY']['type'] = "DELIVERY";//"PICKUP"
                        $Adresai['DELIVERY']['AdreasasFullStr'] = ''; //$Adresai['DELIVERY']['street'].", ".$Adresai['DELIVERY']['city'].", ".$Adresai['DELIVERY']['countryCode'].", ".$Adresai['DELIVERY']['postalCode'];

                        $Adresai['DELIVERY']['tableFrom'] = '';
                        $Adresai['DELIVERY']['imoneID'] = '';
                        $Adresai['DELIVERY']['imoneAdresasID'] = '';



                        $n++;


                    }//end else paprastiems 





                    //Susivedam visu siuntu Produktus, PackingSlipus, JOBus ,...
                    if(trim($OrdDate['PackingSlip'])){
                        if(strpos($PackSlipStr, $OrdDate['PackingSlip'])===false){
                            $PackSlipStr .= $OrdDate['PackingSlip'].", ";
                        }

                        if($OrdDate['afg__ref']){
                           if(strpos($ProdIDStr, $OrdDate['afg__ref'])===false){
                                $ProdIDStr .= $OrdDate['afg__ref'].", ";
                           }
                        }
                        if($OrdDate['ord__ref']){
                           if(strpos($JobIDStr, $OrdDate['ord__ref'])===false){
                                $JobIDStr .= $OrdDate['ord__ref'].", ";
                           }
                        }
                        if($OrdDate['bst__ref']){
                           if(strpos($SOIDStr, $OrdDate['bst__ref'])===false){
                                $SOIDStr .= $OrdDate['bst__ref'].", ";
                           }
                        }
                    }else{
                       $YraKlaidu = "Y"; 
                       $KlaidaCommentTmp = "Nenurodytas PackingSlip numeris.\n";
                       if(strpos($KlaidaComment, $KlaidaCommentTmp)===false){
                            $KlaidaComment .= $KlaidaCommentTmp;//nekartojam tu paciu pranesimu
                       }
                    }

                    //++++++tikrinam ar tas pats gavejas
                    //if(trim($OrdDate['Delivery_Company'])){
                    if(trim($Adresai['CONSIGNEE']['name1'])){
                        if($ClientStr AND $ClientStr!=$Adresai['CONSIGNEE']['name1']){
                           $YraKlaidu = "Y"; 
                           $KlaidaCommentTmp = "Krovinys turi būti tam pačiam gavėjui.\n";
                           if(strpos($KlaidaComment, $KlaidaCommentTmp)===false){
                                $KlaidaComment .= $KlaidaCommentTmp;//nekartojam tu paciu pranesimu
                           }
                        }else{
                            $ClientStr = $Adresai['CONSIGNEE']['name1'];
                        }
                    }else{
                       $YraKlaidu = "Y"; 
                       $KlaidaCommentTmp = "Nenurodytas gavėjas (įmonė)\n";
                       if(strpos($KlaidaComment, $KlaidaCommentTmp)===false){
                            $KlaidaComment .= $KlaidaCommentTmp;//nekartojam tu paciu pranesimu
                       }
                    }

                    //tikrinam ar tas pats vezejas
                    /* 20200617 - nuimam Editos prasymu (email: 20200617 13:41)
                    if(trim($OrdDate['TransporterKeyword'])){
                        if($VezejasStr AND $VezejasStr!=$OrdDate['TransporterKeyword']){
                           $YraKlaidu = "Y"; 
                           $KlaidaCommentTmp = "Turi būti vienas krovinio vežėjas.\n";
                           if(strpos($KlaidaComment, $KlaidaCommentTmp)===false){
                                $KlaidaComment .= $KlaidaCommentTmp;//nekartojam tu paciu pranesimu
                           }
                        }else{
                            $VezejasStr = $OrdDate['TransporterKeyword'];
                        }
                    }else{
                       $YraKlaidu = "Y"; 
                       $KlaidaCommentTmp = "Nenurodytas vežėjas\n";
                       if(strpos($KlaidaComment, $KlaidaCommentTmp)===false){
                            $KlaidaComment .= $KlaidaCommentTmp;//nekartojam tu paciu pranesimu
                       }
                    }
                    */
                    $VezejasStr = $OrdDate['TransporterKeyword'];

                    //tikrinam ar tapati data
                    if($OrdDate['Expected_Shipment_Date'] AND $OrdDate['Expected_Shipment_Date'] > '2019-01-01'){
                        if($ShipmentDateStr AND $ShipmentDateStr!=$OrdDate['Expected_Shipment_Date']){
                           $YraKlaidu = "Y"; 
                           $KlaidaCommentTmp = "Išvežimo data turi būti ta pati.\n";
                           if(strpos($KlaidaComment, $KlaidaCommentTmp)===false){
                                $KlaidaComment .= $KlaidaCommentTmp;//nekartojam tu paciu pranesimu
                           }
                        }else{
                            $ShipmentDateStr = $OrdDate['Expected_Shipment_Date'];
                        }
                    }else{
                       $YraKlaidu = "Y"; 
                       $KlaidaCommentTmp = "Nenurodyta išvežimo data\n";
                       if(strpos($KlaidaComment, $KlaidaCommentTmp)===false){
                            $KlaidaComment .= $KlaidaCommentTmp;//nekartojam tu paciu pranesimu
                       }
                    }

                    //tikrinam ar tas pats sandelys
                    if(trim($OrdDate['ShippedFrom'])){
                        if($ShipmentFromStr AND $ShipmentFromStr!=$OrdDate['ShippedFrom']){
                           $YraKlaidu = "Y"; 
                           $KlaidaCommentTmp = "Turi būti atkraunama iš to pačio sandėlio.\n";
                           if(strpos($KlaidaComment, $KlaidaCommentTmp)===false){
                                $KlaidaComment .= $KlaidaCommentTmp;//nekartojam tu paciu pranesimu
                           }
                        }else{
                            $ShipmentFromStr = $OrdDate['ShippedFrom'];
                        }
                    }else{
                       $YraKlaidu = "Y"; 
                       $KlaidaCommentTmp = "Nenurodytas atkrovimo sandėlys\n";
                       if(strpos($KlaidaComment, $KlaidaCommentTmp)===false){
                            $KlaidaComment .= $KlaidaCommentTmp;//nekartojam tu paciu pranesimu
                       }
                    }

                    //+++++++tikrinam ar tas pats pasto kodas
                    //if(trim($OrdDate['Delivery_post'])){
                    if(trim($Adresai['CONSIGNEE']['postalCode'])){
                        
                        if($AdreasasStr AND $AdreasasStr!=$Adresai['CONSIGNEE']['postalCode']){
                           $YraKlaidu = "Y"; 
                           $KlaidaCommentTmp = "Pristatymo adresas turi būti vienodas.\n";
                           if(strpos($KlaidaComment, $KlaidaCommentTmp)===false){
                                $KlaidaComment .= $KlaidaCommentTmp;//nekartojam tu paciu pranesimu
                           }
                        }else{
                            $AdreasasStr = $Adresai['CONSIGNEE']['postalCode'];
                            $AdreasasFullStr = $Adresai['CONSIGNEE']['street'].", ".$Adresai['CONSIGNEE']['city'].", ".$Adresai['CONSIGNEE']['countryCode'].", ".$Adresai['CONSIGNEE']['postalCode'];
                            $Adresai['CONSIGNEE']['AdreasasFullStr']=$AdreasasFullStr;
                        }
                    }else{
                       $YraKlaidu = "Y"; 
                       $KlaidaCommentTmp = "Nenurodytas pristatymo adresas.\n";
                       if(strpos($KlaidaComment, $KlaidaCommentTmp)===false){
                            $KlaidaComment .= $KlaidaCommentTmp;//nekartojam tu paciu pranesimu
                       }
                    }


                    //susirasos visus SO, paskui nuskaitysim ju failus
                    $SOArray[$OrdDate['bst__ref']]=$OrdDate['bst__ref'];

                    $TransporterID = $OrdDate['TransporterID'];
                    $ClientID = $OrdDate['kla__ref'];
                    $ClientName = $OrdDate['ClientName'];
                    $ClientCompanyCode = $OrdDate['ClientCompanyCode'];
                    $TerminalImCode = $OrdDate['TerminalImCode'];
                    $Delivery_CompanyID = $OrdDate['Delivery_CompanyID'];
                    $Delivery_AddressID = $OrdDate['Delivery_AddressID'];
                    $Delivery_country_code = trim ($OrdDate['Delivery_country_code']);
                    $Delivery_city = $OrdDate['Delivery_city'];
                    $Delivery_post = trim ($OrdDate['Delivery_post']);



                    $OrderList[$OrdDate['PackingSlip']]['PackingSlip']=$OrdDate['PackingSlip'];
                    $OrderList[$OrdDate['PackingSlip']]['Expected_Shipment_Date']=$OrdDate['Expected_Shipment_Date'];
                    $OrderList[$OrdDate['PackingSlip']]['Expected_Delivery_Date']=$OrdDate['Expected_Delivery_Date'];
                    $OrderList[$OrdDate['PackingSlip']]['Real_Shipped_Date']=$OrdDate['Real_Shipped_Date'];

                    $OrderList[$OrdDate['PackingSlip']]['DeliveryStatus']=$OrdDate['DeliveryStatus'];
                    $OrderList[$OrdDate['PackingSlip']]['InvoiceStatus']=$OrdDate['InvoiceStatus'];
                    $OrderList[$OrdDate['PackingSlip']]['bst__ref']=$OrdDate['bst__ref'];
                    $OrderList[$OrdDate['PackingSlip']]['ClientName']=$OrdDate['ClientName'];
                    $OrderList[$OrdDate['PackingSlip']]['ClientID']=$OrdDate['kla__ref'];
                    $OrderList[$OrdDate['PackingSlip']]['ShippedFrom']=$OrdDate['ShippedFrom'];
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_Company']=$OrdDate['Delivery_Company'];
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_CompanyID']=$OrdDate['Delivery_CompanyID'];
                    
                    $OrderList[$OrdDate['PackingSlip']]['TransporterID']=$OrdDate['TransporterID'];
                    $OrderList[$OrdDate['PackingSlip']]['TransporterKeyword']=$OrdDate['TransporterKeyword'];
                    $OrderList[$OrdDate['PackingSlip']]['Packs_picked']=$OrdDate['Packs_picked'];
                    $OrderList[$OrdDate['PackingSlip']]['Pallets_picked']=$OrdDate['Pallets_picked'];

                    $OrderList[$OrdDate['PackingSlip']]['PikedQuontityPacks']=$OrdDate['PikedQuontityPacks'];
                    $OrderList[$OrdDate['PackingSlip']]['PikedQuontityPallets']=$OrdDate['PikedQuontityPallets'];
                    $OrderList[$OrdDate['PackingSlip']]['OrderedQuontityPacks']=$OrdDate['OrderedQuontityPacks'];
                    $OrderList[$OrdDate['PackingSlip']]['OrderedQuontityPallets']=$OrdDate['OrderedQuontityPallets'];

                    $OrderList[$OrdDate['PackingSlip']]['Packing_slip_comment'].=$OrdDate['Packing_slip_comment'].' ';
                    $OrderList[$OrdDate['PackingSlip']]['DeliveryComment'].=$OrdDate['DeliveryComment'].' ';
                    $OrderList[$OrdDate['PackingSlip']]['CommentAfterDelivery'].=$OrdDate['CommentAfterDelivery'].' ';
                    
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_type']=$OrdDate['Delivery_type'];
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_AddressID']=$OrdDate['Delivery_AddressID'];// TODO ar nereikia cia imti is sio kintamojo: $Adresai['CONSIGNEE']['customerAddressIdentifier'] , nes esant LS ir 2LS gali keistis
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_country_code']=trim ($OrdDate['Delivery_country_code']);
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_post']=trim ($OrdDate['Delivery_post']);

                    $OrderList[$OrdDate['PackingSlip']]['Delivery_city']=$OrdDate['Delivery_city'];
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_street']=$OrdDate['Delivery_street'];

                    $OrderList[$OrdDate['PackingSlip']]['Delivery_County']=$OrdDate['Delivery_County'];
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_District']=$OrdDate['Delivery_District'];

                    $OrderList[$OrdDate['PackingSlip']]['Delivery_email']=trim ($OrdDate['Delivery_email']);
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_phone']=trim ($OrdDate['Delivery_phone']);
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_contact']=$OrdDate['Delivery_contact'];
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_contact_email']=trim ($OrdDate['Delivery_contact_email']);
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_contact_phone']=trim ($OrdDate['Delivery_contact_phone']);
                    $OrderList[$OrdDate['PackingSlip']]['PackingSlipDate']=$OrdDate['PackingSlipDate'];
                    $OrderList[$OrdDate['PackingSlip']]['PackingSlipComposedID']=$OrdDate['PackingSlipComposedID'];
                    $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['lyn__ref']=$OrdDate['lyn__ref'];
                    $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['ord__ref']=$OrdDate['ord__ref'];
                    $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['ProductID']=$OrdDate['afg__ref'];
                    $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['ProductName']=$OrdDate['ProductName'];
                    $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['ProdClientID']=$OrdDate['ProdClientID'];
                    $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['ProdClientKey']=$OrdDate['ProdClientKey'];
                    $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['ProdComment']=$OrdDate['ProdComment'];

                    $OrderList[$OrdDate['PackingSlip']]['Adresai']=$Adresai;





                }//end foreach


                $KLAIDOS['Error'] = $YraKlaidu;
                $KLAIDOS['ErrorComments'] = $KlaidaComment;
                if(strlen($PackSlipStr)>2){
                    $PackSlipStr = substr($PackSlipStr, 0,-2);
                }
                if(strlen($ProdIDStr)>2){
                    $ProdIDStr = substr($ProdIDStr, 0,-2);
                }
                if(strlen($JobIDStr)>2){
                    $JobIDStr = substr($JobIDStr, 0,-2);
                }

                if(strlen($SOIDStr)>2){
                    $SOIDStr = substr($SOIDStr, 0,-2);
                }

            }else{//end if
                $KLAIDOS['Error'] = 'Y';
                $KLAIDOS['ErrorComments'] .=  ' Nėra duomenų pagal šią paiešką ';

            }


            //!!!!!! DEBUG
            $this->var_dump($OrderList, "OrderList <hr>$aaa<hr> ");//-----------------DEBUG


            //pasiimam svorius ir  svoriu korekcija 
            if($YraKlaidu != "Y"){
                if($OrdDate['ShippedFrom']=='ETK'){
                    $RezDuomSvoriai = array('lbn__ref_brutt'=>1, 'SvorioKorekcija'=>0,'GalutinisBrutto'=>1);
                }else{
                    $RezDuomSvoriai = $this->getSvoriaiByPackingSlipArray($PackingSlipArray);    
                }
                
            }



            //Formuojam pakuociu KODA
            if($YraKlaidu != "Y"){
                if($OrdDate['ShippedFrom']=='ETK'){
                    $RezDuomPakuotes = $this->getPakuotesByPackingSlipArrayNAV(); //"<div id='packD_1' class='packD'>1|PK|32x23.5x19|1<b><img src='img/ico_del_c.gif' id='del_1' class='del_img' style='cursor: pointer;' /></b></div>";
                }else{
                    $RezDuomPakuotes = $this->getPakuotesByPackingSlipArray($PackingSlipArray);
                }
            }


            //pridedam failus
            //var_dump($SOArray);
            $this_PS_files_array = array();
            $this_PS_files_str = '';


            if($YraKlaidu != "Y"){
                if($OrdDate['ShippedFrom']=='ETK'){
                    $RefArray = array();
                    $this_PS_files_array_str['fileArray']=array();
                    $this_PS_files_array_str['fileStr']='';
                }else{
                    //Paruosiam masyva failu paieskai ...nuskaitom SO/packingslipus/...
                    $RefArray = $this->getSOArrayByPackingSlipArray($PackingSlipArray);
                    //!!!!!! DEBUG
                    //$this->var_dump($RefArray, "RefArray <hr>$sql<hr> ");//-----------------DEBUG

                    //nuskaitom failus is visu vietu, viska kas priklauso siuntai
                    $this_PS_files_array_str=$this->getSOFilesArray($RefArray);
                    //!!!!!! DEBUG
                    //$this->var_dump($this_PS_files_array_str, "this_PS_files_array_str <hr>$sql<hr> ");//-----------------DEBUG
                    
                }
            }




            /* SENAS FAILU ISVEDIMAS
            if($SOArray){
                $idx = 0;
                

                foreach ($SOArray as $key => $SOf) {
                    //susirasom i array priklausan2ius failus
                    $this_PS_files_array_str=$this->getSOFilesArray($SOf,$idx);
                    $this_PS_files_array = array_merge($this_PS_files_array, $this_PS_files_array_tmp);
                    $idx = count($this_PS_files_array);
                    //var_dump($this_PS_files_array);
                }//end foreach

                if($this_PS_files_array){
                    foreach ($this_PS_files_array as $key => $ff) {
                        $this_PS_files_str .= '<a href="'.$ff['fpath'].'" target = "_file" class="aLink">'.$ff['fname'].'</a><br>';
                    }
                }else{
                    $this_PS_files_str = ' ';
                }
            }else{
                    $this_PS_files_str = ' ';
            }//end if
            //var_dump($this_PS_files_array);
            */


            //!!!!!! DEBUG
            //$this->var_dump($RezDuomSvoriai, "RezDuomSvoriai <hr>$qryRealSvoriai<hr> ");//-----------------DEBUG

            //$RezDuomSvoriai['SvorioKorekcija']=$RezDuomSvoriai['SvorioKorekcija'];
            //$RezDuomSvoriai['GalutinisBrutto']=$RezDuomSvoriai['lbn__ref_brutt'] + $RezDuomSvoriai['SvorioKorekcija'];
    }else{//end if
        $KLAIDOS['Error'] = 'Y';
        $KLAIDOS['ErrorComments'] .=  ' Nėra PackingSlip numerio ';

    }




    $RezDuom['SVORIAI'] = $RezDuomSvoriai;
    $RezDuom['PAKUOTES'] = $RezDuomPakuotes['PakKodas'];
    $RezDuom['PAKUOTESARRAY'] = $RezDuomPakuotes['PakArray'];
    $RezDuom['FAILAI'] = $this_PS_files_array_str['fileArray'];
    $RezDuom['FAILAISTR'] = $this_PS_files_array_str['fileStr'];
    $RezDuom['packingOrders'] = $OrderList;
    $RezDuom['ERROR'] = $KLAIDOS;

    $RezDuom['SHORT']['express'] = $express;

    //jei pristatymo adrese taip pat yra suvestas pristatymo laikas, pristatymo laikas imamas pagal Sales Order kortelės informaciją !!! 
    // https://conf.aurika.lt/pages/viewpage.action?pageId=70303881
    if($pristatytiIki){
        $RezDuom['SHORT']['pristatytiIki'] = $pristatytiIki;
    }elseif($PristatymasIkiPagalAdr){
        $RezDuom['SHORT']['pristatytiIki'] = $PristatymasIkiPagalAdr;
    }else{
        $RezDuom['SHORT']['pristatytiIki'] = '';
    }
    
    $RezDuom['SHORT']['Liftas'] = $Liftas;
    $RezDuom['SHORT']['KetRankos'] = $KetRankos;
    $RezDuom['SHORT']['PristaLaikasDarboDienomis'] = $PristaLaikasDarboDienomis;


    //logika is Editos (transportas) mail 20210719 16:00
    //TAG20210721
    switch ($Delivery_country_code) {
        case 'DE':
            if($RezDuom['SHORT']['PristaLaikasDarboDienomis']<=3){
                $RezDuom['SHORT']['SCH_Paslauga'] ='PREMIUM';
            }else{
                $RezDuom['SHORT']['SCH_Paslauga'] ='SYSTEM';
            }
            break;
        case 'SE':
            if($RezDuom['SHORT']['PristaLaikasDarboDienomis']<=4){
                $RezDuom['SHORT']['SCH_Paslauga'] ='PREMIUM';
            }else{
                $RezDuom['SHORT']['SCH_Paslauga'] ='SYSTEM';
            }
            break;

        case 'FI':
            if($RezDuom['SHORT']['PristaLaikasDarboDienomis']<=4){
                $RezDuom['SHORT']['SCH_Paslauga'] ='PREMIUM';
            }else{
                $RezDuom['SHORT']['SCH_Paslauga'] ='SYSTEM';
            }
            break;
        case 'DK':
            if($RezDuom['SHORT']['PristaLaikasDarboDienomis']<=5){
                $RezDuom['SHORT']['SCH_Paslauga'] ='PREMIUM';
            }else{
                $RezDuom['SHORT']['SCH_Paslauga'] ='SYSTEM';
            }
            break;
        case 'NL':
            if($RezDuom['SHORT']['PristaLaikasDarboDienomis']<=4){
                $RezDuom['SHORT']['SCH_Paslauga'] ='PREMIUM';
            }else{
                $RezDuom['SHORT']['SCH_Paslauga'] ='SYSTEM';
            }
            break;
        case 'PL':
            if($RezDuom['SHORT']['PristaLaikasDarboDienomis']<=3){
                $RezDuom['SHORT']['SCH_Paslauga'] ='PREMIUM';
            }else{
                $RezDuom['SHORT']['SCH_Paslauga'] ='SYSTEM';
            }
            break;
        case 'NO':
            if($RezDuom['SHORT']['PristaLaikasDarboDienomis']<=5){
                $RezDuom['SHORT']['SCH_Paslauga'] ='PREMIUM';
            }else{
                $RezDuom['SHORT']['SCH_Paslauga'] ='SYSTEM';
            }
            break;
        case 'FR':
            if($RezDuom['SHORT']['PristaLaikasDarboDienomis']<=4){
                $RezDuom['SHORT']['SCH_Paslauga'] ='PREMIUM';
            }else{
                $RezDuom['SHORT']['SCH_Paslauga'] ='SYSTEM';
            }
            break;
        case 'AT':
            if($RezDuom['SHORT']['PristaLaikasDarboDienomis']<=4){
                $RezDuom['SHORT']['SCH_Paslauga'] ='PREMIUM';
            }else{
                $RezDuom['SHORT']['SCH_Paslauga'] ='SYSTEM';
            }
            break;
        case 'BE':
            if($RezDuom['SHORT']['PristaLaikasDarboDienomis']<=4){
                $RezDuom['SHORT']['SCH_Paslauga'] ='PREMIUM';
            }else{
                $RezDuom['SHORT']['SCH_Paslauga'] ='SYSTEM';
            }
            break;


        default:
            $RezDuom['SHORT']['SCH_Paslauga'] ='PREMIUM';
            break;
    }//end swich

    //cia isimtis tik vienam gavejui "B-Logistik GmbH" kurio adreso ID 406173, jam niekada nededam PREMIUM ... Editos laiskas 2023-02-23 11:26
    if($Adresai['CONSIGNEE']['customerAddressIdentifier']=='406173'){
        $RezDuom['SHORT']['SCH_Paslauga'] ='SYSTEM';
    }

    echo "<br>**** ADRESAS ID:".$Adresai['CONSIGNEE']['customerAddressIdentifier']." SCHENKER PASLAUGA: ".$RezDuom['SHORT']['SCH_Paslauga']." ---- <br>";

    echo "<br>+-".$RezDuom['SHORT']['PristaLaikasDarboDienomis']."+-+".$Delivery_country_code."-+-".$RezDuom['SHORT']['SCH_Paslauga'] ."+-+-+-+-+-<br>";
    //******************************************* TODO ----surasyti logika, kad pagal salis ir dienas parinktu SCHENKER siuntos kategosija---------

    $RezDuom['SHORT']['PackSlipStr'] = $PackSlipStr;
    $RezDuom['SHORT']['ProdIDStr'] = $ProdIDStr;
    $RezDuom['SHORT']['JobIDStr'] = $JobIDStr;
    $RezDuom['SHORT']['SOIDStr'] = $SOIDStr;
    $RezDuom['SHORT']['ClientStr'] = $ClientStr;
    $RezDuom['SHORT']['ClientID'] = $ClientID;
    $RezDuom['SHORT']['VezejasStr'] = $VezejasStr;
    $RezDuom['SHORT']['ShipmentDateStr'] = $ShipmentDateStr;
    $RezDuom['SHORT']['ShipmentFromStr'] = $ShipmentFromStr;
    $RezDuom['SHORT']['PostCodeStr'] = trim ($AdreasasStr);
    $RezDuom['SHORT']['AdreasasFullStr'] = $AdreasasFullStr;

    $RezDuom['SHORT']['Det_VezejasID'] = $TransporterID;
    $RezDuom['SHORT']['Det_KlientasID'] = $ClientID;
    $RezDuom['SHORT']['ClientName'] = $ClientName;

    if($VezejasStr=='PICKUP VEN' AND $ShipmentFromStr=='ETK'){//jeigu is NAVISION ir i VENIPAK pastomata tai dedam pastomata aptarnaujancios imones ID
        $RezDuom['SHORT']['Det_ClientCompanyCode'] = $TerminalImCode; 
    }else{
        $RezDuom['SHORT']['Det_ClientCompanyCode'] = $ClientCompanyCode; 
    }
    
    $RezDuom['SHORT']['Det_ArIPastomata'] = $Det_ArIPastomata; //jeigu i pastomata
    $RezDuom['SHORT']['Det_TerminalImCode'] = $TerminalImCode; //jeigu NAV i pastomata
    
    $RezDuom['SHORT']['Det_GavejasID'] = $Delivery_CompanyID;
    $RezDuom['SHORT']['Det_AdresasID'] = $Delivery_AddressID;
    $RezDuom['SHORT']['Det_SaliesKodas'] = $Delivery_country_code;
    $RezDuom['SHORT']['Det_Miestas'] = $Delivery_city;

    $RezDuom['SHORT']['Det_County'] = $OrdDate['Delivery_County'];
    $RezDuom['SHORT']['Det_District'] = $OrdDate['Delivery_District'];

    $RezDuom['SHORT']['Det_PostKodas'] = trim ($Delivery_post);
    $RezDuom['SHORT']['Det_Street'] = $OrdDate['Delivery_street'];

    $RezDuom['SHORT']['Det_Delivery_email'] = trim ($OrdDate['Delivery_email']);
    $RezDuom['SHORT']['Det_Delivery_phone'] = trim ($OrdDate['Delivery_phone']);
    $RezDuom['SHORT']['Det_Delivery_contact'] = $OrdDate['Delivery_contact'];
    $RezDuom['SHORT']['Det_Delivery_contact_email'] = trim ($OrdDate['Delivery_contact_email']);
    $RezDuom['SHORT']['Det_Delivery_contact_phone'] = trim ($OrdDate['Delivery_contact_phone']);
    $RezDuom['SHORT']['Packing_slip_comment'] = $OrdDate['Packing_slip_comment'];
    $RezDuom['SHORT']['DeliveryComment'] = $OrdDate['Delivery_comment'];
    $RezDuom['ADRESAI']=$Adresai;



    //!!!!!! DEBUG
    $this->var_dump($RezDuom, "RezDuom111 <hr>$qry<hr> ");//-----------------DEBUG

    return $RezDuom;
}//end function




public function getSOFilesArray($RefArray){
    
            $filesArray = array();
            //$fi = $idx;
            $fi = 0;
            $root_path = COMMON::getRootFolder();
            if($RefArray){
                foreach ($RefArray as $pskey => $PSlevel) {
                    $PS_ref = $PSlevel['lbn__ref'];
                    //pasiimam PackingSlip failus
                    //$RTFDir = $root_path."/MNT/CERM_BRF/bstlyn__/bst/" . substr($SO_ref, 0, 3)  . "/" . $SO_ref . "";
                    //$RTFDir = $root_path."MNT/CERM_BRF/bstlyn__/bst/" . substr($PS_ref, 0, 3)  . "/" . $PS_ref . "";
                    //$RezDir = "MNT/CERM_BRF/bstlyn__/bst/" . substr($SO_ref, 0, 3)  . "/" . $SO_ref . "";
                    $PSfilePath = $root_path."/MNT/CERM_BRF/bstlyn__/lvb/" . substr($PS_ref, 0, 3)  . "/" . $PS_ref . ".pdf";
                    $PSfilePathWeb = "MNT/CERM_BRF/bstlyn__/lvb/" . substr($PS_ref, 0, 3)  . "/" . $PS_ref . ".pdf";
                    
                    //var_dump($PSfilePath);                
                    //nuskaitom SO failus is 

                    if(file_exists ( $PSfilePath )){ //tikrinam ar uzmautinta (direktorija, kuri tikrai yra)
                        //$scanPSArray[] = scandir($RTFDir);
                        if (is_file($PSfilePath)){
                            $filesArray[$fi]['fname'] = $PS_ref . ".pdf";
                            $filesArray[$fi]['fpath'] = $PSfilePathWeb;
                            $filesArray[$fi]['isFile'] = 'Y';
                            $filesArray[$fi]['FileType'] = 'PS';
                            $filesArray[$fi]['FileTitle'] = 'PackingSlip file';
                            $fi++;
                        }                        
                    }
                    //echo "*PS|$PSfilePathWeb|<br>";
                    //var_dump($filesArray);

                    //begam toliau per SO
                    $SO_array = $PSlevel['bst__arr'];
                    if($SO_array){
                        foreach ($SO_array as $SOkey => $SOlevel) {
                            $SO_ref = $SOlevel['bst__ref'];

                            //pasiimam SO failus
                            $RTFDir = $root_path."MNT/CERM_BRF/bstlyn__/bst/" . substr($SO_ref, 0, 3)  . "/" . $SO_ref . "";
                            $WebDir = "MNT/CERM_BRF/bstlyn__/bst/" . substr($SO_ref, 0, 3)  . "/" . $SO_ref . "";
                            //var_dump($RTFDir); 
                            if(file_exists ( $RTFDir )){ //tikrinam ar uzmautinta (direktorija, kuri tikrai yra)
                                $scanSOArray = scandir($RTFDir);
                                if($scanSOArray){
                                    foreach ($scanSOArray as $key => $file) {
                                        if (!in_array($file,array(".",".."))){
                                            $filesPath = $RTFDir.'/'.$file;
                                            if (is_file($filesPath)){
                                                $filesArray[$fi]['fname'] = $file;
                                                $filesArray[$fi]['fpath'] = $WebDir.'/'.$file;
                                                $filesArray[$fi]['isFile'] = 'Y';
                                                $filesArray[$fi]['FileType'] = 'SO';
                                                $filesArray[$fi]['FileTitle'] = 'SalesOrder file';
                                                $fi++;
                                            }else{
                                                //$filesArray[$fi]['isFile'] = 'N';
                                            }
                                            //$fi++;
                                        }//end if
                                    }//end foreach
                                }//end if
                            }//end if
                            //echo "**SO|$WebDir|<br>";
                            //var_dump($filesArray);



                            //pasiimam SO->PS failus (SO direktorijoje esanti PS direktorija) - cia sukeliame reikiami failai is VADYBOS
                            $RTFDir = $root_path."MNT/CERM_BRF/bstlyn__/bst/" . substr($SO_ref, 0, 3)  . "/" . $SO_ref . "/".$PS_ref;
                            $WebDir = "MNT/CERM_BRF/bstlyn__/bst/" . substr($SO_ref, 0, 3)  . "/" . $SO_ref . "/".$PS_ref;
                            //var_dump($RTFDir); 
                            if(file_exists ( $RTFDir )){ //tikrinam ar uzmautinta (direktorija, kuri tikrai yra)
                                $scanSOPSArray = scandir($RTFDir);
                                if($scanSOPSArray){
                                    foreach ($scanSOPSArray as $key => $file) {
                                        if (!in_array($file,array(".",".."))){
                                            $filesPath = $RTFDir.'/'.$file;
                                            if (is_file($filesPath)){
                                                $filesArray[$fi]['fname'] = $file;
                                                $filesArray[$fi]['fpath'] = $WebDir.'/'.$file;
                                                $filesArray[$fi]['isFile'] = 'Y';
                                                $filesArray[$fi]['FileType'] = 'KAV';
                                                $filesArray[$fi]['FileTitle'] = 'Vadybos filai';
                                                $fi++;
                                            }else{
                                                //$filesArray[$fi]['isFile'] = 'N';
                                            }
                                            //$fi++;
                                        }//end if
                                    }//end foreach
                                }//end if
                            }//end if
                            //echo "**SO|$WebDir|<br>";
                            //var_dump($filesArray);



                            //begam toliau per JOB
                            $JOB_array = $SOlevel['ord__arr'];
                            if($JOB_array){
                                foreach ($JOB_array as $JOBkey => $JOBlevel) {
                                    $JOB_ref = $JOBlevel['ord__ref'];
                                    //pasiimam JOB failus

                                    //begam toliau per GAM
                                    $GAM_array = $JOBlevel['afg__arr'];
                                    if($GAM_array){
                                        foreach ($GAM_array as $GAMkey => $GAMlevel) {
                                            $GAM_ref = $GAMlevel['afg__ref'];
                                            $sertFile1 = $GAM_ref.'-'.$JOB_ref;
                                            $sertFile2 = 'batch'.$JOB_ref;
                                            //pasiimam kokybes sertifikatus
                                            //C:\WWW\AURIKA_NEW\MNT\FTPSRV\Sertifikatai\!SERTIFIKATAI\!SERTIFIKATAI SANDĖLIUI
                                            // LOCAL SERVER - $KfilePath = $root_path.iconv('UTF-8', 'WINDOWS-1257', "MNT/FTPSRV/Sertifikatai/!SERTIFIKATAI/!SERTIFIKATAI SANDĖLIUI/");
                                            $KfilePath = $root_path."MNT/FTPSRV/Sertifikatai/!SERTIFIKATAI/!SERTIFIKATAI SANDĖLIUI/";
                                            $KfilePathWeb = "MNT/FTPSRV/Sertifikatai/!SERTIFIKATAI/!SERTIFIKATAI SANDĖLIUI";
                                            //echo "==".$KfilePath."==<br>";
                                            if(file_exists ( $KfilePath )){ //tikrinam ar uzmautinta (direktorija, kuri tikrai yra)
                                                //echo "--YRA---<br>";
                                                $scanKArray = scandir($KfilePath);
                                                //var_dump($scanKArra);
                                                if($scanKArray){
                                                    foreach ($scanKArray as $Kkey => $Kfile) {
                                                        if (!in_array($Kfile,array(".",".."))){
                                                            if($sertFile1 == substr($Kfile, 0, 13)){
                                                                $filesPath = $KfilePath.'/'.$Kfile;
                                                                if (is_file($filesPath)){
/*                                                                    

var_dump(mb_detect_encoding($Kfile));                                                                    
var_dump(mb_convert_encoding($Kfile, 'UTF-8', 'Windows-1251'));
var_dump(mb_convert_encoding($Kfile, 'UTF-8', 'ISO-8859-1'));
var_dump(mb_convert_encoding($Kfile, 'UTF-8', 'ISO-8859-15'));  

var_dump(iconv('WINDOWS-1257', 'UTF-8', $Kfile));
var_dump(iconv('ISO-8859-1',   'UTF-8', $Kfile));
var_dump(iconv('ISO-8859-15',  'UTF-8', $Kfile));  

$filename = htmlentities(mb_convert_encoding($Kfile, 'UTF-8', 'Windows-1252'), ENT_QUOTES, 'UTF-8');
var_dump($filename)   ;
*/
                                                                    // LOCAL SERVER - $filesArray[$fi]['fname'] =iconv('WINDOWS-1257', 'UTF-8', $Kfile); //iconv('ISO-8859-1', 'UTF-8',$Kfile);
                                                                    $filesArray[$fi]['fname'] =$Kfile; //iconv('ISO-8859-1', 'UTF-8',$Kfile);
                                                                    //LOCAL SERVER - $filesArray[$fi]['fpath'] = $KfilePathWeb.'/'.iconv('WINDOWS-1257', 'UTF-8', $Kfile);
                                                                    $filesArray[$fi]['fpath'] = $KfilePathWeb.'/'.$Kfile;
                                                                    $filesArray[$fi]['isFile'] = 'Y';
                                                                    $filesArray[$fi]['FileType'] = 'SRT';
                                                                    $filesArray[$fi]['FileTitle'] = 'Sertificat file';
                                                                    $fi++;
                                                                }
                                                            }//end if
                                                            if($sertFile2 == substr($Kfile, 0, 11)){
                                                                $filesPath = $KfilePath.'/'.$Kfile;
                                                                if (is_file($filesPath)){
                                                                    // LOCAL SERVER - $filesArray[$fi]['fname'] =iconv('WINDOWS-1257', 'UTF-8', $Kfile); //iconv('ISO-8859-1', 'UTF-8',$Kfile);
                                                                    $filesArray[$fi]['fname'] = $Kfile;
                                                                    //LOCAL SERVER - $filesArray[$fi]['fpath'] = $KfilePathWeb.'/'.iconv('WINDOWS-1257', 'UTF-8', $Kfile);
                                                                    $filesArray[$fi]['fpath'] = $KfilePathWeb.'/'.$Kfile;
                                                                    $filesArray[$fi]['isFile'] = 'Y';
                                                                    $filesArray[$fi]['FileType'] = 'SRT';
                                                                    $filesArray[$fi]['FileTitle'] = 'Sertificat file';
                                                                    $fi++;
                                                                }
                                                            }//end if

                                                        }//end if
                                                    }//end foreach
                                                }//end if
                                            }else{//end if
                                                //echo "---NERA---<br>";
                                            }
                                            


                                        }//enc foreach
                                    }//end if GAM
                                }//end foreach
                            }//end if JOBArray
                        }//end foreach
                    }//end if SOArray
                }//end foreach PS




                /*
                //PASIIMAM FAILUS PRIE SO
                ///var/www/ngmod.aurika.lt/current/public/MNT/CERM_BRF/bstlyn__/bst
                $root_path = COMMON::getRootFolder();
                $RTFDir = $root_path."/MNT/CERM_BRF/bstlyn__/bst/" . substr($SO_ref, 0, 3)  . "/" . $SO_ref . "";
                $RTFDir = $root_path."MNT/CERM_BRF/bstlyn__/bst/" . substr($SO_ref, 0, 3)  . "/" . $SO_ref . "";
                $RezDir = "MNT/CERM_BRF/bstlyn__/bst/" . substr($SO_ref, 0, 3)  . "/" . $SO_ref . "";
                //$RTFfile = $root_path."/MNT/CERM_BRF/prb/ord/" . substr($InfoDuom['JobID'], 0, 3)  . "/" . $InfoDuom['JobID'] . ".prb";
                
                //var_dump($RTFDir);                
                //nuskaitom SO failus is 
                
                if(file_exists ( $RTFDir )){ //tikrinam ar uzmautinta (direktorija, kuri tikrai yra)
                    $scanArray = scandir($RTFDir);
                    //var_dump($scanArray);
                    if($scanArray){
                        foreach ($scanArray as $key => $file) {
                            if (!in_array($file,array(".",".."))){
                                $filesPath = $RTFDir.'/'.$file;
                                if (is_file($filesPath)){
                                    $filesArray[$fi]['fname'] = $file;
                                    $filesArray[$fi]['fpath'] = $RezDir.'/'.$file;
                                    $filesArray[$fi]['isFile'] = 'Y';
                                    $fi++;
                                }else{
                                    //$filesArray[$fi]['isFile'] = 'N';
                                }
                                //$fi++;
                            }//end if
                        }//end foreach
                    }//end if
                }//end if
                */


                
            }else{
                //
            }


            $fileStr = "";
            if($filesArray){
                $fileStr = "<table class='table_mini'>";
                foreach ($filesArray as $key => $ff) {
                    if($ff['FileType']=='SRT'){
                        $colorClass = 'class="linkRed"';
                    }else{
                        $colorClass = '';
                    }
                    $fileStr .= '<tr><td>'.$ff['FileType'].'</td><td><a href="'.$ff['fpath'].'" target = "_file" class="aLink" title="'.$ff['FileTitle'].'"><span '.$colorClass.'>'.$ff['fname'].'</span></a></td></tr>';
                }//end foreach
                $fileStr .= "</table>";
            }//end if

            //!!!!!! DEBUG
            //$this->var_dump($fileStr, "fileStr <hr>$qry<hr> ");//-----------------DEBUG


        $rez['fileArray']=$filesArray;
        $rez['fileStr']=$fileStr;
    return $rez;
}//end function



public function number_of_working_days($from, $to) {
    $workingDays = [1, 2, 3, 4, 5]; # date format = N (1 = Monday, ...)
    $holidayDays = array('*-01-01', '*-02-16', '*-03-11', '*-05-01', '*-06-24', '*-07-06', '*-08-15', '*-11-01','*-11-02', '*-12-24', '*-12-25', '*-12-26',  '2020-04-13');


    $from = new DateTime($from);
    $to = new DateTime($to);
    $to->modify('+1 day');
    $interval = new DateInterval('P1D');
    $periods = new DatePeriod($from, $interval, $to);

    $days = 0;
    foreach ($periods as $period) {
        if (!in_array($period->format('N'), $workingDays)) continue;
        if (in_array($period->format('Y-m-d'), $holidayDays)) continue;
        if (in_array($period->format('*-m-d'), $holidayDays)) continue;
        $days++;
    }

    if($days>0){$days--;}//padarom, kad nuo siandien iki rytojaus yra tik viena diena o ne dvi, taip reikia pagal Edita
    return $days;
}


public function getSOArrayBySiuntaUID($SiuntaUID){

        $SOArray = array ();

        if($SiuntaUID){
                //pagal siunta pasiimam PackingSlipus
                $qryPackingSlip = "
                        SELECT PackSlipID
                        from _TMS_keys
                        where SiuntaUID = '".$SiuntaUID."'
                ";
                $mssql = DBMSSqlCERM::getInstance();
                $PackingSlipArrayTmp = $mssql->querySql($qryPackingSlip, 1);

                $PackingSlipArray = array();
                if($PackingSlipArrayTmp){
                    foreach ($PackingSlipArrayTmp as $key => $PS) {
                        $PackingSlipArray[]=$PS['PackSlipID'];
                    }//end foreach
                }//end if

                //!!!!!! DEBUG
                //$this->var_dump($PackingSlipArray, "PackingSlipArray <hr>$qryPackingSlip<hr> ");//-----------------DEBUG

                if($PackingSlipArray){
                    $PackingSlipStrArray = "'" . implode("','", $PackingSlipArray)."'";

                    //nuskaitom SO array pagal PackingSlipus
                    $qry = "
                        SELECT TOP 1000
                            A.lbn__ref,
                            A.bst__ref,
                            A.afg__ref,
                            A.ord__ref
                            /*, A.* */
                        FROM bstlyn__ AS A
                        WHERE A.lbn__ref IN (".$PackingSlipStrArray.")
                        -- GROUP BY A.bst__ref
                    ";
                    $SOArrayTmp = $mssql->querySql($qry, 1);

                    //!!!!!! DEBUG
                    //$this->var_dump($SOArrayTmp, "SOArrayTmp <hr>$qry<hr> ");//-----------------DEBUG


                    if($SOArrayTmp){
                        foreach ($SOArrayTmp as $key => $SO) {
                            $SOArray[$SO['lbn__ref']]['lbn__ref'] = $SO['lbn__ref'];
                            $SOArray[$SO['lbn__ref']]['bst__arr'][$SO['bst__ref']]['bst__ref'] = $SO['bst__ref'];
                            $SOArray[$SO['lbn__ref']]['bst__arr'][$SO['bst__ref']]['ord__arr'][$SO['ord__ref']]['ord__ref'] = $SO['ord__ref'];
                            $SOArray[$SO['lbn__ref']]['bst__arr'][$SO['bst__ref']]['ord__arr'][$SO['ord__ref']]['afg__arr'][$SO['afg__ref']]['afg__ref'] = $SO['afg__ref'];
                        }
                    }//end if

                    //!!!!!! DEBUG
                    //$this->var_dump($SOArrayTmp, "SOArrayTmp <hr>$qry<hr> ");//-----------------DEBUG


                }//end if

        }//end if


    return $SOArray;
}//end function



public function getSOArrayByPackingSlipArray($PackingSlipArray){

        $RefArray = array ();
                /*
                $PackingSlipArray = array();
                if($PackingSlipArrayTmp){
                    foreach ($PackingSlipArrayTmp as $key => $PS) {
                        $PackingSlipArray[]=$PS['PackSlipID'];
                    }//end foreach
                }//end if
                */

                //!!!!!! DEBUG
                //$this->var_dump($PackingSlipArray, "PackingSlipArray <hr>$qryPackingSlip<hr> ");//-----------------DEBUG

                if($PackingSlipArray){
                    $PackingSlipStrArray = "'" . implode("','", $PackingSlipArray)."'";

                    //nuskaitom SO array pagal PackingSlipus
                    $qry = "
                        SELECT TOP 1000
                            A.lbn__ref,
                            A.bst__ref,
                            A.afg__ref,
                            A.ord__ref
                            /*, A.* */
                        FROM bstlyn__ AS A
                        WHERE A.lbn__ref IN (".$PackingSlipStrArray.")
                        -- GROUP BY A.bst__ref
                    ";
                    $mssql = DBMSSqlCERM::getInstance();
                    $SOArrayTmp = $mssql->querySql($qry, 1);

                    //!!!!!! DEBUG
                    //$this->var_dump($SOArrayTmp, "SOArrayTmp <hr>$qry<hr> ");//-----------------DEBUG


                    if($SOArrayTmp){
                        foreach ($SOArrayTmp as $key => $SO) {
                            $RefArray[$SO['lbn__ref']]['lbn__ref'] = $SO['lbn__ref'];
                            $RefArray[$SO['lbn__ref']]['bst__arr'][$SO['bst__ref']]['bst__ref'] = $SO['bst__ref'];
                            $RefArray[$SO['lbn__ref']]['bst__arr'][$SO['bst__ref']]['ord__arr'][$SO['ord__ref']]['ord__ref'] = $SO['ord__ref'];
                            $RefArray[$SO['lbn__ref']]['bst__arr'][$SO['bst__ref']]['ord__arr'][$SO['ord__ref']]['afg__arr'][$SO['afg__ref']]['afg__ref'] = $SO['afg__ref'];
                        }
                    }//end if

                    //!!!!!! DEBUG
                    //$this->var_dump($SOArrayTmp, "SOArrayTmp <hr>$qry<hr> ");//-----------------DEBUG


                }//end if



    return $RefArray;

}//end function



public function getSvoriaiByPackingSlipArray($packingSlipArray){

            //Array to Str
            if($packingSlipArray){
                    $PackingSlipStrArray = "'" . implode("','", $packingSlipArray)."'";
                    //$PackingSlipStrArray= substr($PackingSlipStrArray, 0,-2);

                    $qryRealSvoriai = "

                        select SUM(lbn__ref_brutt) as lbn__ref_brutt
                        from (
                        select SUM(CONVERT(float, ISNULL(inhoud02,0))) as lbn__ref_brutt
                        from afgsku__ 
                        where lyn__ref in (
                          select lyn__ref
                          from bstlyn__
                          where lbn__ref IN (".$PackingSlipStrArray.") and afg__ref in (select afg__ref from afgart__ where prkl_ref in (select prkl_ref from prodkl__ where omschr_8 = 'ROLLS')))
                        UNION
                        select SUM(CONVERT(float, ISNULL(inhoud02,0))) as lbn__ref_brutt
                        from afgbox__ 
                        where box__ref in (
                          select box__ref 
                          from afgsku__
                          where lyn__ref in (
                            select lyn__ref
                            from bstlyn__
                            where lbn__ref  IN (".$PackingSlipStrArray.") and afg__ref in (select afg__ref from afgart__ where prkl_ref in (select prkl_ref from prodkl__ where omschr_8 = 'BOXES'))))) A            
                    ";


                    
                    $mssql = DBMSSqlCERM::getInstance();
                    
                    $RezDuomSvoriai = $mssql->querySqlOneRow($qryRealSvoriai, 1);

                    $qrySvorioKorekc = "
                        SELECT SUM (SvorioKorekc) AS SvorioKorekcija
                        FROM (
                            select  DISTINCT lbn__ref, extgew__/1000 AS SvorioKorekc from bstlyn__ where lbn__ref IN (".$PackingSlipStrArray.") 
                        ) AS zzz                        
                    ";
                    $RezDuomSvoriaiKorekcija = $mssql->querySqlOneRow($qrySvorioKorekc, 1);

            }//end if

            $RezDuomSvoriai['SvorioKorekcija']=$RezDuomSvoriaiKorekcija['SvorioKorekcija'];
            $RezDuomSvoriai['GalutinisBrutto']=$RezDuomSvoriai['lbn__ref_brutt'] + $RezDuomSvoriaiKorekcija['SvorioKorekcija'];

            //!!!!!! DEBUG
            //$this->var_dump($RezDuomSvoriai, "RezDuomSvoriai <hr>$qryRealSvoriai<hr> ");//-----------------DEBUG

            return $RezDuomSvoriai;
}//end function





public function getPakuotesByPackingSlipArray($PackingSlipArray){


            //Array to Str
            if($PackingSlipArray){
                    $PackingSlipStrArray = "'" . implode("','", $PackingSlipArray)."'";
                    //$PackingSlipStrArray= substr($PackingSlipStrArray, 0,-2);

                    $qryPakuotes = "

                        SELECT TOP 1000
                        A.lyn__ref,
                        C.lbn__ref,
                        C.bst__ref,
                        A.sku__ref,
                        A.box__ref,
                        A.pal__ref,

                        -- SUM(CONVERT(float, ISNULL(afgsku__.inhoud02,0))) as Bbrutto,
                        A.inhoud02 AS SKUSvoris,
                        B.inhoud02 AS BOXSvoris,
                        B.inhoud04,
                        M.breedte_,
                        M.lengte__,
                        M.hoogte__

                        /*
                        bstlyn__.bst__ref,
                        afgsku__.lyn__ref,
                        afgsku__.pal__ref,
                        --afgsku__.sku__ref,
                        afgbox__.box__ref,
                        afgbox__.inhoud01,
                        afgbox__.inhoud02,
                        afgbox__.inhoud04,
                        artiky__.art_oms1,
                        artiky__.grammage,
                        artiky__.gramm___,
                        artiky__.breedte_,
                        artiky__.lengte__,
                        artiky__.hoogte__,
                        afgsku__.*
                        */

                        FROM
                        afgsku__ AS A
                        LEFT JOIN afgbox__ AS B ON A.box__ref=B.box__ref
                        LEFT JOIN artiky__ AS M ON M.art__ref=B.inhoud04
                        LEFT JOIN bstlyn__ AS C ON C.lyn__ref = A.lyn__ref
                        WHERE
                        -- afgbox__.inhoud04 <> '' and
                        A.lyn__ref <> '' AND
                        -- (afgsku__.pal__ref IS NULL OR afgsku__.pal__ref='' )AND 

                        -- C.lbn__ref = '358262' /* 1 BOX */
                        -- C.lbn__ref = '358268' /* DAUG BOX */
                        -- C.lbn__ref = '358254' /* DAUG PAL svoriai is ritineliu */
                        -- C.lbn__ref = '358246' /* 2 BOX-PAL -svoriai is dezuciu*/
                        -- C.lbn__ref = '358242' /* 2 BOX-PAL -svoriai is dezuciu*/
                        -- C.lbn__ref = '358271' /* daug BOX -svoriai is dezuciu*/
                        -- C.lbn__ref = '358248' /* 1 PAL svoriai is SKU*/
                        -- C.lbn__ref = '357305' /* NERA NIEKO */
                        -- C.lbn__ref = '358272' /* LAABAI daug BOX, nors turetu but ant paletes */
                        -- C.lbn__ref = '358256' /* yra 1 PAL 318 Kg o turi but 5 PAL 2301 kg */
                        C.lbn__ref IN (".$PackingSlipStrArray.")
                    ";


                    
                    $mssql = DBMSSqlCERM::getInstance();
                    
                    $RezDuomPakuotesi = $mssql->querySql($qryPakuotes, 1);


                    $PakuoesArray = array();
                    if($RezDuomPakuotesi){

                        //surenkam i atskiras paletes ir dezes
                        foreach ($RezDuomPakuotesi as $key => $pakuote) {
                            if($pakuote['sku__ref']){
                                if($pakuote['pal__ref'] AND $pakuote['box__ref']){
                                    //jeigu BOX->PAL
                                    //Sumuojam paletes ir svorius skaiciuojam is BOXSvoris sumuodami

                                    $PakuoesArray['P'.$pakuote['pal__ref']]['Svoris']+=$pakuote['BOXSvoris'];
                                    $PakuoesArray['P'.$pakuote['pal__ref']]['plotis']=80;
                                    $PakuoesArray['P'.$pakuote['pal__ref']]['ilgis']=120;
                                    $PakuoesArray['P'.$pakuote['pal__ref']]['aukstis']=170;
                                    $PakuoesArray['P'.$pakuote['pal__ref']]['tipas']='EP';
                                }else if($pakuote['pal__ref'] AND !$pakuote['box__ref']){
                                    //jeigu SKU->PAL
                                    //Sumuojam paletes ir svorius skaiciuojam is SKUSvoris sumuodami
                                    $PakuoesArray['P'.$pakuote['pal__ref']]['Svoris']+=$pakuote['SKUSvoris'];
                                    $PakuoesArray['P'.$pakuote['pal__ref']]['plotis']=80;
                                    $PakuoesArray['P'.$pakuote['pal__ref']]['ilgis']=120;
                                    $PakuoesArray['P'.$pakuote['pal__ref']]['aukstis']=170;
                                    $PakuoesArray['P'.$pakuote['pal__ref']]['tipas']='EP';
                                }else if (!$pakuote['pal__ref'] AND $pakuote['box__ref']){
                                    //jeigu BOX
                                    //Sumuojam dezutes ir svorius imam is BOXSvoris NEsumuodami, tiesiog irasydami
                                    $tmpSvoris = round($pakuote['BOXSvoris']);
                                    $tmpPlotis = round($pakuote['breedte_']/10);
                                    $tmpIlgis = round($pakuote['lengte__']/10);
                                    $tmpAukstiss = round($pakuote['hoogte__']/10);
                                    $PakuoesArray['B'.$pakuote['box__ref']]['Svoris']=$tmpSvoris;
                                    $PakuoesArray['B'.$pakuote['box__ref']]['plotis']=$tmpPlotis;
                                    $PakuoesArray['B'.$pakuote['box__ref']]['ilgis']=$tmpIlgis;
                                    $PakuoesArray['B'.$pakuote['box__ref']]['aukstis']=$tmpAukstiss;
                                    $PakuoesArray['B'.$pakuote['box__ref']]['tipas']='DD';
                                }else if(!$pakuote['pal__ref'] AND !$pakuote['box__ref']){
                                    //jeigu ritineliai (nei dezes nei paletes)
                                    //nieko nedarom, nes nezinom matmenu
                                    /*
                                    $PakuoesArray['PAK'][$pakuote['sku__ref']]['Svoris']=$pakuote['SKUSvoris'];
                                    $PakuoesArray['PAK'][$pakuote['sku__ref']]['plotis']=$pakuote['breedte_']; ???
                                    $PakuoesArray['PAK'][$pakuote['sku__ref']]['ilgis']=$pakuote['lengte__']; ???
                                    $PakuoesArray['PAK'][$pakuote['sku__ref']]['aukstis']=$pakuote['hoogte__']; ???
                                    $PakuoesArray['PAK'][$pakuote['sku__ref']]['tipas']='PK';
                                    */
                                }//end else lese else

                            }//end if
                        }//end foreach
                    }//end if



                    //sugrupuojam i vienodas paletes ir dezes
                    $PakuoesArrayGrouped = array();
                    if($PakuoesArray){
                        foreach ($PakuoesArray as $keyddd => $ddd) {
                            $tmpSvoris = round($ddd['Svoris']);
                            if(!$PakuoesArrayGrouped[$ddd['tipas'].'_'.$ddd['plotis'].'_'.$ddd['ilgis'].'_'.$ddd['aukstis'].'_'.$tmpSvoris]){
                                $PakuoesArrayGrouped[$ddd['tipas'].'_'.$ddd['plotis'].'_'.$ddd['ilgis'].'_'.$ddd['aukstis'].'_'.$tmpSvoris] = $ddd;
                                $PakuoesArrayGrouped[$ddd['tipas'].'_'.$ddd['plotis'].'_'.$ddd['ilgis'].'_'.$ddd['aukstis'].'_'.$tmpSvoris]['kiekis']=1;
                            }else{
                                $PakuoesArrayGrouped[$ddd['tipas'].'_'.$ddd['plotis'].'_'.$ddd['ilgis'].'_'.$ddd['aukstis'].'_'.$tmpSvoris]['kiekis']++;
                            }
                        }//end foreach
                    }//end if

            //!!!!!! DEBUG
            //$this->var_dump($PakuoesArrayGrouped, "PakuoesArrayGrouped <hr><hr> ");//-----------------DEBUG


                    //formuojam pakuociu koda
                    $PakKodas = "";
                    if($PakuoesArrayGrouped){
                        $i=1;
                        foreach ($PakuoesArrayGrouped as $keyID => $pak) {
                            $PakKodas .= "<div id='packD_".$i."' class='packD'>".$pak['kiekis']."|".$pak['tipas']."|".$pak['plotis']."x".$pak['ilgis']."x".$pak['aukstis']."|".$pak['Svoris']."<b><img src='img/ico_del_c.gif' id='del_".$i."' class='del_img' style='cursor: pointer;' /></b></div>";
                            $i++;
                        }
                        
                    }//end if

            }else{//end if
                //echo "----NERA PACKINGSLIPO --- ";
            }

            $RezDuomPakuotes['PakKodas']=$PakKodas;
            $RezDuomPakuotes['PakArray']=$PakuoesArray;

            //!!!!!! DEBUG
            //$this->var_dump($RezDuomPakuotes, "RezDuomPakuotes <hr>$qryPakuotes<hr> ");//-----------------DEBUG

            return $RezDuomPakuotes;
}//end function





public function getPakuotesByPackingSlipArrayNAV(){


            $PakuoesArray = array('NAVP001' =>  
                array (
                    'Svoris' => 1,
                    'plotis' => 32,
                    'ilgis' => 23.5,
                    'aukstis' => 19,
                    'tipas' => 'PK'
                )
            );


            $PakKodas = "<div id='packD_1' class='packD'>1|PK|32x23.5x19|1<b><img src='img/ico_del_c.gif' id='del_1' class='del_img' style='cursor: pointer;' /></b></div>";



            $RezDuomPakuotes['PakKodas']=$PakKodas;
            $RezDuomPakuotes['PakArray']=$PakuoesArray;

            //!!!!!! DEBUG
            $this->var_dump($RezDuomPakuotes, "RezDuomPakuotes <hr>$qryPakuotes<hr> ");//-----------------DEBUG

            return $RezDuomPakuotes;
}//end function






public function getPakuotesPrieSiuntos($siuntaNr){

    $SiuntosArray = array();
    if($siuntaNr){
        $qry = "
            SELECT 
                A.SiuntaUID,
                A.PakuotesNr,
                A.ManifestID
            FROM _TMS_Pak AS A
            WHERE A.SiuntaUID = '".$siuntaNr."'

        ";

        //Nuskaitom NewGam
        $mssql = DBMSSqlCERM::getInstance();
        $PakuotesPrieSiuntos = $mssql->querySql($qry, 1);


        if($PakuotesPrieSiuntos){
            foreach ($PakuotesPrieSiuntos as $key => $value) {
                $SiuntosArray[] = $value['PakuotesNr'];
            }
        }//end if

        //!!!!!! DEBUG
        //$this->var_dump($RezDuom, "RezDuom111 <hr>$qry<HR>L: $RefString<hr> ");//-----------------DEBUG
    }//end if


    return $SiuntosArray;

}//end function




public function getLynRefArray ($bst__ref){

    $LynRefString = '';
    $OrdRefString = '';
    $ProdRefString = '';

    if($this->is_ID($bst__ref)){
        $qry = "
            SELECT 
                A.lyn__ref as LynRef,
                A.ord__ref,
                A.afg__ref
            FROM bstlyn__ AS A
            WHERE A.bst__ref = '".$bst__ref."'

        ";

        //Nuskaitom NewGam
        
        $mssql = DBMSSqlCERM::getInstance();
        $RezDuom = $mssql->querySql($qry, 1);

        if($RezDuom){
            foreach ($RezDuom as $key => $value) {
                $LynRefString .= "'".$value['LynRef']."', ";
                $OrdRefString .= "".$value['ord__ref'].", ";
                $ProdRefString .= "".$value['afg__ref'].", ";
            }
            $LynRefString = substr($LynRefString, 0,-2);
            $OrdRefString = substr($OrdRefString, 0,-2);
            $ProdRefString = substr($ProdRefString, 0,-2);
        }//end if

        //!!!!!! DEBUG
        //$this->var_dump($RezDuom, "RezDuom111 <hr>$qry<HR>L: $RefString<hr> ");//-----------------DEBUG
    }//end if

    $rez['LynRefString']=$LynRefString;
    $rez['OrdRefString']=$OrdRefString;
    $rez['ProdRefString']=$ProdRefString;

    return $rez;
}//end function




/*  2019-09-27 A. Ramonas
   Saugom naujai suformuota SIUNTA
*/
public function savePakuote($OrdDuom){

    //tikrinam ar sie PackingSlipai dar nebuvo prideti prie tam tikros siuntos

    if($OrdDuom['Det_Gamyba']=='ETK'){
        // etikeciu sandeliui (duomenys is NAVISIONO) imam is kito lauko, nes jis neturi skaitmeniu packinsleepu, o turi OrderNr ir ne skaiciu
        $qry = "
            SELECT 
                COUNT (NAVOrder) AS KiekPS
            FROM _TMS_keys
            WHERE deleted<>1 AND NAVOrder IN ('".implode("','",str_replace(" ", "",$OrdDuom['PSlipArray']))."');
        ";
    }else{
        $qry = "
            SELECT 
                COUNT (PackSlipID) AS KiekPS
            FROM _TMS_keys
            WHERE deleted<>1 AND PackSlipID IN ('".implode("','",str_replace(" ", "",$OrdDuom['PSlipArray']))."');
        ";
    }

    //Nuskaitom NewGam
    $mssql = DBMSSqlCERM::getInstance();
    $ArYraPS = $mssql->querySqlOneRow($qry, 1);

    //!!!!!! DEBUG
    //$this->var_dump($ArYraPS, "qry <hr>$qry<hr> ");//-----------------DEBUG

    
    if($OrdDuom){
        if($ArYraPS['KiekPS']<=0){
        //foreach ($OrdDuom as $key => $PSlip) {
            //if($PSlip['PSlip']){


            /* sanitaizinam pries irasyma */
                            $OrdDuom['Det_SaliesKodas'] = trim($OrdDuom['Det_SaliesKodas']); 
                            $OrdDuom['Det_PostKodas'] = trim($OrdDuom['Det_PostKodas']); 
                            $OrdDuom['Det_Delivery_email'] = trim($OrdDuom['Det_Delivery_email']); 
                            $OrdDuom['Det_Delivery_contact_email'] = trim($OrdDuom['Det_Delivery_contact_email']); 
                            $OrdDuom['Det_Delivery_phone'] = trim($OrdDuom['Det_Delivery_phone']); 
                            $OrdDuom['Det_Delivery_contact_phone'] = trim($OrdDuom['Det_Delivery_contact_phone']); 


                            /* siuntejas */
                            $OrdDuom['Det_SiuntejoSaliesKodas'] = trim($OrdDuom['Det_SiuntejoSaliesKodas']);
                            $OrdDuom['Det_SiuntejoPostKodas'] = trim($OrdDuom['Det_SiuntejoPostKodas']);
                            $OrdDuom['Det_Siuntejo_email'] = trim($OrdDuom['Det_Siuntejo_email']);
                            $OrdDuom['Det_Siuntejo_phone'] = trim($OrdDuom['Det_Siuntejo_phone']);
                            $OrdDuom['Det_Siuntejo_contact_email'] = trim($OrdDuom['Det_Siuntejo_contact_email']);
                            $OrdDuom['Det_Siuntejo_contact_phone'] = trim($OrdDuom['Det_Siuntejo_contact_phone']);

                            /* dileris */
                            $OrdDuom['Det_DilerioSaliesKodas'] = trim($OrdDuom['Det_DilerioSaliesKodas']); 
                            $OrdDuom['Det_DilerioPostKodas'] = trim($OrdDuom['Det_DilerioPostKodas']); 
                            $OrdDuom['Det_Dilerio_email'] = trim($OrdDuom['Det_Dilerio_email']); 
                            $OrdDuom['Det_Dilerio_phone'] = trim($OrdDuom['Det_Dilerio_phone']); 
                            $OrdDuom['Det_Dilerio_contact_email'] = trim($OrdDuom['Det_Dilerio_contact_email']); 
                            $OrdDuom['Det_Dilerio_contact_phone'] = trim($OrdDuom['Det_Dilerio_contact_phone']); 




                try {
                        
                    //keiciam samatos lauka i TIKRINTA
                    //$wsql = 'UPDATE v1bon___ SET tstval02=\''.$NewStatus.'\' WHERE  bon__ref=\''.$EstimateID.'\' AND rowid=\''.$EstimatesStatusArray['EstROWID'].'\' ;';

                    //irasom siuntos duomenis
                    $siandien = date("Y-m-d H:i:s");
                    $sql = "
                        INSERT INTO _TMS_Siuntos (

                            Created, 

                            Expected_Shipment_Date,
                            Expected_Delivery_Date,

                            SvorisSum, 

                            VezejasCermID, 
                            VezejasCermShort, 
                            KlientasID, 

                            NeutralumasKod,

                            /*gavejas*/
                            GavejasID, 
                            ClientCompanyCode,
                            Gavejas,
                            AdresasID, 
                            Adresas, 
                            Delivery_street,
                            SaliesKodas, 
                            Miestas, 
                            PostKodas, 
                            Delivery_email,
                            Delivery_contact_email,
                            Delivery_phone,
                            Delivery_contact_phone,
                            Delivery_contact,

                            /* siuntejas */
                            SiuntejoID,
                            SiuntejoName,
                            SiuntejoAdresasID,
                            SiuntejoAdrF,
                            SiuntejoStreet,
                            SiuntejoMiestas,
                            SiuntejoSaliesKodas,
                            SiuntejoPostKodas,
                            Siuntejo_email,
                            Siuntejo_phone,
                            Siuntejo_contact,
                            Siuntejo_contact_email,
                            Siuntejo_contact_phone,

                            /* dileris */
                            DilerioID,
                            DilerioName,
                            DilerioAdresasID,
                            DilerioAdrF,
                            DilerioStreet,
                            DilerioMiestas,
                            DilerioSaliesKodas,
                            DilerioPostKodas,
                            Dilerio_email,
                            Dilerio_phone,
                            Dilerio_contact,
                            Dilerio_contact_email,
                            Dilerio_contact_phone,


                            Pakuotes, 
                            Sandelys, 

                            VezejasReal, 
                            VezejasUzsakyta, 
                            VezejasVeza, 
                            VezejasIsveze, 
                            VezejasPristate, 

                            SiuntosBusena, 
                            DocKrovVaztar, 
                            TrackingNr, 

                            Packing_slip_comment,
                            Delivery_comment,
                            ProdComment,

                            Doc1, 
                            Doc2, 
                            Doc3,
                            AttentionMail,
                            Express,
                            Pristat1012,
                            ArIPastomata

                        ) VALUES (

                            '".$siandien."', 

                            '1910-01-01',
                            '1910-01-01',

                            '".$OrdDuom['svorisBRUTTO']."', 

                            N'".$OrdDuom['Det_VezejasID']."', 
                            N'".str_replace("'", '`', trim($OrdDuom['Det_Vezejas']))."', 
                            N'".$OrdDuom['Det_KlientasID']."', 

                            N'".$OrdDuom['Det_NeutralumasKod']."',

                            /* gavejas */
                            N'".$OrdDuom['Det_GavejasID']."', 
                            N'".$OrdDuom['Det_ClientCompanyCode']."', 
                            N'".str_replace("'", '`', trim($OrdDuom['Det_Gavejas']))."', 
                            N'".$OrdDuom['Det_AdresasID']."', 
                            N'".str_replace("'", '`', trim($OrdDuom['Det_PristatAdrFull']))."', 
                            N'".str_replace("'", '`', trim($OrdDuom['Det_Street']))."',
                            N'".str_replace("'", '`', trim($OrdDuom['Det_SaliesKodas']))."', 
                            N'".str_replace("'", '`', trim($OrdDuom['Det_Miestas']))."', 
                            N'".str_replace("'", '`', trim($OrdDuom['Det_PostKodas']))."', 
                            N'".str_replace("'", '`', trim($OrdDuom['Det_Delivery_email']))."', 
                            N'".str_replace("'", '`', trim($OrdDuom['Det_Delivery_contact_email']))."', 
                            N'".str_replace("'", '`', trim($OrdDuom['Det_Delivery_phone']))."', 
                            N'".str_replace("'", '`', trim($OrdDuom['Det_Delivery_contact_phone']))."', 
                            N'".str_replace("'", '`', trim($OrdDuom['Det_Delivery_contact']))."', 

                            /* siuntejas */
                            N'".$OrdDuom['Det_SiuntejoID']."',
                            N'".str_replace("'", '`', trim($OrdDuom['Det_SiuntejoName']))."',
                            N'".$OrdDuom['Det_SiuntejoAdresasID']."',
                            N'".str_replace("'", '`', trim($OrdDuom['Det_SiuntejoAdrF']))."',
                            N'".str_replace("'", '`', trim($OrdDuom['Det_SiuntejoStreet']))."',
                            N'".str_replace("'", '`', trim($OrdDuom['Det_SiuntejoMiestas']))."',
                            N'".str_replace("'", '`', trim($OrdDuom['Det_SiuntejoSaliesKodas']))."',
                            N'".str_replace("'", '`', trim($OrdDuom['Det_SiuntejoPostKodas']))."',
                            N'".str_replace("'", '`', trim($OrdDuom['Det_Siuntejo_email']))."',
                            N'".str_replace("'", '`', trim($OrdDuom['Det_Siuntejo_phone']))."',
                            N'".str_replace("'", '`', trim($OrdDuom['Det_Siuntejo_contact']))."',
                            N'".str_replace("'", '`', trim($OrdDuom['Det_Siuntejo_contact_email']))."',
                            N'".str_replace("'", '`', trim($OrdDuom['Det_Siuntejo_contact_phone']))."',

                            /* dileris */
                            N'".$OrdDuom['Det_DilerioID']."',
                            N'".str_replace("'", '`', trim($OrdDuom['Det_DilerioName']))."',
                            N'".$OrdDuom['Det_DilerioAdresasID']."',
                            N'".str_replace("'", '`', trim($OrdDuom['Det_DilerioAdrF']))."',
                            N'".str_replace("'", '`', trim($OrdDuom['Det_DilerioStreet']))."',
                            N'".str_replace("'", '`', trim($OrdDuom['Det_DilerioMiestas']))."',
                            N'".str_replace("'", '`', trim($OrdDuom['Det_DilerioSaliesKodas']))."',
                            N'".str_replace("'", '`', trim($OrdDuom['Det_DilerioPostKodas']))."',
                            N'".str_replace("'", '`', trim($OrdDuom['Det_Dilerio_email']))."',
                            N'".str_replace("'", '`', trim($OrdDuom['Det_Dilerio_phone']))."',
                            N'".str_replace("'", '`', trim($OrdDuom['Det_Dilerio_contact']))."',
                            N'".str_replace("'", '`', trim($OrdDuom['Det_Dilerio_contact_email']))."',
                            N'".str_replace("'", '`', trim($OrdDuom['Det_Dilerio_contact_phone']))."',


                            N'".$OrdDuom['pakuotes']."', 
                            N'".$OrdDuom['Det_Gamyba']."', 

                            N'', 
                            '', 
                            '', 
                            '', 
                            '',  

                            '0', 
                            N'', 
                            N'', 

                            N'".str_replace("'", '`', trim($OrdDuom['Det_Packing_slip_comment']))."', 
                            N'".str_replace("'", '`', trim($OrdDuom['Det_DeliveryComment']))."', 
                            N'',

                            N'', 
                            N'', 
                            N'',
                            0,
                            N'".$OrdDuom['Det_Express']."',
                            ".$OrdDuom['PristatytiIki'].",
                            N'".$OrdDuom['Det_ArIPastomata']."'
                        );                    
                    ";

                    echo "<hr>+++++<br>".$sql."<hr>";

                    $wmssql = DBMSSqlCERM::getInstance();
                    $retSQL = $wmssql->execSql($sql, 1);
                    $testing = $retSQL > 0;
                    $test[$test_name] &= $testing;

                    var_dump($retSQL);

                    if ($testing) {
                        //Saugom rysius siuntos su packingSlipais
                        if($retSQL){//jeigu issisaugojo 
                            $PaduotesID = $retSQL;
                            $packingSlipArray = $OrdDuom['PSlipArray'];
                            if($packingSlipArray){
                                foreach ($packingSlipArray as $key1 => $PSvalue) {
                                    
                                    if($OrdDuom['Det_Gamyba']=='ETK'){
                                        $fakePackingSlip = str_replace('UZS', '9', $PSvalue);
                                        $sqlIDX = "
                                            INSERT INTO _TMS_keys (
                                                SiuntaUID, 
                                                PackSlipID, 
                                                NAVOrder, 
                                                PackSvorisSum
                                            ) VALUES (
                                                '".$PaduotesID."', 
                                                '".$fakePackingSlip."',
                                                '".$PSvalue."', 
                                                '".$OrdDuom['svorisBRUTTO']."'
                                            );                    
                                        ";
                                    }else{
                                        $sqlIDX = "
                                            INSERT INTO _TMS_keys (
                                                SiuntaUID, 
                                                PackSlipID, 
                                                PackSvorisSum
                                            ) VALUES (
                                                '".$PaduotesID."', 
                                                '".$PSvalue."', 
                                                '".$OrdDuom['svorisBRUTTO']."'
                                            );                    
                                        ";
                                    }

                                    //echo "<hr>".$sqlIDX."<hr>";

                                    //$wmssql = DBMSSqlCERM::getInstance();
                                    $retSQLIDX = $wmssql->execSql($sqlIDX, 1);
                                    $testingIdx = $retSQLIDX > 0;
                                    //$test[$test_name] &= $testingIdx;

                                    //var_dump($retSQL);

                                    if (!(string)$ex) {
                                        $ret = 'OK';
                                        //echo "OK - ".$EstimateID." ".$NewStatus." <br>";
                                    } else{
                                        $this->AddError((string)$ex);
                                        $ret = 'NOT OK DB';
                                    }

                                }//end foreach
                            }else{//end if
                                $this->AddError("Duomenys neišsaugoti, nes nėra PackingSlip numerio.");
                                $ret = 'NOT OK DB';
                            }//end else

                        }else{//end if
                            $this->AddError("Duomenys neišsaugoti, nes nėra PackingSlip numerio.");
                            $ret = 'NOT OK DB';
                        }

                        //$ret = 'OK';
                        //echo "OK - ".$EstimateID." ".$NewStatus." <br>";
                    } else{
                        //$this->AddError('Įvyko duomenų bazės klaida !');
                        $ret = 'OK DB1';
                        //echo "*****NOT OK DB1 ".$EstimateID." ".$NewStatus." -RezID:".$retSQL."-<br>";
                    }

                } catch (Exception $ex) {
                    $this->AddError((string)$ex);
                    $ret = 'NOT OK DB';
                }//catch

            //}else{
            //    $ret = 'NOT OK PackingSlip';
                //echo "*****NOT OK Packing Slip<br>";
            //}
        //}//end foreach
        }else{//end if KiekPS
            $this->AddError("PackingSlip'as jau priskirtas vienai iš siuntų.");
            $ret = 'NOT OK DB7';
        }
    }else{
        $ret = 'NOT OK PackingSlipArray';
        $this->AddError("Nėra saugojamų duomenų.");
    }

    $rez['OK']=$ret;
    if($PaduotesID){
        $rez['SiuntaID'] = $PaduotesID;
    }else{
        $rez['SiuntaID'] = '';
    }

    return $rez;
}//end function






public function delSiuntaData($SiuntaID){

    $mssql = DBMSSqlCERM::getInstance();
    
    if($SiuntaID){
                try {
                    //trinam (pazymim, kad irasas istrintas) siuntos duomenis
                    $wsqlS = 'UPDATE TOP (1) _TMS_Siuntos SET deleted=\'1\' WHERE  uid=\''.$SiuntaID.'\' ;';
                    //echo "--- $wsqlS---";
                    $retSiuntos = $mssql->execSql($wsqlS, 1);
                    //$testingIdx = $retSiuntos > 0;
                    //$test[$test_name] &= $testingIdx;

                    //var_dump($retSQL);

                    if (!(string)$ex) {
                            $ret['Siunta'] = 'Deleted';


                            //trinam surisima su PackingSlipais (pazymim, kad istrinta)
                            $wsqlK = 'UPDATE _TMS_keys SET deleted=\'1\' WHERE  SiuntaUID=\''.$SiuntaID.'\' ;';
                            //echo "--- $wsqlK---";
                            $retKeys = $mssql->execSql($wsqlK, 1);
                            //$testingIdx = $retKeys > 0;
                            //$test[$test_name] &= $testingIdx;

                            //var_dump($retSQL);

                            if (!(string)$ex) {
                                $ret['SiuntaKeys'] = 'Deleted';
                            } else{
                                $this->AddError((string)$ex);
                                $ret['SiuntaKeys'] = 'Not deleted';
                            }



                            //trinam surisima su pakuotemis (pazymim, kad istrinta), nors tokiu neturi buti, nes neleidzia trinti jeigu siunta jau uzregistruota pas vezeja
                            $wsqlP = 'UPDATE _TMS_Pak SET deleted=\'1\' WHERE  SiuntaUID=\''.$SiuntaID.'\' ;';
                            //echo "--- $wsqlP---";
                            $retKeys = $mssql->execSql($wsqlP, 1);
                            //$testingIdx = $retKeys > 0;
                            //$test[$test_name] &= $testingIdx;

                            //var_dump($retSQL);

                            if (!(string)$ex) {
                                $ret['SiuntaPaks'] = 'Deleted';
                            } else{
                                $this->AddError((string)$ex);
                                $ret['SiuntaPaks'] = 'Not deleted';
                            }

                            //nuskaitom patikrinimui ir kitu duomenu paemimui
                            $qryTest = "
                                SELECT 
                                    *
                                FROM _TMS_Siuntos
                                WHERE uid = '".$SiuntaID."';

                            ";
                            $mssql = DBMSSqlCERM::getInstance();
                            $SiuntaDuomTest = $mssql->querySqlOneRow($qryTest, 1);

                            //!!!!!! DEBUG
                            //$this->var_dump($SiuntaDuomTest, "qry <hr>$qryTest<hr> ");//-----------------DEBUG



                            $pavyko = 1;
                            $sendMail = 'N';
                            $sendMailMail = '';
                            if ($SiuntaDuomTest['deleted'] == '1'){
                                $pavykoStr = 'Siunta:Del|';
                                
                                if($SiuntaDuomTest['VezejasReal']=='SCHENKER' AND $SiuntaDuomTest['VezejoSiuntNr']){
                                    $sendMail = 'Y';    
                                    //$sendMailMail = 'booking.vilnius@dbschenker.com';
                                    $delSiuntaNrPasVezeja = $SiuntaDuomTest['VezejoSiuntNr'];
                                    $delSiuntaVezejasReal = $SiuntaDuomTest['VezejasReal'];
                                }
                                
                            }else{
                                $pavyko = 0;
                                $pavykoStr = 'Siunta:NotDel|';
                            }

                            if ($ret['SiuntaKeys'] == 'Deleted'){
                                $pavykoStr .= 'Keys:Del|';
                            }else{
                                $pavyko = 0;
                                $pavykoStr .= 'Keys:NotDel|';
                            }

                            if ($ret['SiuntaPaks'] == 'Deleted'){
                                $pavykoStr .= 'Paks:Del|';
                            }else{
                                $pavyko = 0;
                                $pavykoStr .= 'Paks:NotDel|';
                            }

                            //uzregistruojam i istorija
                            $siandien = date("Y-m-d H:i:s");
                            $sqlHis = "
                                INSERT INTO _TMS_His (

                                    SiuntaUID, 
                                    Created,
                                    HisGroup,
                                    HisAction, 
                                    Owner, 
                                    OwnerUID, 
                                    Comment, 

                                    successfully 
                                ) VALUES (
                                    '".$SiuntaID."',
                                    '".$siandien."', 

                                    'SIUNTA_DEL',
                                    'delSiuntaManualy',

                                    N'".$_SESSION['user_name']."', 
                                    N'".$_SESSION['user_id']."', 

                                    N'Siunta trinama rankiniu būdu iš sandėlio modulio', 
                                    '".$pavyko."'
                                );                    
                            ";

                            //echo "<hr>".$sql."<hr>";
                            //echo "--- $sqlHis---";
                            //$mssql = DBMSSqlCERM::getInstance();
                            $retSQL = $mssql->execSql($sqlHis, 1);



                    } else{
                        $this->AddError((string)$ex);
                        $ret['Siunta'] = 'Not deleted';
                    }

                } catch (Exception $ex) {
                    $this->AddError((string)$ex);
                    $ret = 'NOT OK DB';
                }//catch
    }else{//end if
        $pavyko = 0;
        $this->AddError('Nežinomas siuntos numeris.');
    }

    if($pavyko==1){$rez['OK']='OK';}else{$rez['OK']='NOTOK';}
    $rez['Comment']=$this->getErrorArrayAsStr();
    $rez['sendMail']=$sendMail;    
    //$rez['sendMailMail']=$sendMailMail;
    $rez['delSiuntaNrPasVezeja']=$delSiuntaNrPasVezeja;
    $rez['delSiuntaVezejasReal']=$delSiuntaVezejasReal;


    return $rez;
}//end function



public function changeAutoPatikraBusena($SiuntaID, $NewAPBusena){

    $mssql = DBMSSqlCERM::getInstance();
    
    if($SiuntaID AND $NewAPBusena){
        $siandien = date("Y-m-d H:i:s");
        $darbuotojasName=  $_SESSION['user_name'];
        $darbuotojasNGMOD_UID= $_SESSION['user_id'];
                try {


                    $wsqlS = 'UPDATE TOP (1) _TMS_Siuntos 
                              SET 
                                AutoPatikra=\''.$NewAPBusena.'\', 
                                AutoPatikraDate=\''.$siandien.'\', 
                                AutoPatikraDarbuotojas=\''.$darbuotojasName.'\', 
                                AutoPatikraDarbuotojasUID=\''.$darbuotojasNGMOD_UID.'\' 
                              WHERE  uid=\''.$SiuntaID.'\' ;
                    ';
                    echo "--- $wsqlS---";
                    $retSiuntos = $mssql->execSql($wsqlS, 1);

                    if (!(string)$ex) {
                        $rez['OK']='OK';
                    } else{
                        $this->AddError("Duomenų bazės klaida.");
                        $this->AddError((string)$ex);
                        $rez['OK']='NOTOK';
                    }

                } catch (Exception $ex) {
                    $this->AddError("Duomenų bazės klaida.");
                    $this->AddError((string)$ex);
                    $rez['OK']='NOTOK';
                }//catch
    }else{//end if
        $rez['OK']='NOTOK';
        $this->AddError('Nežinomas siuntos numeris.');
    }

    $rez['Comment']=$this->getErrorArrayAsStr();
    $rez['SiuntaUpd']=$SiuntaID;
    $rez['NewAPBusena']=$NewAPBusena;

    return $rez;
}//end function



public function getManifestList($date){

            if($date){

                    $qryMan = "
                        SELECT Manifest, Sandelys
                        FROM  _TMS_Siuntos                 
                        WHERE KrovinysReg = 'Y' AND SiuntaUzregistruota > '".$date."' AND Manifest>'' AND deleted=0
                        GROUP BY Manifest, Sandelys
                    ";
                    
                    $mssql = DBMSSqlCERM::getInstance();
                    $RezDuom= $mssql->querySql($qryMan, 1);

            }else{//end if
                $RezDuom = array();
            }

            //!!!!!! DEBUG
            //$this->var_dump($RezDuom, "RezDuom <hr>$qryMan<hr> ");//-----------------DEBUG

            return $RezDuom;
}//end function







/* ********************************************** TRANSPORT ****************************************************************************************** */

public function getSvoriaiByLynArray($LynRefArray){

            //Array to Str
            if($LynRefArray){
                    $LynRefStrArray = "'" . implode("','", $LynRefArray)."'";
                    //$PackingSlipStrArray= substr($PackingSlipStrArray, 0,-2);

                    $qryRealSvoriai = "

                        select SUM(ref_brutt) as lbn__ref_brutt
                        from (
                            select SUM(CONVERT(float, ISNULL(inhoud02,0))) as ref_brutt
                            from afgsku__ 
                            where lyn__ref in (
                              select lyn__ref
                              from bstlyn__
                              where lyn__ref IN (".$LynRefStrArray.") and afg__ref in (select afg__ref from afgart__ where prkl_ref in (select prkl_ref from prodkl__ where omschr_8 = 'ROLLS')))
                            UNION
                            select SUM(CONVERT(float, ISNULL(inhoud02,0))) as ref_brutt
                            from afgbox__ 
                            where box__ref in (
                              select box__ref 
                              from afgsku__
                              where lyn__ref in (
                                select lyn__ref
                                from bstlyn__
                                where lyn__ref  IN (".$LynRefStrArray.") and afg__ref in (select afg__ref from afgart__ where prkl_ref in (select prkl_ref from prodkl__ where omschr_8 = 'BOXES'))))
                        ) A            
                    ";


                    
                    $mssql = DBMSSqlCERM::getInstance();
                    
                    $RezDuomSvoriai = $mssql->querySqlOneRow($qryRealSvoriai, 1);

                    $qrySvorioKorekc = "
                        SELECT SUM (SvorioKorekc) AS SvorioKorekcija
                        FROM (
                            select  DISTINCT lbn__ref, extgew__/1000 AS SvorioKorekc from bstlyn__ where lbn__ref IN (".$LynRefStrArray.") 
                        ) AS zzz                        
                    ";
                    $RezDuomSvoriaiKorekcija = $mssql->querySqlOneRow($qrySvorioKorekc, 1);

            }//end if

            $RezDuomSvoriai['SvorioKorekcija']=$RezDuomSvoriaiKorekcija['SvorioKorekcija'];
            if(!is_numeric($RezDuomSvoriai['SvorioKorekcija'])){
                $RezDuomSvoriai['SvorioKorekcija'] = 0;
            }
            $RezDuomSvoriai['GalutinisBrutto']=$RezDuomSvoriai['lbn__ref_brutt'] + $RezDuomSvoriaiKorekcija['SvorioKorekcija'];

            //!!!!!! DEBUG
            //$this->var_dump($RezDuomSvoriai, "RezDuomSvoriai <hr>$qryRealSvoriai<hr> ");//-----------------DEBUG

            return $RezDuomSvoriai;
}//end function




/*20191003 A. Ramonas
Isveda lista pagal paieskos parametrus (Transporto modulis)
Sarasas SalesOrderiu pakavimui 
*/
public function getOrderTranspList($SearchDuom){
    $OrderList = array();

    $qry = "
    SELECT *
    FROM (
        SELECT TOP 1000 
            A.lyn__ref,
            A.lbn__ref AS PackingSlip,
            A.vrz__tst AS Shipped, /* 0-NotApplicable; 1-Not yet ready tro ship, N-ToDoo, Y-Done, Z-Returned */
            A.bst__ref, 
            A.afg__ref,
            A.ord__ref,
            C.naam____ AS ClientName,

            CASE
                WHEN A.tstval03='1000' THEN 'KEG'
                WHEN A.tstval03='2000' THEN 'KPG'
                WHEN A.tstval03='3000' THEN 'ETK1'
                ELSE 'Unknown'
            END AS 'ShippedFrom',

            CASE
                WHEN A.tstval04='500' THEN 'Not printed'
                WHEN A.tstval04='1000' THEN 'Printed'
                ELSE 'Unknown'
            END AS 'PickingSlipPrinted',

            CASE
                WHEN A.tstval06='500' THEN 'Not printed'
                WHEN A.tstval06='1000' THEN 'Printed'
                ELSE 'Unknown'
            END AS 'DeliveryNotePrinted',

            CASE
                WHEN A.trn__srt='1'
                THEN C.naam____
                ELSE L.lev_loc1 
            END AS 'Delivery_Company',

            left(convert(char,A.vrzv_dat,120),10) AS 'Expected_Shipment_Date',
            left(convert(char,A.levv_dat,120),10) AS 'Expected_Delivery_Date',
            left(convert(char,A.vrz__dat,120),10) AS 'Real_Shipped_Date',
            A.b_netto_ AS 'NETTO_estimated',
            A.koloma11 AS 'NETTO_picked',
            A.aant_pak AS 'Packs_picked',
            A.aant_pal AS 'Pallets_picked',
            A.trn__srt AS 'Delivery_type',  /* 0 - pristatoma į AURIKA sandėlį, 1 - pristatoma kliento pagrindiniu adresu,  2,3,4 - pristatoma kliento adresu */
            A.lok__ref AS 'Delivery_AddressID',
            CASE
                WHEN A.trn__srt='1'
                THEN C.land_ref
                ELSE L.land_ref  
            END AS 'Delivery_country_code',
            CASE
                WHEN A.trn__srt='1'
                THEN C.post_ref
                ELSE L.post_ref  
            END AS 'Delivery_post',
            CASE
                WHEN A.trn__srt='1'
                THEN C.postnaam
                ELSE L.postnaam  
            END AS 'Delivery_city',
            CASE
                WHEN A.trn__srt='1'
                THEN C.straat__
                ELSE L.lev_loc3 
            END AS 'Delivery_street',

            CASE
                WHEN A.trn__srt='1'
                THEN C.county__
                ELSE L.county__ 
            END AS 'Delivery_County',
            CASE
                WHEN A.trn__srt='1'
                THEN C.wijk____
                ELSE L.wijk____
            END AS 'Delivery_District',


            CASE
                WHEN A.trn__srt='1'
                THEN C.telex___
                ELSE L.email___ 
            END AS 'Delivery_email',
            CASE
                WHEN A.trn__srt='1'
                THEN C.telefoon
                ELSE L.telefoon 
            END AS 'Delivery_phone',
            CASE
                WHEN A.trn__srt='1'
                THEN (O.knp__vnm + ' ' + O.knp__nam)
                ELSE (K.knp__vnm + ' ' + K.knp__nam) 
            END AS 'Delivery_contact',
            CASE
                WHEN A.trn__srt='1'
                THEN O.email___
                ELSE K.email___ 
            END AS 'Delivery_contact_email',
            CASE
                WHEN A.trn__srt='1'
                THEN O.tel_auto
                ELSE K.tel_auto 
            END AS 'Delivery_contact_phone' ,

            
            A.lyn__ref AS lyyn_ref, 
            
            A.uit__lay AS Picking, 
            A.lbn__ref AS PackingSlipFinal, 
            A.l_aantal AS DeliveredQuantity,
            A.l_aantal AS PickedQuantity,
            A.l_antpak AS PikedQuontityPacks,
            A.l_antpal AS PikedQuontityPallets,
            A.b_aantal AS OrderetQuantity,
            A.b_antpak AS ExpectedQuontityPacks,
            A.b_antpal AS ExpectedQuontityPallets,
            A.levb_dat AS PackingSlipDate,
            A.lvb___ex AS NoOfPicPackingSlip,
            A.lvb__lay AS LayoutPackingSlip,
            A.lvb__ref AS PackingSlipComposedID,
            PA.in__vrrd AS InStrockQuantity,
            PA.in_produ AS InProduction,

            A.levv_dat,
            A.levvwref,
            A.leverkod,
            A.levb_dat,
            A.levtrcom,
            A.levvodat,

            (A.koloma11 + A.l_tarra_) AS GrossWeightPicked,
            (A.b_netto_ + A.b_tarra_) AS GrossWeightOrdered,


            /* PRODUCT DATE */
            P.afg_oms1 AS ProductName,
            P.kla__ref AS ProdClientID,
            P.kla__rpn AS ProdClientKey,
            P.commkern AS ProdComment,

            /* SIUNTU REGISTRAS */
            
            S.uid AS PakSiuntosNr,
            S.Created AS PakSiuntaSukurta,
            S.Pakuotes AS PakPakuotesStr,
            S.SvorisSum AS PakSvorisSum,

            /* STATUSAI */
            A.fac__tst AS ToByInvoiced,
            A.dok__dat AS ToByInvoicedDate,

            A.lev__tst AS DeliveryStatus, /* N-Not delivered */
            A.fac__tst AS InvoiceStatus, /* 0- Not yet invoiced; N- To invoice; W- In process, Y - Invoiced */
            A.levb_dat AS DateForPackingSlip,
            A.lvb__lay AS PackingSlipLayout,


            /* COMMENTS */
            A.lbn__com AS 'Packing_slip_comment',
            A.lev__com AS 'ShipmentComment',
            A.levtrcom AS 'CommentAfterDelivery',

            /* TRANSPORT */
            A.lev__ref as TransporterID,
            A.lev__rpn AS TransporterKeyword,
            A.trn__ref AS TransportZoneID,
            TZ.taal___1 AS TransportZone,
            TR.trnt_oms AS TransportRate,

            /* JOB */
            JV.int_cont AS InternalContact,
            A.fiat____ AS Aproved,
            J.off__ref AS Job,

            /* TMS */
            TK.SiuntaUID,

          
          '----' AS EndQry
            /*, A. */
        FROM bstlyn__ AS A
        LEFT JOIN klabas__ AS C ON A.kla__ref = C.kla__ref
        LEFT JOIN levlok__ AS L ON A.lok__ref=L.lok__ref
        LEFT JOIN afgart__ AS P ON A.afg__ref=P.afg__ref
        LEFT JOIN afgant__ AS PA ON A.afg__ref=PA.afg__ref
        LEFT JOIN konper__ AS K ON A.lok__ref=K.lok__ref AND L.lvknpref=K.knp__ref
        LEFT JOIN konpkl__ AS O ON A.kla__ref=O.kla__ref AND A.knp__ref=O.knp__ref
        LEFT JOIN _TMS_Keys AS TK ON A.lbn__ref=TK.PackSlipID AND TK.deleted<>1
        LEFT JOIN _TMS_Siuntos AS S ON TK.SiuntaUID=S.uid AND S.deleted <> 1
        LEFT JOIN trnzn___ AS TZ ON A.trn__ref = TZ.trn__ref
        /* LEFT JOIN trntar__ AS TR ON A.trn__ref = TR.trn__ref */
        LEFT JOIN trntar__ AS TR ON A.trnt_ref = TR.trnt_ref 
        LEFT JOIN v4off___ AS J ON A.ord__ref = J.off__ref
        LEFT JOIN v4bon___ AS JV ON J.bon__ref = JV.bon__ref
        /* LEFT JOIN _TMS_keys AS TMS ON A.lbn__ref = TMS.PackSlipID AND TMS.deleted <> 1 */

    ";

    /*

        WHERE 
          -- A.lbn__ref IS NOT NULL AND A.lbn__ref <> ''
          -- A.bst__ref = '274276'
          --A.bst__ref = '276974'
          -- OR A.bst__ref = '275157'
        ORDER BY A.lyn__ref DESC    
    */    



    // $WHERE = "WHERE A.lbn__ref IS NOT NULL AND A.lbn__ref <>'' ";
    $WHERE = "WHERE A.lyn__ref <>'' ";

    $yraTikslus = "N";//jeigu irasyta samataID/CalculationID/NewGamID, tai ignoruoja kai kuriuos kitus filtrus, tokius kaip data

    //!!!!!! DEBUG
    //$this->var_dump($SearchDuom, "SearchDuom <hr>$qry<hr> ");//-----------------DEBUG


    if($SearchDuom){


        //PackingSlip
        if($SearchDuom['sPackingSlip']){
            $WHERE .= " AND A.lbn__ref = '".$SearchDuom['sPackingSlip']."' " ;
            $yraTikslus = "Y";
        }//end if


        //sOrderID 
        if($SearchDuom['sOrderID']){
            $WHERE .= " AND A.bst__ref = '".$SearchDuom['sOrderID']."' " ;
            $yraTikslus = "Y";
        }//end if


        //sOrderID 
        if($SearchDuom['sGamID']){
            $WHERE .= " AND A.sfg__ref = '".$SearchDuom['sGamID']."' " ;
            $yraTikslus = "Y";
        }//end if


        if ($yraTikslus == "N"){
            if ($SearchDuom['sDatNuo'] AND $SearchDuom['sDatIki'] ){
                $WHERE .= " AND ( A.vrzv_dat >= '".$SearchDuom['sDatNuo']."' AND  A.vrzv_dat <= '".$SearchDuom['sDatIki']."') " ;
            }else{
                $SearchDuom['sDatNuo'] = date("Y-m-d 00:00");//siandien pradzia
                $SearchDuom['sDatIki'] = date("Y-m-d 23:59");//siandien pabaiga
                $WHERE .= " AND ( A.vrzv_dat >= '".$SearchDuom['sDatNuo']."' AND  A.vrzv_dat <= '".$SearchDuom['sDatIki']."') " ;
            }
        }

        //sOrderID 
        if($SearchDuom['sVezejas']){
            $WHERE .= " AND A.lev__rpn LIKE N'%".$SearchDuom['sVezejas']."%' " ;
        }//end if


        if($SearchDuom['sKlientas']){
            $WHERE .= " AND C.naam____ LIKE N'%".$SearchDuom['sKlientas']."%' " ;
        }//end if



        if($SearchDuom['sSandelys'] == '1000' OR $SearchDuom['sSandelys'] == '2000'){
            $WHERE .= " AND A.tstval03 = '".$SearchDuom['sSandelys']."' " ;
        }elseif($SearchDuom['sSandelys'] == 'Kita'){
            $WHERE .= " AND (A.tstval03 <> '1000' AND A.tstval03 <> '2000') " ;
        }else{
            // jeigu visi tai nieko nedarom
        }

        switch ($SearchDuom['sShiped']) {
            case '0':
            case '1':
            case 'N':
            case 'Y':
                $WHERE .= " AND A.vrz__tst = '".$SearchDuom['sShiped']."' " ;
                break;
            
            default:
                // Jeigu All tai nedarom nieko
                break;
        }

        switch ($SearchDuom['sInvoiced']) {
            case '0':
            case 'N':
            case 'W':
            case 'Y':
                $WHERE .= " AND A.fac__tst = '".$SearchDuom['sInvoiced']."' " ;
                break;
            
            default:
                // Jeigu All tai nedarom nieko
                break;
        }





    }//end if SearchDuom

    

    $qry .= $WHERE;

    $qry .= "
     ) AS sourceTable 
     ";

    switch ($SearchDuom['sRusiavimas']){
        case 'TR_ExpShipDate':
            $sortColum = ' Expected_Shipment_Date ';
            break;
        case 'TR_ExpDelDate':
            $sortColum = ' Expected_Delivery_Date ';
            break;
        case 'TR_Customer':
            $sortColum = ' Delivery_Company ';
            break;
        case 'TR_Order':
            $sortColum = ' bst__ref ';
            break;
        case 'TR_PackingSlip':
            $sortColum = ' PackingSlip ';
            break;
        case 'TR_TranspZone':
            $sortColum = ' TransportZone ';
            break;
        case 'TR_ShipComment':
            $sortColum = ' ShipmentComment ';
            break;
        case 'TR_Country':
            $sortColum = ' Delivery_country_code ';
            break;
        case 'TR_TranspRate':
            $sortColum = ' TransportRate ';
            break;
        case 'TR_DelivAdres':
            $sortColum = ' Delivery_street ';
            break;
        default:

            break;
    }

    if($sortColum){
        $ORDER = ' ORDER BY '.$sortColum.' '.$SearchDuom['sRusiavimasAscDesc'].', bst__ref ASC '; 
    }else{
        $ORDER = ' ORDER BY bst__ref ASC '; 
    }
    $qry .= $ORDER; /* " ORDER  BY  A.NewGamUID DESC"; */

    //Nuskaitom Orderius
    
    $mssql = DBMSSqlCERM::getInstance();
    $OrderList = $mssql->querySql($qry, 1);


    //!!!!!! DEBUG
    //$this->var_dump($OrderList, "OrderListTemp <hr>$qry<hr> ");//-----------------DEBUG


    return $OrderList;
}//end function



/*20191007 A. Ramonas
grazina sarasa lyn__ref'u kurie tinka vienam vezimui (pakuotei).
turi atitikti sandelys(KEG/KPG), adresas, gavejas, vezejas, isvezimo data
*/
public function getLynAlternat($LynID){
    $OrderList = array();

    //pasiimam duomenys pacheckinto checkListo
    $qry = "

        SELECT TOP 1000 
            A.lyn__ref,
            A.lbn__ref AS PackingSlip,
            A.vrz__tst AS Shipped, /* 0-NotApplicable; 1-Not yet ready tro ship, N-ToDoo, Y-Done, Z-Returned */
            A.bst__ref, 
            CASE
                WHEN A.tstval03='1000' THEN 'KEG'
                WHEN A.tstval03='2000' THEN 'KPG'
                WHEN A.tstval03='3000' THEN 'ETK1'
                ELSE 'Unknown'
            END AS 'ShippedFrom',

            CASE
                WHEN A.trn__srt='1'
                THEN C.naam____
                ELSE L.lev_loc1 
            END AS 'Delivery_CompanyID',

            left(convert(char,A.vrzv_dat,120),10) AS 'Expected_Shipment_Date',
            A.trn__srt AS 'Delivery_type',  /* 0 - pristatoma į AURIKA sandėlį, 1 - pristatoma kliento pagrindiniu adresu,  2,3,4 - pristatoma kliento adresu */
            A.lok__ref AS 'Delivery_AddressID',
            CASE
                WHEN A.trn__srt='1'
                THEN C.post_ref
                ELSE L.post_ref  
            END AS 'Delivery_post',
            /* TRANSPORT */
            A.lev__ref as TransporterID,
            A.lev__rpn AS TransporterKeyword,
            A.trn__ref AS TransportZoneID

        FROM bstlyn__ AS A
        LEFT JOIN klabas__ AS C ON A.kla__ref = C.kla__ref
        LEFT JOIN levlok__ AS L ON A.lok__ref=L.lok__ref
        WHERE lyn__ref = '".$LynID."'

    ";
    
    $mssql = DBMSSqlCERM::getInstance();
    $OrderDate = $mssql->querySqlOneRow($qry, 1);

    //!!!!!! DEBUG
    //$this->var_dump($OrderDate, "OrderDate <hr>$qry<hr> ");//-----------------DEBUG


    $qryG = "
        SELECT  
            lyn__ref
        FROM (

                        SELECT TOP 1000 
                            A.lyn__ref,
                            A.lbn__ref AS PackingSlip,
                            A.vrz__tst AS Shipped, /* 0-NotApplicable; 1-Not yet ready tro ship, N-ToDoo, Y-Done, Z-Returned */
                            A.bst__ref, 
                            CASE
                                WHEN A.tstval03='1000' THEN 'KEG'
                                WHEN A.tstval03='2000' THEN 'KPG'
                                WHEN A.tstval03='3000' THEN 'ETK1'
                                ELSE 'Unknown'
                            END AS 'ShippedFrom',

                            CASE
                                WHEN A.trn__srt='1'
                                THEN C.naam____
                                ELSE L.lev_loc1 
                            END AS 'Delivery_CompanyID',

                            left(convert(char,A.vrzv_dat,120),10) AS 'Expected_Shipment_Date',
                            A.trn__srt AS 'Delivery_type',  /* 0 - pristatoma į AURIKA sandėlį, 1 - pristatoma kliento pagrindiniu adresu,  2,3,4 - pristatoma kliento adresu */
                            A.lok__ref AS 'Delivery_AddressID',
                            CASE
                                WHEN A.trn__srt='1'
                                THEN C.post_ref
                                ELSE L.post_ref  
                            END AS 'Delivery_post',
                            /* TRANSPORT */
                            A.lev__ref as TransporterID,
                            A.lev__rpn AS TransporterKeyword,
                            A.trn__ref AS TransportZoneID
                        FROM bstlyn__ AS A
                        LEFT JOIN klabas__ AS C ON A.kla__ref = C.kla__ref
                        LEFT JOIN levlok__ AS L ON A.lok__ref=L.lok__ref
                        WHERE 
                            A.trn__srt = '".$OrderDate['Delivery_type']."'
                            AND A.lok__ref = '".$OrderDate['Delivery_AddressID']."'
                            AND A.lev__ref = '".$OrderDate['TransporterID']."'
                            AND left(convert(char,A.vrzv_dat,120),10) = '".$OrderDate['Expected_Shipment_Date']."'

        ) AS AAA
        WHERE   
                ShippedFrom = '".$OrderDate['ShippedFrom']."'
                
                AND Delivery_CompanyID = N'".$OrderDate['Delivery_CompanyID']."'
                
    ";
    
    $mssql = DBMSSqlCERM::getInstance();
    $OrderList = $mssql->querySql($qryG, 1);


    //!!!!!! DEBUG
    //$this->var_dump($OrderList, "--OrderList <hr>$qryG<hr> ");//-----------------DEBUG


    return $OrderList;
}//end function






/*20190925 A. Ramonas

*/
public function getPackLinData($LinRefArray){
    $RezDuom = array();


    if($LinRefArray){
        $LinRefArrayStr = "'" . implode("','", $LinRefArray)."'";
        $qry = "
            SELECT TOP 1000 
                A.lyn__ref,
                A.lbn__ref AS PackingSlip,
                A.vrz__tst AS Shipped, /* 0-NotApplicable; 1-Not yet ready tro ship, N-ToDoo, Y-Done, Z-Returned */
                A.lev__tst AS DeliveryStatus, /* N-Not delivered */
                A.fac__tst AS InvoiceStatus, /* 0- Not yet invoiced; N- To invoice; W- In process, Y - Invoiced */
                A.levb_dat,
                A.bst__ref,
                A.ord__ref, 
                A.afg__ref,
                A.kla__ref,
                C.naam____ AS ClientName,

                CASE
                    WHEN A.tstval03='1000' THEN 'KEG'
                    WHEN A.tstval03='2000' THEN 'KPG'
                    WHEN A.tstval03='3000' THEN 'ETK1'
                    ELSE 'Unknown'
                END AS 'ShippedFrom',

                A.lok__ref AS 'Delivery_CompanyID',

                CASE
                    WHEN A.trn__srt='1'
                    THEN C.naam____
                    ELSE L.lev_loc1 
                END AS 'Delivery_Company',

                A.lev__ref as TransporterID,
                A.lev__rpn AS TransporterKeyword,
                left(convert(char,A.vrzv_dat,120),10) AS 'Expected_Shipment_Date',
                left(convert(char,A.levv_dat,120),10) AS 'Expected_Delivery_Date',

                A.aant_pak AS 'Packs_picked',
                A.aant_pal AS 'Pallets_picked',
                A.lbn__com AS 'Packing_slip_comment',
                A.levtrcom AS 'Delivery_comment',
                A.trn__srt AS 'Delivery_type',  /* 0 - pristatoma į AURIKA sandėlį, 1 - pristatoma kliento pagrindiniu adresu,  2,3,4 - pristatoma kliento adresu */
                A.lok__ref AS 'Delivery_AddressID',
                CASE
                    WHEN A.trn__srt='1'
                    THEN C.land_ref
                    ELSE L.land_ref  
                END AS 'Delivery_country_code',
                CASE
                    WHEN A.trn__srt='1'
                    THEN C.post_ref
                    ELSE L.post_ref  
                END AS 'Delivery_post',
                CASE
                    WHEN A.trn__srt='1'
                    THEN C.postnaam
                    ELSE L.postnaam  
                END AS 'Delivery_city',
                CASE
                    WHEN A.trn__srt='1'
                    THEN C.straat__
                    ELSE L.lev_loc3 
                END AS 'Delivery_street',

                CASE
                    WHEN A.trn__srt='1'
                    THEN C.county__
                    ELSE L.county__ 
                END AS 'Delivery_County',
                CASE
                    WHEN A.trn__srt='1'
                    THEN C.wijk____
                    ELSE L.wijk____
                END AS 'Delivery_District',


                CASE
                    WHEN A.trn__srt='1'
                    THEN C.telex___
                    ELSE L.email___ 
                END AS 'Delivery_email',
                CASE
                    WHEN A.trn__srt='1'
                    THEN C.telefoon
                    ELSE L.telefoon 
                END AS 'Delivery_phone',
                CASE
                    WHEN A.trn__srt='1'
                    THEN (O.knp__vnm + ' ' + O.knp__nam)
                    ELSE (K.knp__vnm + ' ' + K.knp__nam) 
                END AS 'Delivery_contact',
                CASE
                    WHEN A.trn__srt='1'
                    THEN O.email___
                    ELSE K.email___ 
                END AS 'Delivery_contact_email',
                CASE
                    WHEN A.trn__srt='1'
                    THEN O.tel_auto
                    ELSE K.tel_auto 
                END AS 'Delivery_contact_phone' ,

               
                A.uit__lay AS Picking, 
                A.lbn__ref AS PackingSlipFinal, 
                A.l_antpak AS PikedQuontityPacks,
                A.l_antpal AS PikedQuontityPallets,
                A.b_antpak AS OrderedQuontityPacks,
                A.b_antpal AS OrderedQuontityPallets,

                A.levb_dat AS PackingSlipDate,
                A.lvb___ex AS NoOfPicPackingSlip,
                A.lvb__lay AS LayoutPackingSlip,
                A.lvb__ref AS PackingSlipComposedID,

                /* PRODUCT DATE */
                P.afg_oms1 AS ProductName,
                P.kla__ref AS ProdClientID,
                P.kla__rpn AS ProdClientKey,
                P.commkern AS ProdComment



                /*, A.**/
            FROM bstlyn__ AS A
            LEFT JOIN klabas__ AS C ON A.kla__ref = C.kla__ref
            LEFT JOIN levlok__ AS L ON A.lok__ref=L.lok__ref
            LEFT JOIN afgart__ AS P ON A.afg__ref=P.afg__ref
            LEFT JOIN konper__ AS K ON A.lok__ref=K.lok__ref AND L.lvknpref=K.knp__ref
            LEFT JOIN konpkl__ AS O ON A.kla__ref=O.kla__ref AND A.knp__ref=O.knp__ref

            WHERE A.lyn__ref IN (".$LinRefArrayStr.")

        ";

            //Nuskaitom NewGam
            
            $mssql = DBMSSqlCERM::getInstance();
            $RezDuomTmp = $mssql->querySql($qry, 1);
            //!!!!!! DEBUG
            //$this->var_dump($RezDuomTmp, "RezDuom <hr>$qry<hr> ");//-----------------DEBUG


            /* tvarkom struktura */
            $OrderList = array();
            $det_ShipmentDate = "";
            $det_Salis = "";
            $det_Adresas = "";
            $det_PostCode = "";
            $det_ShipmentDate = "";

            /*
            $ShipmentFromStr = "";
            $YraKlaidu = "N";
            $KlaidaComment = "";

            $TransporterID = '';
            $ClientID = '';
            $Delivery_CompanyID = '';
            $Delivery_AddressID = '';
            $Delivery_country_code = '';
            $Delivery_city = '';
            $Delivery_post = '';
            */


            if($RezDuomTmp){
                $KlaidaCommentTmp="";
                $PackingSlipArray = array();
                $LynRefArray = array();

                foreach ($RezDuomTmp as $key => $OrdDate) {

                    $LynRefArray[$OrdDate['lyn__ref']]=$OrdDate['lyn__ref'];
                    //tikrinam  KLAIDAS
                    if(trim($OrdDate['PackingSlip'])){
                        //Kaupiam PackinSlipu sarasa
                        if(strpos($PackSlipStr, $OrdDate['PackingSlip'])===false){
                            $PackSlipStr .= $OrdDate['PackingSlip'].", ";
                            $PackingSlipArray[$OrdDate['PackingSlip']]=$OrdDate['PackingSlip'];
                        }
                        //Kaupiam Produktu sarasa
                        if($OrdDate['afg__ref']){
                           if(strpos($ProdIDStr, $OrdDate['afg__ref'])===false){
                                $ProdIDStr .= $OrdDate['afg__ref'].", ";
                           }
                        }
                        //Kaupiam Jobu sarasa
                        if($OrdDate['ord__ref']){
                           if(strpos($JobIDStr, $OrdDate['ord__ref'])===false){
                                $JobIDStr .= $OrdDate['ord__ref'].", ";
                           }
                        }
                    }else{
                       $YraKlaidu = "Y"; 
                       $KlaidaCommentTmp = "Nenurodytas PackingSlip numeris.\n";
                       if(strpos($KlaidaComment, $KlaidaCommentTmp)===false){
                            $KlaidaComment .= $KlaidaCommentTmp;//nekartojam tu paciu pranesimu
                       }
                    }

                    //tikrinam ar tas pats klientas
                    if(trim($OrdDate['Delivery_Company'])){
                        if($Delivery_Company AND $Delivery_Company!=$OrdDate['Delivery_Company']){
                           $YraKlaidu = "Y"; 
                           $KlaidaCommentTmp = "Krovinys turi būti tam pačiam gavėjui.\n";
                           if(strpos($KlaidaComment, $KlaidaCommentTmp)===false){
                                $KlaidaComment .= $KlaidaCommentTmp;//nekartojam tu paciu pranesimu
                           }
                        }else{
                            $Delivery_Company = $OrdDate['Delivery_Company'];
                        }
                    }else{
                       $YraKlaidu = "Y"; 
                       $KlaidaCommentTmp = "Nenurodytas gavėjas (įmonė)\n";
                       if(strpos($KlaidaComment, $KlaidaCommentTmp)===false){
                            $KlaidaComment .= $KlaidaCommentTmp;//nekartojam tu paciu pranesimu
                       }
                    }

                    //tikrinam ar tas pats vezejas
                    if(trim($OrdDate['TransporterKeyword'])){
                        if($VezejasStr AND $VezejasStr!=$OrdDate['TransporterKeyword']){
                           $YraKlaidu = "Y"; 
                           $KlaidaCommentTmp = "Turi būti vienas krovinio vežėjas.\n";
                           if(strpos($KlaidaComment, $KlaidaCommentTmp)===false){
                                $KlaidaComment .= $KlaidaCommentTmp;//nekartojam tu paciu pranesimu
                           }
                        }else{
                            $VezejasStr = $OrdDate['TransporterKeyword'];
                        }
                    }else{
                       $YraKlaidu = "Y"; 
                       $KlaidaCommentTmp = "Nenurodytas vežėjas\n";
                       if(strpos($KlaidaComment, $KlaidaCommentTmp)===false){
                            $KlaidaComment .= $KlaidaCommentTmp;//nekartojam tu paciu pranesimu
                       }
                    }

                    //tikrinam ar tapati data
                    if($OrdDate['Expected_Shipment_Date'] AND $OrdDate['Expected_Shipment_Date'] > '2019-01-01'){
                        if($ShipmentDateStr AND $ShipmentDateStr!=$OrdDate['Expected_Shipment_Date']){
                           $YraKlaidu = "Y"; 
                           $KlaidaCommentTmp = "Išvežimo data turi būti ta pati.\n";
                           if(strpos($KlaidaComment, $KlaidaCommentTmp)===false){
                                $KlaidaComment .= $KlaidaCommentTmp;//nekartojam tu paciu pranesimu
                           }
                        }else{
                            $ShipmentDateStr = $OrdDate['Expected_Shipment_Date'];
                        }
                    }else{
                       $YraKlaidu = "Y"; 
                       $KlaidaCommentTmp = "Nenurodyta išvežimo data\n";
                       if(strpos($KlaidaComment, $KlaidaCommentTmp)===false){
                            $KlaidaComment .= $KlaidaCommentTmp;//nekartojam tu paciu pranesimu
                       }
                    }

                    //tikrinam ar tas pats sandelys
                    if(trim($OrdDate['ShippedFrom'])){
                        if($ShipmentFromStr AND $ShipmentFromStr!=$OrdDate['ShippedFrom']){
                           $YraKlaidu = "Y"; 
                           $KlaidaCommentTmp = "Turi būti atkraunama iš to pačio sandėlio.\n";
                           if(strpos($KlaidaComment, $KlaidaCommentTmp)===false){
                                $KlaidaComment .= $KlaidaCommentTmp;//nekartojam tu paciu pranesimu
                           }
                        }else{
                            $ShipmentFromStr = $OrdDate['ShippedFrom'];
                        }
                    }else{
                       $YraKlaidu = "Y"; 
                       $KlaidaCommentTmp = "Nenurodytas atkrovimo sandėlys\n";
                       if(strpos($KlaidaComment, $KlaidaCommentTmp)===false){
                            $KlaidaComment .= $KlaidaCommentTmp;//nekartojam tu paciu pranesimu
                       }
                    }

                    //tikrinam ar tas pats pasto kodas
                    if(trim($OrdDate['Delivery_post'])){
                        if($AdreasasStr AND $AdreasasStr!=trim ($OrdDate['Delivery_post'])){
                           $YraKlaidu = "Y"; 
                           $KlaidaCommentTmp = "Pristatymo adresas turi būti vienodas.\n";
                           if(strpos($KlaidaComment, $KlaidaCommentTmp)===false){
                                $KlaidaComment .= $KlaidaCommentTmp;//nekartojam tu paciu pranesimu
                           }
                        }else{
                            $AdreasasStr = trim ($OrdDate['Delivery_post']);
                            $AdreasasFullStr = $OrdDate['Delivery_street'].", ".$OrdDate['Delivery_city'].", ".$OrdDate['Delivery_country_code'].", ".$OrdDate['Delivery_post'];
                        }
                    }else{
                       $YraKlaidu = "Y"; 
                       $KlaidaCommentTmp = "Nenurodytas pristatymo adresas.\n";
                       if(strpos($KlaidaComment, $KlaidaCommentTmp)===false){
                            $KlaidaComment .= $KlaidaCommentTmp;//nekartojam tu paciu pranesimu
                       }
                    }


                    $TransporterID = $OrdDate['TransporterID'];
                    $ClientID = $OrdDate['kla__ref'];
                    $Delivery_CompanyID = $OrdDate['Delivery_CompanyID'];
                    $Delivery_AddressID = $OrdDate['Delivery_AddressID'];
                    $Delivery_country_code = $OrdDate['Delivery_country_code'];
                    $Delivery_city = $OrdDate['Delivery_city'];
                    $Delivery_post = $OrdDate['Delivery_post'];
                    $ClientStr = $OrdDate['ClientName'];
                    



                    $OrderList[$OrdDate['PackingSlip']]['PackingSlip']=$OrdDate['PackingSlip'];
                    $OrderList[$OrdDate['PackingSlip']]['Expected_Shipment_Date']=$OrdDate['Expected_Shipment_Date'];
                    $OrderList[$OrdDate['PackingSlip']]['Expected_Delivery_Date']=$OrdDate['Expected_Delivery_Date'];
                    $OrderList[$OrdDate['PackingSlip']]['Real_Shipped_Date']=$OrdDate['Real_Shipped_Date'];

                    $OrderList[$OrdDate['PackingSlip']]['DeliveryStatus']=$OrdDate['DeliveryStatus'];
                    $OrderList[$OrdDate['PackingSlip']]['InvoiceStatus']=$OrdDate['InvoiceStatus'];
                    $OrderList[$OrdDate['PackingSlip']]['bst__ref']=$OrdDate['bst__ref'];
                    $OrderList[$OrdDate['PackingSlip']]['ClientName']=$OrdDate['ClientName'];
                    $OrderList[$OrdDate['PackingSlip']]['ClientID']=$OrdDate['kla__ref'];
                    $OrderList[$OrdDate['PackingSlip']]['ShippedFrom']=$OrdDate['ShippedFrom'];
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_Company']=$OrdDate['Delivery_Company'];
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_CompanyID']=$OrdDate['Delivery_CompanyID'];
                    
                    $OrderList[$OrdDate['PackingSlip']]['TransporterID']=$OrdDate['TransporterID'];
                    $OrderList[$OrdDate['PackingSlip']]['TransporterKeyword']=$OrdDate['TransporterKeyword'];
                    $OrderList[$OrdDate['PackingSlip']]['Packs_picked']=$OrdDate['Packs_picked'];
                    $OrderList[$OrdDate['PackingSlip']]['Pallets_picked']=$OrdDate['Pallets_picked'];

                    $OrderList[$OrdDate['PackingSlip']]['PikedQuontityPacks']=$OrdDate['PikedQuontityPacks'];
                    $OrderList[$OrdDate['PackingSlip']]['PikedQuontityPallets']=$OrdDate['PikedQuontityPallets'];
                    $OrderList[$OrdDate['PackingSlip']]['OrderedQuontityPacks']=$OrdDate['OrderedQuontityPacks'];
                    $OrderList[$OrdDate['PackingSlip']]['OrderedQuontityPallets']=$OrdDate['OrderedQuontityPallets'];

                    $OrderList[$OrdDate['PackingSlip']]['Packing_slip_comment']=$OrdDate['Packing_slip_comment'];
                    $OrderList[$OrdDate['PackingSlip']]['DeliveryComment']=$OrdDate['DeliveryComment'];
                    $OrderList[$OrdDate['PackingSlip']]['CommentAfterDelivery']=$OrdDate['CommentAfterDelivery'];
                    
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_type']=$OrdDate['Delivery_type'];
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_AddressID']=$OrdDate['Delivery_AddressID'];
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_country_code']=$OrdDate['Delivery_country_code'];
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_post']=$OrdDate['Delivery_post'];

                    $OrderList[$OrdDate['PackingSlip']]['Delivery_city']=$OrdDate['Delivery_city'];
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_street']=$OrdDate['Delivery_street'];

                    $OrderList[$OrdDate['PackingSlip']]['Delivery_County']=$OrdDate['Delivery_County'];
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_District']=$OrdDate['Delivery_District'];
                    
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_email']=trim ($OrdDate['Delivery_email']);
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_phone']=trim ($OrdDate['Delivery_phone']);
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_contact']=$OrdDate['Delivery_contact'];
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_contact_email']=trim ($OrdDate['Delivery_contact_email']);
                    $OrderList[$OrdDate['PackingSlip']]['Delivery_contact_phone']=trim ($OrdDate['Delivery_contact_phone']);
                    $OrderList[$OrdDate['PackingSlip']]['PackingSlipDate']=$OrdDate['PackingSlipDate'];
                    $OrderList[$OrdDate['PackingSlip']]['PackingSlipComposedID']=$OrdDate['PackingSlipComposedID'];
                    $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['lyn__ref']=$OrdDate['lyn__ref'];
                    $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['ord__ref']=$OrdDate['ord__ref'];
                    $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['ProductID']=$OrdDate['afg__ref'];
                    $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['ProductName']=$OrdDate['ProductName'];
                    $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['ProdClientID']=$OrdDate['ProdClientID'];
                    $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['ProdClientKey']=$OrdDate['ProdClientKey'];
                    $OrderList[$OrdDate['PackingSlip']]['DET'][$OrdDate['lyn__ref']]['ProdComment']=$OrdDate['ProdComment'];



                }//end foreach


                //!!!!!! DEBUG
                //$this->var_dump($PackingSlipArray, "PackingSlipArray <hr><hr> ");//-----------------DEBUG



                $KLAIDOS['Error'] = $YraKlaidu;
                $KLAIDOS['ErrorComments'] = $KlaidaComment;
                if(strlen($PackSlipStr)>2){
                    $PackSlipStr = substr($PackSlipStr, 0,-2);
                }
                if(strlen($ProdIDStr)>2){
                    $ProdIDStr = substr($ProdIDStr, 0,-2);
                }
                if(strlen($JobIDStr)>2){
                    $JobIDStr = substr($JobIDStr, 0,-2);
                }

            }//end if



            //pasiimam svorius ir  svoriu korekcija 
            if($YraKlaidu != "Y"){
                //skaiciuoja svorius visam packing slipui (nesvarbu kiek pazymetu lyn__ref)
                //$RezDuomSvoriai = $this->getSvoriaiByPackingSlipArray($PackingSlipArray);

                //skaiciuoja svorius tik pazymetiems lyn__ref'ams
                $RezDuomSvoriai = $this->getSvoriaiByLynArray($LynRefArray);
            }


            //$RezDuomSvoriai['SvorioKorekcija']=$RezDuomSvoriai['SvorioKorekcija'];
            //$RezDuomSvoriai['GalutinisBrutto']=$RezDuomSvoriai['lbn__ref_brutt'] + $RezDuomSvoriai['SvorioKorekcija'];
    }//end if


    $RezDuom['SVORIAI'] = $RezDuomSvoriai;
    $RezDuom['packingOrders'] = $OrderList;
    $RezDuom['ERROR'] = $KLAIDOS;

    $RezDuom['SHORT']['PackSlipStr'] = $PackSlipStr;
    $RezDuom['SHORT']['ProdIDStr'] = $ProdIDStr;
    $RezDuom['SHORT']['JobIDStr'] = $JobIDStr;
    $RezDuom['SHORT']['ClientStr'] = $ClientStr;
    $RezDuom['SHORT']['Delivery_Company'] = $Delivery_Company;
    
    $RezDuom['SHORT']['VezejasStr'] = $VezejasStr;
    $RezDuom['SHORT']['ShipmentDateStr'] = $ShipmentDateStr;
    $RezDuom['SHORT']['ShipmentFromStr'] = $ShipmentFromStr;
    $RezDuom['SHORT']['PostCodeStr'] = $AdreasasStr;
    $RezDuom['SHORT']['AdreasasFullStr'] = $AdreasasFullStr;

    $RezDuom['SHORT']['Det_VezejasID'] = $TransporterID;
    $RezDuom['SHORT']['Det_KlientasID'] = $ClientID;
    $RezDuom['SHORT']['Det_GavejasID'] = $Delivery_CompanyID;
    $RezDuom['SHORT']['Det_AdresasID'] = $Delivery_AddressID;
    $RezDuom['SHORT']['Det_SaliesKodas'] = $Delivery_country_code;
    $RezDuom['SHORT']['Det_Miestas'] = $Delivery_city;
    $RezDuom['SHORT']['Det_PostKodas'] = $Delivery_post;


    //!!!!!! DEBUG
    //$this->var_dump($RezDuom, "RezDuom <hr>$qry<hr> ");//-----------------DEBUG

    return $RezDuom;
}//end function



    public function convertServiceCodeToName ($serviceCode){
        switch ($serviceCode) {
            case '07':
                $serviceName = 'Express'; //UPS
                break;
            case '11':
                $serviceName = 'UPS Standart';//UPS
                break;
            case '65':
                $serviceName = 'UPS Saver';//UPS
                break;
            
            default:
                $serviceName = $serviceCode;
                break;
        }

        return $serviceName;
    }//end function



public function detSiuntaGreenData($SiuntaUID){


        if($SiuntaUID){

                //Pasiimam duomenys is siuntos
                $qrySiunta = "
                        SELECT *
                        from _TMS_Siuntos
                        where uid = '".$SiuntaUID."'
                ";
                $mssql = DBMSSqlCERM::getInstance();
                $SiuntaData = $mssql->querySqlOneRow($qrySiunta, 1);

                if($SiuntaData){
                    $SiuntaData['ServiceName'] = $this->convertServiceCodeToName ($SiuntaData['Service']);
                }


                //Pasiimam pakuociu duomenis
                $qrySiunta = "
                        SELECT *
                        from _TMS_Pak
                        where SiuntaUID = '".$SiuntaUID."'  AND deleted=0
                ";
                $mssql = DBMSSqlCERM::getInstance();
                $SiuntaPak = $mssql->querySql($qrySiunta, 1);



                //pagal siunta pasiimam PackingSlipus
                $qryPackingSlip = "
                        SELECT PackSlipID
                        from _TMS_keys
                        where SiuntaUID = '".$SiuntaUID."'  AND deleted=0
                ";
                $mssql = DBMSSqlCERM::getInstance();
                $PackingSlipArrayTmp = $mssql->querySql($qryPackingSlip, 1);


                $PackingSlipArray = array();
                if($PackingSlipArrayTmp){
                    foreach ($PackingSlipArrayTmp as $key => $PS) {
                        $PackingSlipArray[]=$PS['PackSlipID'];
                    }//end foreach
                }//end if



                //!!!!!! DEBUG
                //$this->var_dump($PackingSlipArray, "PackingSlipArray <hr>$qryPackingSlip<hr> ");//-----------------DEBUG

                if($PackingSlipArray){
                    $PackingSlipStrArray = "'" . implode("','", $PackingSlipArray)."'";

                    //nuskaitom SO array pagal PackingSlipus
                    $qry = "
                        SELECT TOP 1000
                            A.lbn__ref,
                            A.bst__ref,
                            A.afg__ref,
                            A.ord__ref
                            /*, A.* */
                        FROM bstlyn__ AS A
                        WHERE A.lbn__ref IN (".$PackingSlipStrArray.")
                        -- GROUP BY A.bst__ref
                    ";
                    $SOArrayTmp = $mssql->querySql($qry, 1);

                    //!!!!!! DEBUG
                    //$this->var_dump($SOArrayTmp, "SOArrayTmp <hr>$qry<hr> ");//-----------------DEBUG

                    $PSArray = array();
                    $SOArray = array();
                    $JOBArray = array();
                    $GAMArray = array();

                    if($SOArrayTmp){
                        //susirenkam visus PackingSlipus
                        foreach ($SOArrayTmp as $key => $SO) {
                            $PSArray[$SO['lbn__ref']] = $SO['lbn__ref'];
                        }//end foreach

                        //susirenkam visus SO
                        foreach ($SOArrayTmp as $key => $SO) {
                            $SOArray[$SO['bst__ref']] = $SO['bst__ref'];
                        }//end foreach

                        //susirenkam visus JOB
                        foreach ($SOArrayTmp as $key => $SO) {
                            $JOBArray[$SO['ord__ref']] = $SO['ord__ref'];
                        }//end foreach

                        //susirenkam visus GAM
                        foreach ($SOArrayTmp as $key => $SO) {
                            $GAMArray[$SO['afg__ref']] = $SO['afg__ref'];
                        }//end foreach
                    }//end if

                    //!!!!!! DEBUG
                    //$this->var_dump($SOArrayTmp, "SOArrayTmp <hr>$qry<hr> ");//-----------------DEBUG



                    //susirenkam failus
                        //susiformuojam reikiama masyva is PS SO JOB ir GAM
                        $RefArray = $this->getSOArrayBySiuntaUID($SiuntaUID);

                        //!!!!!! DEBUG
                        $this->var_dump($RefArray, "RefArray <hr>$qry<hr> ");//-----------------DEBUG

                        //pasiimam failus
                        $this_PS_files_array_str=$this->getSOFilesArray($RefArray);


                    $RezArray['ERROR']['Error'] = 'OK';
                    $RezArray['ERROR']['ErrorComments'] = "";

                }

        }else{//end if
            echo "NO SIUNTA ID";
            $RezArray['ERROR']['Error'] = 'NOT OK';
            $RezArray['ERROR']['ErrorComments'] = "Negautas siuntos ID";
        }

        $RezArray['SiuntaData'] = $SiuntaData;
        $RezArray['SiuntaPak'] = $SiuntaPak;
        $RezArray['PSArray'] = $PSArray;
        $RezArray['SOArray'] = $SOArray;
        $RezArray['JOBArray'] = $JOBArray;
        $RezArray['GAMArray'] = $GAMArray;
        $RezArray['Files'] = $this_PS_files_array_str;


        //!!!!!! DEBUG
        $this->var_dump($RezArray, "RezArray <hr>$qry<hr> ");//-----------------DEBUG


    return $RezArray;    

}//end function











/* ********************************************************************** SIUNTOS ************************************************************************************* */
public function getSiuntosList($sDuom){



    $SiuntosList = array();

    //tvarkom paieska
    $WHERE = "";

    if($sDuom['sSiuntaID']){
        $WHERE .= " AND A.uid = '".$sDuom['sSiuntaID']."' ";
    }

    if($sDuom['sSiuntReg']=='Y'){
        $WHERE .= " AND A.KrovinysReg = 'Y ' ";
    }else if ($sDuom['sSiuntReg']=='N'){
        $WHERE .= " AND (A.KrovinysReg <> 'Y '  OR A.KrovinysReg IS NULL ) ";
    }

    if($sDuom['sSiuntaRegDate']){
        $WHERE .= " AND (A.Created >= '".$sDuom['sSiuntaRegDate']." 00:00:00.000' AND  A.Created <= '".$sDuom['sSiuntaRegDate']." 23:59:59.000' ) ";
    }

    if($sDuom['sSandelys']){
        $WHERE .= " AND A.Sandelys = '".$sDuom['sSandelys']."' ";
    }

    if($sDuom['sKlientas']){
        $WHERE .= " AND C.naam____ LIKE '%".$sDuom['sKlientas']."%' ";
    }

    if($sDuom['sVezejas']){
        $WHERE .= " AND A.VezejasCermShort LIKE '%".$sDuom['sVezejas']."%' ";
    }

    if($sDuom['sSaliesKodas']){
        $WHERE .= " AND A.SaliesKodas = '".$sDuom['sSaliesKodas']."' ";
    }

    //pasiimam duomenys pacheckinto checkListo
    $qry = "

        SELECT  
            left(convert(char,A.Expected_Shipment_Date,120),10) AS 'Expected_Shipment_DateR',
            left(convert(char,A.Expected_Delivery_Date,120),10) AS 'Expected_Delivery_DateR',

            A.*, 
            C.naam____ AS ClientName, 
            L.lok__rpn AS GavejasShort, 
            L.lok__oms AS Gavejas, 
            L.land_ref AS GavejoSalis
        FROM _TMS_Siuntos AS A
        LEFT JOIN klabas__ AS C ON A.KlientasID = C.kla__ref
        LEFT JOIN levlok__ AS L ON A.GavejasID=L.lok__ref
        WHERE deleted<>1 ".$WHERE."
        ORDER BY A.uid DESC
    ";
    
    $mssql = DBMSSqlCERM::getInstance();
    $SiuntosList = $mssql->querySql($qry, 1);

    //!!!!!! DEBUG
    //$this->var_dump($SiuntosList, "SiuntosList <hr>$qry<hr> ");//-----------------DEBUG


    return $SiuntosList;
}//end function


//si funkcija negeneruoja manifesto tik pasiima ji jeigu jis tinkamas, arba grazina tuscia, jeigu jo nera arba jis netinkamai sugeneruotas
//funkcija naudojama DET aprasyme modulyje SIUNTOS
public function getVP_Manifest($KEGKPG){

    // nuo 20210701 pasikeitimas: manifestu datoje rasomas jo galiojimo laikas (iki kada galioja o ne kokia diena sukurtas)
    // logika:
        // - jeigu manifestas sukurtas siandien iki 17 val tai jis galioja iki siandien 17 val
        // jeigu manifestas sukurtas siandien po 17 val tai jis galioja iki rytojaus 17 val.


    $rezManifest = "";
    $qry = "
        SELECT  VP_OpenManifest, VP_OpenManifestDate, VP_OpenManifestKEG, VP_OpenManifestDateKEG, VP_OpenManifestTEST, VP_OpenManifestDateTEST, VP_manifest
        FROM _TMS_numbers 
        WHERE row = 1
    ";
    
    $mssql = DBMSSqlCERM::getInstance();
    $VPManifestDB = $mssql->querySqlOneRow($qry, 1);

    $date = date("Y-m-d H:i:s");

    echo "****************-----------manifest: date:".$date." and DB manifest: ".$VPManifestDB['VP_OpenManifestDateKEG']."------------****************<br>";


    if($KEGKPG=='KPG'){
        if($VPManifestDB['VP_OpenManifest'] AND $VPManifestDB['VP_OpenManifestDate']>$date  AND strlen($VPManifestDB['VP_OpenManifest'])==14){
            $rezManifest = $VPManifestDB['VP_OpenManifest'];
        }
    }elseif($KEGKPG=='KEG'){
        if($VPManifestDB['VP_OpenManifestKEG'] AND $VPManifestDB['VP_OpenManifestDateKEG']>$date  AND strlen($VPManifestDB['VP_OpenManifestKEG'])==14){
            $rezManifest = $VPManifestDB['VP_OpenManifestKEG'];
            //echo "<br>*********** PRAEJO MANIFEST ****************<br>";
        }
    }elseif($KEGKPG=='ETK' OR $KEGKPG=='ETK1'){
        if($VPManifestDB['VP_OpenManifestETK'] AND $VPManifestDB['VP_OpenManifestDateETK']>$date  AND strlen($VPManifestDB['VP_OpenManifestETK'])==14){
            $rezManifest = $VPManifestDB['VP_OpenManifestETK'];
            //echo "<br>*********** PRAEJO MANIFEST ****************<br>";
        }
    }elseif($KEGKPG=='TEST'){
        if($VPManifestDB['VP_OpenManifestTEST'] AND $VPManifestDB['VP_OpenManifestDateTEST']>$date  AND strlen($VPManifestDB['VP_OpenManifestTEST'])==14){
            $rezManifest = $VPManifestDB['VP_OpenManifestTEST'];
        }

    }

    return $rezManifest;
}//end function


public function generateManifestDates (){


        $workingDays = array(1, 2, 3, 4, 5);
        $holidayDays = array('*-01-01', '*-02-16', '*-03-11', '*-05-01', '*-06-24', '*-07-06', '*-08-15', '*-11-01','*-11-02', '*-12-24', '*-12-25', '*-12-26',  '2020-04-13');
        

        //$date = date("Y-m-d H:i:s");
        $hour = date("H");
        $weekDay = date("N");
        //$hour = 17;
        if($hour<17 AND in_array($weekDay, $workingDays)){
            $validManifestValidIki = date('Y-m-d 17:00:00');
            $dat =date("ymd");
        }else{
            $setDate = date('Y-m-d H:i:s');//pradine data siandienos, bet tikrinsim nuo rytdienos cikle

            $stop = false;
            $ciklu = 0;
            $getData = null;
            $tempDate = $setDate;
            while (!$stop AND $ciklu<10) {

                $tempDate = date('Y-m-d', strtotime($tempDate .' +1 day'));

                //echo "<br><br><br>---" . $tempDate . ' ' . date('l', $tempDate);

                //jei tai savaites darbo diena ir jeigu tai ne svente su konkrecia data (pvz velykos) ir jeigu tai ne pasikartojanti kasmet svente
                if (in_array(date('N', strtotime($tempDate)), $workingDays) AND !in_array(date('Y-m-d', strtotime($tempDate)), $holidayDays) AND !in_array(date('*-m-d', strtotime($tempDate)), $holidayDays)){
                    $getData = $tempDate;
                    $validManifestValidIki = date('Y-m-d 17:00:00', strtotime($getData));
                    $dat = date('ymd', strtotime($getData));
                    $stop = true;//stabdom cikla
                }else{
                    $ciklu++;
                }
            }//end while

        }//end else



    $returnArray['validManifestValidIki'] = $validManifestValidIki;
    $returnArray['dat'] = $dat;

    return $returnArray;

}//end function




//Sugeneruoja nauja arba grazina tinkamai sugeneruota manifest numeri pries kuriant XML
//sugeneruotas manifest saugomas _TMS_numbers.VP_OpenManifest lenteleje 
// ir josugeneravimo data  _TMS_numbers.VP_OpenManifestDate
// jeigu tikrinimo metu manifestas paseno (ne sios dienos arba sios dienos bet po 17:00) arba nera ar netinkamai sugeneruotas,
// tai jis pergeneruojamas vel
public function generateVP_Manifest($VUserID, $KEGKPG){

    $rezManifest = "";
    //nusiskaitom is DB ar yra siandien atidarytas VENIPAK manifestas (sios dienos)
    // jeigu nera arba jis ne sios dienos tai generuojam nauja manifest numeri ir irasom i DB

    $qry = "
        SELECT  VP_OpenManifest, VP_OpenManifestDate, VP_OpenManifestKEG, VP_OpenManifestDateKEG, VP_OpenManifestETK, VP_OpenManifestDateETK, VP_OpenManifestTEST, VP_OpenManifestDateTEST, VP_manifest
        FROM _TMS_numbers 
        WHERE row = 1
    ";
    
    $mssql = DBMSSqlCERM::getInstance();
    $VPManifestDB = $mssql->querySqlOneRow($qry, 1);

    /* pakeiciam i funkcija kuri vertina ir sventines dienas
    $date = date("Y-m-d H:i:s");
    $hour = date("H");
    if($hour<=17){
        $validManifestValidIki = date('Y-m-d 17:00:00');
        $dat =date("ymd");
    }else{
        $validManifestValidIki = date('Y-m-d 17:00:00', strtotime("+1 days"));
        $dat =date("ymd", strtotime("+1 days"));
    }
    */

    $Mdatos = $this->generateManifestDates ();
    $validManifestValidIki = $Mdatos ['validManifestValidIki'];
    $dat = $Mdatos ['dat'];

    $date = date("Y-m-d H:i:s");

    if($KEGKPG=='KPG'){
        $VP_OpenManifestDate = substr($VPManifestDB['VP_OpenManifestDate'], 0, 10);
        $VP_OpenManifestHour = substr($VPManifestDB['VP_OpenManifestDate'], 11, 2);

        if(!$VPManifestDB['VP_OpenManifest']  OR strlen($VPManifestDB['VP_OpenManifest'])!=14 OR $date>$VPManifestDB['VP_OpenManifestDate']){ // nuo 20210701 $VPManifestDB['VP_OpenManifestDate'] - yra data iki kada galioja manifestas, po 17 val ivedimo. Keiciant manifesta irasoma nauja jo galiojimo data $validManifestValidIki
            //jeig manifesto nera arba jis ne sios dienos tai kuriam nauja manifesto NR
            //echo "<hr>|".$VPManifestDB['VP_manifest']. "----".$VUserID."| <br>";
            if($VUserID AND is_numeric($VPManifestDB['VP_manifest'])){
                $VP_manifestWithPad = str_pad($VPManifestDB['VP_manifest'], 3, "0", STR_PAD_LEFT);
                //$dat =date("ymd");
                $rezManifest = $VUserID.$dat.$VP_manifestWithPad;

                //irasom nauja manifesta i DB
                $newNumberValue = $VPManifestDB['VP_manifest']+1;
                $wsql = 'UPDATE _TMS_Numbers SET 
                            VP_manifest=\''.$newNumberValue.'\', 
                            VP_OpenManifest=\''.$rezManifest.'\',
                            VP_OpenManifestDate=\''.$validManifestValidIki.'\'
                        WHERE  row=1 ;'
                ;    
                // VP_OpenManifestDate=\''.$validManifestValidIki.'\' - irasoma data iki kada galioja manifestas ... jeigu sukuriamas siandien iki 17 val tai galioja siandien iki 17 val, jeigu siandien po 17 val tai galioja iki rytojaus 17 val.
                //var_dump($wsql);

                $wmssql = DBMSSqlCERM::getInstance();
                $retSQL = $wmssql->execSql($wsql, 1);

            }else{
                    $error = 'NOTOK';
                    $this->AddError('Nepavyko sukurti Manifest numerio');
            }
        }else{//end if
            //manifestas yra sekmingai atidarytas siandien ir ji grazinam
            $rezManifest = $VPManifestDB['VP_OpenManifest'];
        }
    }elseif ($KEGKPG=='KEG'){
        if(!$VPManifestDB['VP_OpenManifestKEG'] OR $date > $VPManifestDB['VP_OpenManifestDateKEG']  OR strlen($VPManifestDB['VP_OpenManifestKEG'])!=14){
            //jeig manifesto nera arba jis ne tinkamos dienos tai kuriam nauja manifesto NR
            //echo "<hr>|".$VPManifestDB['VP_manifest']. "----".$VUserID."| <br>";
            if($VUserID AND is_numeric($VPManifestDB['VP_manifest'])){
                $VP_manifestWithPad = str_pad($VPManifestDB['VP_manifest'], 3, "0", STR_PAD_LEFT);
                //$dat =date("ymd");
                $rezManifest = $VUserID.$dat.$VP_manifestWithPad;

                //irasom nauja manifesta i DB
                $newNumberValue = $VPManifestDB['VP_manifest']+1;
                $wsql = 'UPDATE _TMS_Numbers SET 
                            VP_manifest=\''.$newNumberValue.'\', 
                            VP_OpenManifestKEG=\''.$rezManifest.'\',
                            VP_OpenManifestDateKEG=\''.$validManifestValidIki.'\'
                        WHERE  row=1 ;'
                ;    

                //var_dump($wsql);

                $wmssql = DBMSSqlCERM::getInstance();
                $retSQL = $wmssql->execSql($wsql, 1);

            }else{
                    $error = 'NOTOK';
                    $this->AddError('Nepavyko sukurti Manifest numerio');
            }
        }else{//end if
            //manifestas yra sekmingai atidarytas siandien ir ji grazinam
            $rezManifest = $VPManifestDB['VP_OpenManifestKEG'];
        }
    }elseif ($KEGKPG=='ETK' OR $KEGKPG=='ETK1'){
        if(!$VPManifestDB['VP_OpenManifestETK'] OR $date > $VPManifestDB['VP_OpenManifestDateETK']  OR strlen($VPManifestDB['VP_OpenManifestETK'])!=14){
            //jeig manifesto nera arba jis ne tinkamos dienos tai kuriam nauja manifesto NR
            //echo "<hr>|".$VPManifestDB['VP_manifest']. "----".$VUserID."| <br>";
            if($VUserID AND is_numeric($VPManifestDB['VP_manifest'])){
                $VP_manifestWithPad = str_pad($VPManifestDB['VP_manifest'], 3, "0", STR_PAD_LEFT);
                //$dat =date("ymd");
                $rezManifest = $VUserID.$dat.$VP_manifestWithPad;

                //irasom nauja manifesta i DB
                $newNumberValue = $VPManifestDB['VP_manifest']+1;
                $wsql = 'UPDATE _TMS_Numbers SET 
                            VP_manifest=\''.$newNumberValue.'\', 
                            VP_OpenManifestETK=\''.$rezManifest.'\',
                            VP_OpenManifestDateETK=\''.$validManifestValidIki.'\'
                        WHERE  row=1 ;'
                ;    

                //var_dump($wsql);

                $wmssql = DBMSSqlCERM::getInstance();
                $retSQL = $wmssql->execSql($wsql, 1);

            }else{
                    $error = 'NOTOK';
                    $this->AddError('Nepavyko sukurti Manifest numerio');
            }
        }else{//end if
            //manifestas yra sekmingai atidarytas siandien ir ji grazinam
            $rezManifest = $VPManifestDB['VP_OpenManifestETK'];
        }

    }elseif ($KEGKPG=='TEST'){
        // testui naudojam 20210104 - SO 340102
        echo" <br> ************************************************************* <br>";
        var_dump($VPManifestDB['VP_OpenManifestTEST']);
        var_dump($VPManifestDB['VP_OpenManifestDateTEST']);
        var_dump($validManifestValidIki);
        var_dump($date);
        echo" <br> ************************************************************* <br>";

        if(!$VPManifestDB['VP_OpenManifestTEST'] OR $date > $VPManifestDB['VP_OpenManifestDateTEST'] OR strlen($VPManifestDB['VP_OpenManifestTEST'])!=14){
            //jeig manifesto nera arba jis ne sios dienos tai kuriam nauja manifesto NR
            //echo "<hr>|".$VPManifestDB['VP_manifest']. "----".$VUserID."| <br>";
            if($VUserID AND is_numeric($VPManifestDB['VP_manifest'])){
                $VP_manifestWithPad = str_pad($VPManifestDB['VP_manifest'], 3, "0", STR_PAD_LEFT);
                //$dat =date("ymd");
                $rezManifest = $VUserID.$dat.$VP_manifestWithPad;

                //irasom nauja manifesta i DB
                $newNumberValue = $VPManifestDB['VP_manifest']+1;
                $wsql = 'UPDATE _TMS_Numbers SET 
                            VP_manifest=\''.$newNumberValue.'\', 
                            VP_OpenManifestTEST=\''.$rezManifest.'\',
                            VP_OpenManifestDateTEST=\''.$validManifestValidIki.'\'
                        WHERE  row=1 ;'
                ;    

                //var_dump($wsql);

                $wmssql = DBMSSqlCERM::getInstance();
                $retSQL = $wmssql->execSql($wsql, 1);

            }else{
                    $error = 'NOTOK';
                    $this->AddError('Nepavyko sukurti Manifest numerio');
            }
        }else{//end if
            //manifestas yra sekmingai atidarytas siandien ir ji grazinam
            $rezManifest = $VPManifestDB['VP_OpenManifestTEST'];
        }

    }//elseif

    echo" <br> ************************************************************* <br>";
    var_dump($rezManifest);

    return $rezManifest;

}//end function




public function siustiMANUAL ($SiuntaUID, $sParam){

    $error = 'OK';
    if($SiuntaUID){

        $siandien = date ("Y-m-d H:i:s");
        //irasom nauja manifesta i DB

        try {
            $wsql = 'UPDATE _TMS_Siuntos SET 

                    /* Adresas=\''.$sParam['det_AdresasFull'].'\', */
                    Delivery_street=\''.$sParam['det_Street1'].' '.$sParam['det_Street2'].' '.$sParam['det_Region'].'\',
                    SaliesKodas=\''.$sParam['det_CountryCode'].'\', 
                    Miestas=\''.$sParam['det_City'].'\',
                    /* Delivery_email=\''.$sParam['det_ContactPersonMail'].'\', */
                    Delivery_contact_email=\''.$sParam['det_ContactPersonMail'].'\',
                    /* Delivery_phone=\''.$sParam['det_ContactPersonTel'].'\', */
                    Delivery_contact_phone=\''.$sParam['det_ContactPersonTel'].'\',
                    Delivery_contact=\''.$sParam['det_ContactPerson'].'\',

                    /* Sandelys=\''.$sParam['det_Street1'].'\', */

                    VezejasReal=\''.$sParam['sMAN_VEZEJAS'].'\',
                    SysManual=\'MAN\',
                    KrovinysReg=\'Y\',
                    /* KurjerisReg=\'Y\', */

                    KurjOrderNr=\''.$sParam['sMAN_SiuntaOrder'].'\',
                    SiuntaUzregistruota=\''.$siandien.'\',
                    SiuntosBusena=\'2\',
                    /* DocKrovVaztar=\'\', */
                    TrackingNr=\''.$sParam['sMAN_TrackingNr'].'\',
                    Service=\''.$sParam['sMAN_Service'].'\',
                    
                    LiveDemo=\''.$sParam['sMAN_LiveDemo'].'\'
                WHERE  uid=\''.$SiuntaUID.'\' ;'
            ;    

            var_dump($wsql);

            $wmssql = DBMSSqlCERM::getInstance();
            $retSQL = $wmssql->execSql($wsql, 1);

            $qry = "
                SELECT  *
                FROM _TMS_Siuntos 
                WHERE uid = ".$SiuntaUID." 
            ";
            $RezDB = $wmssql->querySqlOneRow($qry, 1);
            //var_dump($RezDB);

            $Y = 'Y ';
            if($RezDB['uid']==$SiuntaUID AND $RezDB['KrovinysReg']==$Y AND $RezDB['VezejasReal']==$sParam['sMAN_VEZEJAS'] ){
                $error = 'OK';

                var_dump($RezDB['Pakuotes']);

                $pakuociuArrayTmp = $this->parsePacksStrToArray ($RezDB['Pakuotes']);

                var_dump($pakuociuArrayTmp);

                $pakuociuArray = array();
                $i=0;$j=1;
                if(is_array($pakuociuArrayTmp)){
                    foreach ($pakuociuArrayTmp as $key => $pak) {
                        $pakuociuArray[$i] = $pak;
                        $pakuociuArray[$i]['SiuntaUID'] = $SiuntaUID;
                        $pakuociuArray[$i]['VezejasReal'] = $sParam['sMAN_VEZEJAS'];
                        $pakuociuArray[$i]['LipdukasPdf'] = '';
                        $priesd = date("Ymd");
                        $pakuociuArray[$i]['PakuotesNr'] = $priesd."-".$SiuntaUID."-".$j;

                        $i++;
                        $j++;
                    }//end foreach


                    $toDB['SiuntuNr'] = array();
                }//end if
                var_dump($pakuociuArray);
                

                //saugom pakuotes
                $retPak = $this->saveTvsMANUALPakuotesID($pakuociuArray);

                if($retPak['OK']!='OK'){
                    //$error = 'NOTOK'; - net jei nepavyko tai ne klaida, nes cia tik del saves saugom pakuotes
                    $this->AddError('Nepavyko išsaugoti pakuočių');
                }
                $RezDB['PAKS']=$retPak['PAKS'];

                //saugom istorija

                $toDB['SiuntaUID'] =  $SiuntaUID;
                $toDB['SendetXMLTime'] = '';
                $toDB['HisGroup'] = 'SIUNTA_REG';
                $toDB['HisAction'] = 'IDMANUAL';
                $toDB['SendetXMLUser']=  $_SESSION['user_name'];
                $toDB['SendetXMLUserUID']= $_SESSION['user_id'];
                $toDB['SendetXML']= '';
                $toDB['ResponseXML']= '';
                $toDB['Comment'] = 'Rankinis siuntos registravimas';
                $toDB['SendetXMLOK']= '1';

                $retHis = $this->saveTvsHis($toDB);

            }else{
                //echo "----------------<br>".$RezDB['uid']."==".$SiuntaUID." AND ".$RezDB['KrovinysReg']."=='Y' AND ".$RezDB['VezejasReal']."==".$sParam['sMAN_VEZEJAS']." ----<br>";
                $error = 'NOTOK';
                $this->AddError('Nepavyko išsaugoti duomenų');
            }
            



        } catch (Exception $ex) {
            $this->AddError((string)$ex);
            $error = 'NOTOK';
        }//catch                        


    }else{
            $error = 'NOTOK';
            $this->AddError('Nenurodytas siuntos numeris');
    }

    $man_rez['OK']=$error;
    $man_rez['Data']=$RezDB;
    return $man_rez;

}//end function



/*  Surenka siuntos duomenys atidavimui i Transporto uzsakyma */
public function getSiuntaDuomToTransp($SiuntaUID, $Sandelys='NaN'){

    $SiuntosList = array();

    $error = 'OK';
    if($SiuntaUID){
            //pasiimam duomenys apie siunta vezejams
            $qry = "
                SELECT  
                    ROUND(CAST (A.SvorisSum AS decimal (10,2)),2) AS SvorisSumR,
                    left(convert(char,A.Expected_Shipment_Date,120),10) AS 'Expected_Shipment_DateR',
                    left(convert(char,A.Expected_Delivery_Date,120),10) AS 'Expected_Delivery_DateR',

                    A.*, 
                    C.naam____ AS ClientName, 
                    C.straat__ AS ClientGatve,
                    C.land_ref AS ClientLandRef,
                    C.county__ AS ClientCountry, /*Apskritis*/
                    C.post_ref AS ClientPostCode,
                    C.postnaam AS ClientRajonasMiestas,
                    C.telefoon AS ClientTel,
                    C.telefax_ AS ClientTelFax,
                    C.telex___ AS ClientEmail,
                    C.website_ AS ClientWebSite,
                    C.kla_hvdt AS ClientMajorGrouping,
                    C.vrt__ref AS ClientAtsovaujaID,
                    C.ord_begl AS ClientJobManager,
                    C.int_cont AS ClientInerContact,
                    C.cdeklaap AS ClientImKodas,


                    L.lok__rpn AS GavShort, 
                    L.lev_loc1 AS GavName, 
                    L.lev_loc3 AS GavGatve, 
                    L.land_ref AS GavLandRef,
                    L.county__ AS GavCountry, /*Apskritis*/
                    L.post_ref AS GavPostCode,
                    L.postnaam AS GavRajonasMiestas,
                    L.telefoon AS GavTel,
                    L.email___ AS GavEmail,
                    L.trn__ref AS GavTransportZone


                FROM _TMS_Siuntos AS A
                LEFT JOIN klabas__ AS C ON A.KlientasID = C.kla__ref
                LEFT JOIN levlok__ AS L ON A.GavejasID=L.lok__ref
                WHERE A.uid = '".$SiuntaUID."' AND A.deleted<>1
            ";
            
            $mssql = DBMSSqlCERM::getInstance();
            $SiuntosDuom = $mssql->querySqlOneRow($qry, 1);

                //!!!!!! DEBUG
                $this->var_dump($SiuntosDuom, "SiuntosDuomenys MOD<hr>$qry<hr> ");//-----------------DEBUG







            if($SiuntosDuom){

                if(!$Sandelys OR $Sandelys=='NaN'){
                    $Sandelys=$SiuntosDuom['Sandelys'];
                }

                if($Sandelys=='KEG' OR $Sandelys=='KPG' OR $Sandelys=='ETK' OR $Sandelys=='ETK1'){

                    //tikrinam ar ne siunta i Pastomata ir jeigu taip, tai keiciam CompanyCode i pastomato koda 
                    if($SiuntosDuom['ArIPastomata']=='PICKUP'){
                        $SiuntosDuom['ClientImKodas']=$SiuntosDuom['ClientCompanyCode'];
                    }

                    $qryKey = "

                        SELECT  *
                        FROM _TMS_keys AS A
                        WHERE A.deleted<>1 AND SiuntaUID = '".$SiuntaUID."' 
                        ORDER BY A.PackSlipID DESC
                    ";
                    
                    //$mssql = DBMSSqlCERM::getInstance();
                    $SiuntosDuomKey = $mssql->querySql($qryKey, 1);

                    $SiuntosDuom['KEY'] = $SiuntosDuomKey;




                    $qryPak = "

                        SELECT  *
                        FROM _TMS_Pak AS A
                        WHERE A.deleted<>1 AND SiuntaUID = '".$SiuntaUID."' 
                        ORDER BY A.uid DESC
                    ";
                    
                    //$mssql = DBMSSqlCERM::getInstance();
                    $SiuntosDuomPack = $mssql->querySql($qryPak, 1);

                    $SiuntosDuom['PAKS'] = $SiuntosDuomPack;

                    /*
                    $SiuntosDuom['OPER']['user_id'] = $_SESSION['user_id'];
                    $SiuntosDuom['OPER']['user_name'] = $_SESSION['user_name'];
                    $SiuntosDuom['OPER']['user_Mob'] = $_SESSION['user_MobTelefonas'];
                    $SiuntosDuom['OPER']['user_Email'] = $_SESSION['user_Email'];
                    */
                    $SiuntosDuom['OPER']['user_id'] = '858';
                    $SiuntosDuom['OPER']['user_name'] = 'Edita Kupčiūnienė';
                    $SiuntosDuom['OPER']['user_Mob'] = '+37068802736';
                    $SiuntosDuom['OPER']['user_Email'] = 'transportas@aurika.lt';


                    //aktyvus VENIPAK manifestas
                    $this->mode = TVS_CONFIG::VENIPAK_MODE;
                    if(strtoupper($this->mode)=='TEST'){
                        $SiuntosDuom['OpenVPManifest'] = $this->getVP_Manifest('TEST');
                    }else{
                        $SiuntosDuom['OpenVPManifest'] = $this->getVP_Manifest($Sandelys);  
                    }
                    
                }else{
                    $error = 'NOTOK';
                    $this->AddError('Nenurodytas sandėlys iš kurio bus siunčiama (KEG/KPG).');
                }

            }else{
                $error = 'NOTOK';
                $this->AddError('Nėra duomenų apie siuntą');
            }
    }else{//end if
        $error = 'NOTOK';
        $this->AddError('Duomenų perdavimo klaida. Nenurodytas ID');
    }

    $rez['OK']=$error;
    $rez['Duom'] = $SiuntosDuom;
    return $rez;
}//end function




/*  Surenka siuntos duomenys atidavimui i Transporto uzsakyma */
public function getSiuntaDuomToTranspETK($SiuntaUID, $Sandelys='NaN'){

    $SiuntosList = array();

    $error = 'OK';
    if($SiuntaUID){
            //pasiimam duomenys apie siunta vezejams
            $qry = "
                SELECT  
                    ROUND(CAST (A.SvorisSum AS decimal (10,2)),2) AS SvorisSumR,
                    left(convert(char,A.Expected_Shipment_Date,120),10) AS 'Expected_Shipment_DateR',
                    left(convert(char,A.Expected_Delivery_Date,120),10) AS 'Expected_Delivery_DateR',

                    A.*,
                    A.Gavejas AS ClientName, 
                    A.Delivery_street AS ClientGatve,
                    A.SaliesKodas AS ClientLandRef,
                    A.SaliesKodas AS ClientCountry,
                    A.PostKodas AS ClientPostCode,
                    A.Miestas AS ClientRajonasMiestas,
                    A.Delivery_phone AS ClientTel,
                    A.Delivery_contact_phone AS ClientTelFax,
                    A.Delivery_email AS ClientEmail,
                    '' AS ClientWebSite,
                    '' AS ClientMajorGrouping,
                    '' AS ClientAtsovaujaID,
                    '' AS ClientJobManager,
                    A.Delivery_contact AS ClientInerContact,
                    '' AS ClientImKodas,


                    '' AS GavShort, 
                    A.Gavejas AS GavName, 
                    A.Delivery_street AS GavGatve, 
                    A.SaliesKodas AS GavLandRef,
                    A.SaliesKodas AS GavCountry, 
                    A.PostKodas AS GavPostCode,
                    A.Miestas AS GavRajonasMiestas,
                    A.Delivery_phone AS GavTel,
                    A.Delivery_email AS GavEmail,
                    '' AS GavTransportZone
                    

                FROM _TMS_Siuntos AS A
                /*
                LEFT JOIN klabas__ AS C ON A.KlientasID = C.kla__ref
                LEFT JOIN levlok__ AS L ON A.GavejasID=L.lok__ref
                */
                WHERE A.uid = '".$SiuntaUID."' AND A.deleted<>1
            ";
            
            $mssql = DBMSSqlCERM::getInstance();
            $SiuntosDuom = $mssql->querySqlOneRow($qry, 1);

            //!!!!!! DEBUG
            $this->var_dump($SiuntosDuom, "SiuntosDuomenys MOD ETK<hr>$qry<hr> ");//-----------------DEBUG







            if($SiuntosDuom){

                if(!$Sandelys OR $Sandelys=='NaN'){
                    $Sandelys=$SiuntosDuom['Sandelys'];
                }

                if($Sandelys=='KEG' OR $Sandelys=='KPG' OR $Sandelys=='ETK' OR $Sandelys=='ETK1'){

                    //tikrinam ar ne siunta i Pastomata ir jeigu taip, tai keiciam CompanyCode i pastomato koda 
                    if($SiuntosDuom['ArIPastomata']=='PICKUP'){
                        $SiuntosDuom['ClientImKodas']=$SiuntosDuom['ClientCompanyCode'];
                    }

                    $qryKey = "

                        SELECT  *
                        FROM _TMS_keys AS A
                        WHERE A.deleted<>1 AND SiuntaUID = '".$SiuntaUID."' 
                        ORDER BY A.PackSlipID DESC
                    ";
                    
                    //$mssql = DBMSSqlCERM::getInstance();
                    $SiuntosDuomKey = $mssql->querySql($qryKey, 1);

// TODO20211204
                    //Jeigu siunta is ETK sandelio tai ji neturi PackingSlip ir vietoje jo imituojam siuntos OrderNr ... bet jis yra ne skaicius, todel jis yra kitame stulpelyje ir cia is kito stulpelio permetas i PackingSlipID stulpeli, kad negriautu logikos
                    /*
                    if($Sandelys=='ETK'){
                        if($SiuntosDuomKey){
                            foreach ($SiuntosDuomKey as $key => $valueSD) {
                                if($SiuntosDuomKey['PackSlipID']==0 AND $SiuntosDuomKey['NAVOrder']){
                                    $SiuntosDuomKey['PackSlipID']=$SiuntosDuomKey['NAVOrder'];
                                }
                            }
                        }
                        
                    }
                    */

                    $SiuntosDuom['KEY'] = $SiuntosDuomKey;




                    $qryPak = "

                        SELECT  *
                        FROM _TMS_Pak AS A
                        WHERE A.deleted<>1 AND SiuntaUID = '".$SiuntaUID."' 
                        ORDER BY A.uid DESC
                    ";
                    
                    //$mssql = DBMSSqlCERM::getInstance();
                    $SiuntosDuomPack = $mssql->querySql($qryPak, 1);

                    $SiuntosDuom['PAKS'] = $SiuntosDuomPack;

                    /*
                    $SiuntosDuom['OPER']['user_id'] = $_SESSION['user_id'];
                    $SiuntosDuom['OPER']['user_name'] = $_SESSION['user_name'];
                    $SiuntosDuom['OPER']['user_Mob'] = $_SESSION['user_MobTelefonas'];
                    $SiuntosDuom['OPER']['user_Email'] = $_SESSION['user_Email'];
                    */
                    $SiuntosDuom['OPER']['user_id'] = '858';
                    $SiuntosDuom['OPER']['user_name'] = 'Edita Kupčiūnienė';
                    $SiuntosDuom['OPER']['user_Mob'] = '+37068802736';
                    $SiuntosDuom['OPER']['user_Email'] = 'transportas@aurika.lt';


                    //aktyvus VENIPAK manifestas
                    $this->mode = TVS_CONFIG::VENIPAK_MODE;
                    if(strtoupper($this->mode)=='TEST'){
                        $SiuntosDuom['OpenVPManifest'] = $this->getVP_Manifest('TEST');
                    }else{
                        $SiuntosDuom['OpenVPManifest'] = $this->getVP_Manifest($Sandelys);  
                    }
                    
                }else{
                    $error = 'NOTOK';
                    $this->AddError('Nenurodytas sandėlys iš kurio bus siunčiama (KEG/KPG/ETK).');
                }

            }else{
                $error = 'NOTOK';
                $this->AddError('Nėra duomenų apie siuntą');
            }
    }else{//end if
        $error = 'NOTOK';
        $this->AddError('Duomenų perdavimo klaida. Nenurodytas ID');
    }




    $rez['OK']=$error;
    $rez['Duom'] = $SiuntosDuom;

            //!!!!!! DEBUG
            $this->var_dump($rez, "REZ MOD ETK<hr>$qry<hr> ");//-----------------DEBUG


    return $rez;
}//end function




public function getTVSNumbers (){
            $qry = "
                SELECT  
                    *
                FROM _TMS_Numbers
            ";
            
            $mssql = DBMSSqlCERM::getInstance();
            $NumeriuArray = $mssql->querySqlOneRow($qry, 1);
    return $NumeriuArray;
}//end function



//Grazina sios dienos siuntas su UPS. Naudojama pries kvieciant UPS kurjeri
public function getUPSSiuntosSiandien ($Sandelys){

            $iandienNuo = date ("Y-m-d 00:00:00");
            $iandienIki = date ("Y-m-d 23:59:59");

            //testavimui
            //$iandienNuo = "2021-09-13 00:00:00";
            //$iandienIki = "2021-09-13 23:59:59";

            if($Sandelys=='ETK'){
                $qry = "
                    SELECT  
                        *
                    FROM _TMS_Siuntos
                    WHERE Sandelys IN ('ETK', 'ETK1') AND VezejasReal = 'UPS' AND LiveDemo = 'live      ' AND  deleted='0' AND (SiuntaUzregistruota >= '".$iandienNuo."' AND SiuntaUzregistruota <= '".$iandienIki."')
                ";
            }else{
                $qry = "
                    SELECT  
                        *
                    FROM _TMS_Siuntos
                    WHERE Sandelys = '".$Sandelys."' AND VezejasReal = 'UPS' AND LiveDemo = 'live      ' AND  deleted='0' AND (SiuntaUzregistruota >= '".$iandienNuo."' AND SiuntaUzregistruota <= '".$iandienIki."')
                ";
            }            
            $mssql = DBMSSqlCERM::getInstance();
            $UPSSiuntosArrayDB = $mssql->querySql($qry, 1);

            //!!!!!! DEBUG
            //$this->var_dump($UPSSiuntosArrayDB, "UPSSiuntosArrayDB MOD<hr>$qry<hr> ");//-----------------DEBUG


            if ($UPSSiuntosArrayDB){
                $i = 0;
                $UPSSiuntosArray['SiuntuSkSum'] = 0;
                $UPSSiuntosArray['SiuntuSvoriuSum'] = 0;
                foreach ($UPSSiuntosArrayDB as $key => $eilute) {
                    $rezArray = $this->parsePacksStrToArray ($eilute['Pakuotes']);
                    if($rezArray){
                        foreach ($rezArray as $key => $siunt) {
                            $UPSSiuntosArray['Siuntos'][$i] = $siunt;
                            $UPSSiuntosArray['Siuntos'][$i]['SiuntaUzregistruota']=$eilute['SiuntaUzregistruota'];
                            $UPSSiuntosArray['Siuntos'][$i]['VezejasReal']=$eilute['VezejasReal'];
                            $UPSSiuntosArray['Siuntos'][$i]['Sandelys']=$eilute['Sandelys'];
                            $UPSSiuntosArray['Siuntos'][$i]['SaliesKodas']=$eilute['SaliesKodas'];
                            $UPSSiuntosArray['Siuntos'][$i]['PostKodas']=$eilute['PostKodas'];

                            $UPSSiuntosArray['SiuntuSkSum'] += $siunt['pKiekis'];
                            $UPSSiuntosArray['SiuntuSvoriuSum'] += $siunt['pPakioSvoris']*$siunt['pKiekis'];

                            $i++;
                        }
                    }
                }//foreach
            }//end if


            //!!!!!! DEBUG
            //$this->var_dump($UPSSiuntosArray, "UPSSiuntosArray MOD<hr>$qry<hr> ");//-----------------DEBUG


            return $UPSSiuntosArray;

}//end function




//Grazina sios dienos siuntas su UPS. Naudojama UPS manifestui generuoti
//nuo 20211007 nenaudojama, nes generuojamas ne CSV o pdf (nauja funkcija zemiau)
public function getUPSSiuntosSiandienManifestCSV____nenaudojama ($Sandelys){

            $iandienNuo = date ("Y-m-d 00:00:00");
            $iandienIki = date ("Y-m-d 23:59:59");

            //testavimui
            //$iandienNuo = "2020-09-21 00:00:00";
            //$iandienIki = "2020-09-21 23:59:59";


            $qry = "
                SELECT A.uid, A.SysManual, A.Gavejas, A.Adresas, A.Service, A.Pakuotes, *
                FROM _TMS_Siuntos AS A
                /* LEFT JOIN _TMS_Pak AS B ON A.uid = B.SiuntaUID */
                WHERE 
                    A.SiuntaUzregistruota >= '".$iandienNuo."' AND A.SiuntaUzregistruota <= '".$iandienIki."'
                    AND A.VezejasReal = 'UPS'
                    AND A.Sandelys = '".$Sandelys."'
                    AND A.deleted = '0'
                    AND LiveDemo = 'live      ' 
                    /* AND A.SysManual = 'SYS' */
                ";
            $mssql = DBMSSqlCERM::getInstance();
            $UPSSiuntosArrayDB = $mssql->querySql($qry, 1);

            //!!!!!! DEBUG
            $this->var_dump($UPSSiuntosArrayDB, "UPSSiuntosArrayDB MOD<hr>$qry<hr> ");//-----------------DEBUG


            $ArrayToManifest = array();

            if($Sandelys=='KPG'){
                $ArrayToManifest[0]['Tracking number'] = "Shipper: account 976V1F, Aurika UAB, Chemijos g. 29F, Kaunas, 51333 ";
            }else{
                $ArrayToManifest[0]['Tracking number'] = "Shipper: account 976V1F, Aurika UAB, Taikos pr. 129A, Kaunas, 51127 ";
            }
            
            $ArrayToManifest[0]['Packages'] ='';
            $ArrayToManifest[0]['Ship to'] ='';
            $ArrayToManifest[0]['Service'] ='';

            $ArrayToManifest[1]['Tracking number'] = '';
            $ArrayToManifest[1]['Packages'] ='';
            $ArrayToManifest[1]['Ship to'] ='';
            $ArrayToManifest[1]['Service'] ='';

            $ArrayToManifest[2]['Tracking number'] = 'Tracking number';
            $ArrayToManifest[2]['Packages'] ='Packages';
            $ArrayToManifest[2]['Ship to'] ='Ship to';
            $ArrayToManifest[2]['Service'] ='Service';

            if ($UPSSiuntosArrayDB){
                $i = 3;
                $SipmentTotal = 0;
                $PackageTotal = 0;
                foreach ($UPSSiuntosArrayDB as $key => $eilute) {

                    $tmpPakuote = $this->parsePacksStrToArray ($eilute['Pakuotes']);

                    //!!!!!! DEBUG
                    //$this->var_dump($tmpPakuote, "tmpPakuote MOD<hr><hr> ");//-----------------DEBUG

                    $serviceName = $this->convertServiceCodeToName($eilute['Service']);

                    if($tmpPakuote){
                        foreach ($tmpPakuote as $keyp => $pak) {
                            $ArrayToManifest[$i]['Tracking number'] =$eilute['TrackingNr'];
                            $ArrayToManifest[$i]['Packages'] =$pak['pKiekis'];
                            $ArrayToManifest[$i]['Ship to'] =$eilute['Gavejas'].', '.$eilute['Adresas'];
                            $ArrayToManifest[$i]['Service'] =$serviceName;

                            $PackageTotal += $pak['pKiekis'];
                            $i++;
                            
                        }
                        $SipmentTotal += 1;
                    }

                }//foreach

            $ArrayToManifest[$i]['Tracking number'] = '';
            $ArrayToManifest[$i]['Packages'] ='';
            $ArrayToManifest[$i]['Ship to'] ='';
            $ArrayToManifest[$i]['Service'] ='';
            $i++;
            $ArrayToManifest[$i]['Tracking number'] = 'Shipment Total';
            $ArrayToManifest[$i]['Packages'] =$SipmentTotal;
            $ArrayToManifest[$i]['Ship to'] ='';
            $ArrayToManifest[$i]['Service'] ='';
            $i++;
            $ArrayToManifest[$i]['Tracking number'] = 'Package Total';
            $ArrayToManifest[$i]['Packages'] =$PackageTotal;
            $ArrayToManifest[$i]['Ship to'] ='';
            $ArrayToManifest[$i]['Service'] ='';


            }//end if


            //!!!!!! DEBUG
            $this->var_dump($ArrayToManifest, "ArrayToManifest MOD<hr>$qry<hr> ");//-----------------DEBUG

            return $ArrayToManifest;

}//end function




//Grazina sios dienos siuntas su UPS. Naudojama UPS manifestui generuoti PDF formate
public function getUPSSiuntosSiandienManifest ($Sandelys){

            $iandienNuo = date ("Y-m-d 00:00:00");
            $iandienIki = date ("Y-m-d 23:59:59");
            $siandien = date ("Y-m-d");
            $siandienPDF = date ("Ymd");

            //testavimui
            //$iandienNuo = "2021-10-05 00:00:00";
            //$iandienIki = "2021-10-05 23:59:59";


            $qry = "
                SELECT A.uid, A.SysManual, A.Gavejas, A.Adresas, A.Service, A.Pakuotes, A.TrackingNr
                FROM _TMS_Siuntos AS A
                /* LEFT JOIN _TMS_Pak AS B ON A.uid = B.SiuntaUID */
                WHERE 
                    A.SiuntaUzregistruota >= '".$iandienNuo."' AND A.SiuntaUzregistruota <= '".$iandienIki."'
                    AND A.VezejasReal = 'UPS'
                    AND A.Sandelys = '".$Sandelys."'
                    AND A.deleted = '0'
                    -- AND LiveDemo = 'live      ' 
                    /* AND A.SysManual = 'SYS' */
                ";
            $mssql = DBMSSqlCERM::getInstance();
            $UPSSiuntosArrayDB = $mssql->querySql($qry, 1);

            //!!!!!! DEBUG
            $this->var_dump($UPSSiuntosArrayDB, "UPSSiuntosArrayDB MOD<hr>$qry<hr> ");//-----------------DEBUG

            $ArrayToManifest = array();


            if($Sandelys=='KPG'){
                $ArrayToManifest['SHIPPER'] = "<b>Shipper:</b> account 976V1F, Aurika UAB, Chemijos g. 29F, Kaunas, 51333 <br> <b>Date:</b> ".$siandien." ";
            }else{
                $ArrayToManifest['SHIPPER'] = "<b>Shipper:</b> account 976V1F, Aurika UAB, Taikos pr. 129A, Kaunas, 51127  <br> <b>Date:</b> ".$siandien." ";
            }
            
            /*
            $ArrayToManifest[2]['Tracking number'] = 'Tracking number';
            $ArrayToManifest[2]['Packages'] ='Packages';
            $ArrayToManifest[2]['Ship to'] ='Ship to';
            $ArrayToManifest[2]['Service'] ='Service';
            */

            if ($UPSSiuntosArrayDB){
                $i = 0;
                $SipmentTotal = 0;
                $PackageTotal = 0;
                foreach ($UPSSiuntosArrayDB as $key => $eilute) {

                    $tmpPakuote = $this->parsePacksStrToArray ($eilute['Pakuotes']);

                    //!!!!!! DEBUG
                    //$this->var_dump($tmpPakuote, "tmpPakuote MOD<hr><hr> ");//-----------------DEBUG

                    $serviceName = $this->convertServiceCodeToName($eilute['Service']);

                    if($tmpPakuote){
                        foreach ($tmpPakuote as $keyp => $pak) {
                            $ArrayToManifest['SIUNTOS'][$i]['TrackingNr'] =$eilute['TrackingNr'];
                            $ArrayToManifest['SIUNTOS'][$i]['Packages'] =$pak['pKiekis'];
                            $ArrayToManifest['SIUNTOS'][$i]['ShipTo'] =$eilute['Gavejas'].', '.$eilute['Adresas'];
                            $ArrayToManifest['SIUNTOS'][$i]['Service'] =$serviceName;

                            $PackageTotal += $pak['pKiekis'];
                            $i++;
                            
                        }
                        $SipmentTotal += 1;
                    }

                }//foreach

                $ArrayToManifest['ShipmentTotal'] =$SipmentTotal;
                $ArrayToManifest['PackageTotal'] =$PackageTotal;
                $ArrayToManifest['siandien'] =$siandien;
                $ArrayToManifest['siandienPDF'] =$siandienPDF;

            }//end if


            //!!!!!! DEBUG
            $this->var_dump($ArrayToManifest, "ArrayToManifest MOD<hr>$qry<hr> ");//-----------------DEBUG

            return $ArrayToManifest;

}//end function





//Grazina sios dienos siuntas su UPS. Naudojama UPS manifestui generuoti
public function getUPSSiuntosSiandienManifest____OLD ($Sandelys){

            $iandienNuo = date ("Y-m-d 00:00:00");
            $iandienIki = date ("Y-m-d 23:59:59");

            //testavimui
            $iandienNuo = "2020-09-21 00:00:00";
            $iandienIki = "2020-09-21 23:59:59";


            $qry = "
                SELECT A.uid, A.SysManual, A.Gavejas, A.Adresas, A.Service, B.PakuotesNr, '1' AS Packages, *
                FROM _TMS_Siuntos AS A
                LEFT JOIN _TMS_Pak AS B ON A.uid = B.SiuntaUID
                WHERE 
                    A.SiuntaUzregistruota >= '".$iandienNuo."' AND A.SiuntaUzregistruota <= '".$iandienIki."'
                    AND A.VezejasReal = 'UPS'
                    AND A.Sandelys = '".$Sandelys."'
                    -- AND A.SysManual = 'SYS'
                ";
            
            $mssql = DBMSSqlCERM::getInstance();
            $UPSSiuntosArrayDB = $mssql->querySql($qry, 1);

            //!!!!!! DEBUG
            $this->var_dump($UPSSiuntosArrayDB, "UPSSiuntosArrayDB MOD<hr>$qry<hr> ");//-----------------DEBUG


            $ArrayToManifest = array();

            if($Sandelys=='KPG'){
                $ArrayToManifest[0]['Tracking number'] = "Shipper: account 976V1F, Aurika UAB, Chemijos g. 29F, Kaunas, 51333 ";
            }else{
                $ArrayToManifest[0]['Tracking number'] = "Shipper: account 976V1F, Aurika UAB, Taikos pr. 129A, Kaunas, 51127 ";
            }
            
            $ArrayToManifest[0]['Packages'] ='';
            $ArrayToManifest[0]['Ship to'] ='';
            $ArrayToManifest[0]['Service'] ='';

            $ArrayToManifest[1]['Tracking number'] = '';
            $ArrayToManifest[1]['Packages'] ='';
            $ArrayToManifest[1]['Ship to'] ='';
            $ArrayToManifest[1]['Service'] ='';

            $ArrayToManifest[2]['Tracking number'] = 'Tracking number';
            $ArrayToManifest[2]['Packages'] ='Packages';
            $ArrayToManifest[2]['Ship to'] ='Ship to';
            $ArrayToManifest[2]['Service'] ='Service';

            if ($UPSSiuntosArrayDB){
                $i = 3;
                $SipmentTotal = 0;
                $PackageTotal = 0;
                foreach ($UPSSiuntosArrayDB as $key => $eilute) {
                    if($eilute['SysManual']=='SYS'){
                        $ArrayToManifest[$i]['Tracking number'] =$eilute['PakuotesNr'];
                    }else{
                        $ArrayToManifest[$i]['Tracking number'] =$eilute['PakuotesNr'];
                    }
                    $ArrayToManifest[$i]['Packages'] =$eilute['Packages'];
                    $ArrayToManifest[$i]['Ship to'] =$eilute['Gavejas'].', '.$eilute['Adresas'];
                    $ArrayToManifest[$i]['Service'] =$eilute['Service'];

                    $SipmentTotal += $eilute['Packages'];
                    $PackageTotal += $eilute['Packages'];
                    $i++;
                }//foreach

            $ArrayToManifest[$i]['Tracking number'] = '';
            $ArrayToManifest[$i]['Packages'] ='';
            $ArrayToManifest[$i]['Ship to'] ='';
            $ArrayToManifest[$i]['Service'] ='';
            $i++;
            $ArrayToManifest[$i]['Tracking number'] = 'Shipment Total';
            $ArrayToManifest[$i]['Packages'] =$SipmentTotal;
            $ArrayToManifest[$i]['Ship to'] ='';
            $ArrayToManifest[$i]['Service'] ='';
            $i++;
            $ArrayToManifest[$i]['Tracking number'] = 'Package Total';
            $ArrayToManifest[$i]['Packages'] =$PackageTotal;
            $ArrayToManifest[$i]['Ship to'] ='';
            $ArrayToManifest[$i]['Service'] ='';


            }//end if


            //!!!!!! DEBUG
            $this->var_dump($ArrayToManifest, "ArrayToManifest MOD<hr>$qry<hr> ");//-----------------DEBUG

            return $ArrayToManifest;

}//end function



public function getTVSNr ($numberName){

            $NumeriuArray = $this->getTVSNumbers ();
            if($NumeriuArray){

                $numberValue=$NumeriuArray[$numberName];

                if(is_numeric($numberValue)){
                    try {
                        $newNumberValue = $numberValue +1;
                        $wsql = 'UPDATE _TMS_Numbers SET '.$numberName.'=\''.$newNumberValue.'\' WHERE  row=\'1\' ;';            
                        $wmssql = DBMSSqlCERM::getInstance();
                        $retSQL = $wmssql->execSql($wsql, 1);


                        //tikrinam ar pasididino numeris
                        $NumeriuArray2 = $this->getTVSNumbers ();
                        $numberValue2=$NumeriuArray2[$numberName];
                        if($numberValue2<=$numberValue){
                            $numberValue2 = 'ERROR';
                        }else{

                            //papildomas gauto numerio apdirbimas
                            switch ($numberName) {
                                /* generuoja atskira funkcija generateVP_Manifest
                                case 'VP_manifest':
                                    $numberValue2 = str_pad($numberValue2, 3, "0", STR_PAD_LEFT);
                                    break;
                                */
                                case 'VP_shipmentCode':
                                    $numberValue2 = 'S'.str_pad($numberValue2, 4, "0", STR_PAD_LEFT);
                                    break;
                                case 'VP_pack':
                                    $numberValue2 = str_pad($numberValue2, 7, "0", STR_PAD_LEFT);
                                    break;
                                case 'VP_kurjer_doc': //kurjerio iskvietimo doc numeris
                                    $numberValue2 = 'KI'.str_pad($numberValue2, 7, "0", STR_PAD_LEFT);
                                    break;
                                default:
                                    # code...
                                    break;
                            }
                        }

                    } catch (Exception $ex) {
                        $this->AddError((string)$ex);
                        $numberValue2 = 'ERROR';
                    }//catch                        
                }else{
                    $numberValue2 = 'ERROR';
                }
            }else{
                $numberValue2 = 'ERROR';
            }
            
    return $numberValue2;
}//end function




//uzdaro aktyvu VENIPAKO manifesta
public function closeVPManifest($KEGKPG){
    if($KEGKPG=='KPG'){
        try {
                $wsql = 'UPDATE TOP (1) _TMS_numbers SET
                            VP_OpenManifest         =   NULL,
                            VP_OpenManifestDate     =   NULL
                        WHERE  row=1 ;
                ';            

                $wmssql = DBMSSqlCERM::getInstance();
                $retSQL = $wmssql->execSql($wsql, 1);
                var_dump($wsql);
                $ret['OK'] = 'OK';
        } catch (Exception $ex) {
            $this->AddError((string)$ex);
            $ret['OK'] = 'NOT OK DB';
        }//catch
    }elseif($KEGKPG=='KEG'){
        try {
                $wsql = 'UPDATE TOP (1) _TMS_numbers SET
                            VP_OpenManifestKEG         =   NULL,
                            VP_OpenManifestDateKEG     =   NULL
                        WHERE  row=1 ;
                ';            

                $wmssql = DBMSSqlCERM::getInstance();
                $retSQL = $wmssql->execSql($wsql, 1);
                //var_dump($wsql);
                $ret['OK'] = 'OK';
        } catch (Exception $ex) {
            $this->AddError((string)$ex);
            $ret['OK'] = 'NOT OK DB';
        }//catch

    }elseif($KEGKPG=='ETK' OR $KEGKPG=='ETK1'){
        try {
                $wsql = 'UPDATE TOP (1) _TMS_numbers SET
                            VP_OpenManifestETK         =   NULL,
                            VP_OpenManifestDateETK     =   NULL
                        WHERE  row=1 ;
                ';            

                $wmssql = DBMSSqlCERM::getInstance();
                $retSQL = $wmssql->execSql($wsql, 1);
                //var_dump($wsql);
                $ret['OK'] = 'OK';
        } catch (Exception $ex) {
            $this->AddError((string)$ex);
            $ret['OK'] = 'NOT OK DB';
        }//catch
    }

    return $ret;

}//end function




//po siuntos registravimo, padarom pakeitimus Navisione, jeigu tai buvo siunta is Navisiono ir ne TEST siunta
public function saveTvsTranspRegNavision($toDB, $PSlipArray){

                            //!!!!!! DEBUG
                            //$this->var_dump($toDB, "toDB NAVISION after <hr>$wsql<hr> ");//-----------------DEBUG

                            //!!!!!! DEBUG
                            $this->var_dump($PSlipArray, "PSlipArray NAVISION after <hr>$wsql<hr> ");//-----------------DEBUG



    if($toDB AND COUNT($PSlipArray)>0){
        if($toDB['SiuntaUID']>0){
                try {
                        
                    if($toDB['actTip'] == 'SIUNTA'){
                        if($toDB['SendetXMLOK']==1){
                            $PackingSlipStrArray = "'" . implode("','", $PSlipArray)."'";
                            $siandien = date ("Y-m-d H:i:s");

                            //updatinam aktyviu Orderiu DB (dar neperkeltu i archyva)
                            $wsql = 'UPDATE [AURIKA_CERM].[dbo].[AURIKA CERM$Sales Header$478bcd1e-cac5-4def-9017-2ecd670bc386] SET
                                [APGDVSSendToDVS]         =   \'1\',
                                [APGDVSSendToDVSDateTime] =   \''.$siandien.'\'
                                WHERE  [No_] IN ('.$PackingSlipStrArray.')  ;
                            ';      
                                  
                            //WHERE  [No_] IN ('.$PackingSlipStrArray.')  ;
                            //WHERE  [No_] IN (\'UZS024400\',\'UZS024409\')  ;

                            //!!!!!! DEBUG
                            $this->var_dump($toDB, "toDB NAVISION after <hr>$wsql<hr> ");//-----------------DEBUG

                            //TODO reikia patikrinti ar nereikia to paties irasyti i kita lentele "AURIKA CERM$Sales Invoice Header$478bcd1e-cac5-4def-9017-2ecd670bc386" (joje atsiranda orderiai po ju uzbaigimo)
                            //TODO lentele tokia pati, tik skiriasi numeris, 
                            //TODO naujos lenteles numerius kuriuos reikia paupdatinti galima suristi per lentele AURIKA "CERM$Sales Invoice Header " lauka "Order No_"...... 
                            //TODO "CERM$Sales Invoice Header"."Order No_" = "CERM$Sales Header"."No_"


                            $mssqlNAV = DBMSSqlNAV::getInstance();
                            $retSQL = $mssqlNAV->execSql($wsql, 1);
                            $ret = 'OK';

                            echo "<br>*******RYQ1NAV-".$retSQL;




                            //updatinam uzdarytu Orderiu DB (jau perkeltu i archyva)
                            //pradzioj susirandam naujus numerius (tokie kokie jie tampa archyve)
                            $qry = '
                                SELECT [No_]
                                FROM [AURIKA_CERM].[dbo].[AURIKA CERM$Sales Invoice Header]
                                WHERE 
                                [Order No_] IN ('.$PackingSlipStrArray.')
                                ';
                            
                            
                            $NAVnewOrderNr = $mssqlNAV->querySql($qry, 1);

                            //!!!!!! DEBUG
                            $this->var_dump($NAVnewOrderNr, "NAVnewOrderNr <hr>$qry<hr> ");//-----------------DEBUG

                            if($NAVnewOrderNr){
                                //
                                $NewPackingSlipStrArray = array();
                                foreach ($NAVnewOrderNr as $key => $value) {
                                    $NewPackingSlipStrArray[]=$value['No_'];
                                }
                                $NewPackingSlipStrArrayStr = "'" . implode("','", $NewPackingSlipStrArray)."'";
                                $wsql1 = 'UPDATE [AURIKA_CERM].[dbo].[AURIKA CERM$Sales Invoice Header$478bcd1e-cac5-4def-9017-2ecd670bc386] SET
                                    [APGDVSSendToDVS]         =   \'1\',
                                    [APGDVSSendToDVSDateTime] =   \''.$siandien.'\'
                                    WHERE  [No_] IN ('.$NewPackingSlipStrArrayStr.')  ;
                                ';      
                                      
                                //WHERE  [No_] IN ('.$NewPackingSlipStrArrayStr.')  ;
                                //WHERE  [No_] IN (\'UZS024400\',\'UZS024409\')  ;

                                //!!!!!! DEBUG
                                $this->var_dump($toDB____, "toDB NAVISION after <hr>$wsql1<hr> ");//-----------------DEBUG

                                //$wmssql = DBMSSqlCERM::getInstance();
                                $retSQL1 = $mssqlNAV->execSql($wsql1, 1);
                                $ret1 = 'OK';

                                echo "<br>*******RYQ2NAV-".$retSQL1;
                            }//end if



                        }else{//jeigu nepavyko uzregistruoti siuntos
                        }


                    }elseif($toDB['actTip'] == 'KURJERIS'){
                        if($toDB['SendetXMLOK']==1){

                        }else{//jeigu nepavyko iskviesti kurjerio
                            /* nieko nekeiciam, kita isirays istorijoje apie nesekminga bandyma */
                        }
                        $ret = $this->saveTvsHis($toDB);
                        $ret = 'OK';
                    }


                } catch (Exception $ex) {
                    $this->AddError((string)$ex);
                    $ret = 'NOT OK DB';
                }//catch

        }else{//end if KiekPS
            $this->AddError("Klaida rašant į NAV DB. Nėra siuntos numerio.");
            $ret = 'NOT OK NDB7';
        }
    }else{
        $ret = 'NOT OK NDB8';
        $this->AddError("Nėra saugojamų duomenų.");
    }


    return $ret;

}//end function





//saugom veiksmo rezultatus registruojant siunta ir kvieciant kurjeri
//atitinkamai saugomi pavyke ir nepavyke bandymai i TMS_his lentele
public function saveTvsTranspReg($toDB){



    if($toDB){
        if($toDB['SiuntaUID']>0){
                try {
                        
                    if($toDB['actTip'] == 'SIUNTA'){
                        if($toDB['SendetXMLOK']==1){
                            $wsql = 'UPDATE TOP (1) _TMS_Siuntos SET
                                KrovinysReg         =   \''.$toDB['KrovinysReg'].'\',
                                SiuntaUzregistruota =   \''.$toDB['SiuntaUzregistruota'].'\',
                                SiuntosBusena       =   \''.$toDB['SiuntosBusena'].'\',
                                VezejasReal         =   \''.$toDB['VezejasReal'].'\',
                                VezejoSiuntNr       =   \''.$toDB['VezejoSiuntosNr'].'\',
                                Manifest            =   \''.$toDB['Manifest'].'\',
                                TrackingNr          =   \''.$toDB['TrackingNr'].'\',
                                Service             =   \''.$toDB['Service'].'\',
                                SysManual           =   \'SYS\',
                                LiveDemo            =   \''.$toDB['LiveDemo'].'\',
                                LabelLink           =   \''.$toDB['SiuntaPDF'].'\',
                                VaztLink            =   \''.$toDB['VaztarPDF'].'\'
                                WHERE  uid=\''.$toDB['SiuntaUID'].'\' ;
                            ';            
//210921____________________
                            //echo "<hr>$wsql<hr>";
    //!!!!!! DEBUG
    $this->var_dump($toDB, "toDB MOD<hr>$wsql<hr> ");//-----------------DEBUG


                            $wmssql = DBMSSqlCERM::getInstance();
                            $retSQL = $wmssql->execSql($wsql, 1);
                            $ret = 'OK';

                            echo "<br>*******RYQ1-".$retSQL;
                            //registruojam pakuociu IDus (pvz: V57943E0000100)
                            if($toDB['SendetXMLOK']==1){
                                if($toDB['HisAction']=='IDSCHENKER'){
                                    $rezPkuocID = $this->saveTvsSCHENKERPakuotesID($toDB);
                                }elseif($toDB['HisAction']=='IDVENIPAK'){
                                    $rezPkuocID = $this->saveTvsVENIPAKPakuotesID($toDB);
                                }elseif($toDB['HisAction']=='IDUPS'){
                                    $rezPkuocID = $this->saveTvsUPSPakuotesID($toDB);                                    
                                }elseif($toDB['HisAction']=='IDACE'){
                                    $rezPkuocID = $this->saveTvsACEPakuotesID($toDB);                                    
                                }elseif($toDB['HisAction']=='IDCAT'){
                                    $rezPkuocID = $this->saveTvsCATPakuotesID($toDB);                                    
                                }else{

                                }
                                if($rezPkuocID != 'OK'){
                                    $this->AddError("Klaida rašant į pakuočių duomenis DB.");
                                    $ret = 'NOT OK DB10';
                                }
                            }//end if

                        }else{//jeigu nepavyko uzregistruoti siuntos
                            /* nieko nekeiciam, kita isirays istorijoje apie nesekminga bandyma
                            $wsql = 'UPDATE TOP (1) _TMS_Siuntos SET
                                KrovinysReg         =   \''.$toDB['KurjerisReg'].'\',
                                SiuntaUzregistruota =   \''.$toDB['SiuntaUzregistruota'].'\',
                                SiuntosBusena       =   \''.$toDB['SiuntosBusena'].'\',
                                VezejasReal         =   \''.$toDB['VezejasReal'].'\'

                                WHERE  uid=\''.$toDB['SiuntaUID'].'\' ;
                            ';            
                            */
                        }


                        //echo "<br>*******RYQ2".$ret;

                        $ret = $this->saveTvsHis($toDB);

                        //echo "<br>*******RYQ3".$ret;



                    }elseif($toDB['actTip'] == 'KURJERIS'){
                        if($toDB['SendetXMLOK']==1){
                            $wsql = 'UPDATE TOP (1) _TMS_Siuntos SET
                                KurjerisReg         =   \''.$toDB['KurjerisReg'].'\',
                                VezejasUzsakyta     =   \''.$toDB['VezejasUzsakyta'].'\',
                                SiuntosBusena       =   \''.$toDB['SiuntosBusena'].'\',
                                VezejasReal         =   \''.$toDB['VezejasReal'].'\',
                                KurjOrderNr         =   \''.$toDB['OrderNr'].'\'

                                WHERE  uid=\''.$toDB['SiuntaUID'].'\' ;
                            ';            

                            //echo "<hr>$wsql<hr>";
                            $wmssql = DBMSSqlCERM::getInstance();
                            $retSQL = $wmssql->execSql($wsql, 1);


                        }else{//jeigu nepavyko iskviesti kurjerio
                            /* nieko nekeiciam, kita isirays istorijoje apie nesekminga bandyma
                            $wsql = 'UPDATE TOP (1) _TMS_Siuntos SET
                                KrovinysReg         =   \''.$toDB['KurjerisReg'].'\',
                                SiuntaUzregistruota =   \''.$toDB['SiuntaUzregistruota'].'\',
                                SiuntosBusena       =   \''.$toDB['SiuntosBusena'].'\',
                                VezejasReal         =   \''.$toDB['VezejasReal'].'\'

                                WHERE  uid=\''.$toDB['SiuntaUID'].'\' ;
                            ';            
                            */
                        }


                        $ret = $this->saveTvsHis($toDB);
                        $ret = 'OK';
                    }


                } catch (Exception $ex) {
                    $this->AddError((string)$ex);
                    $ret = 'NOT OK DB';
                }//catch

        }else{//end if KiekPS
            $this->AddError("Klaida rašant į DB. Nėra siuntos numerio.");
            $ret = 'NOT OK DB7';
        }
    }else{
        $ret = 'NOT OK DB8';
        $this->AddError("Nėra saugojamų duomenų.");
    }


    return $ret;
}//end function




//saugom irasa i istorija apie sekmingai/nesekmingai atliktus veiksmus
public function saveTvsHis($toDB){

    if($toDB){
        if($toDB['SiuntaUID']>0){
                try {
                        
                    //irasom siuntos duomenis
                    $siandien = date("Y-m-d H:i:s");

                    //TODO jeigu schenker tai is response XML iskerpam PDF (nes ilgas ir neatidaro is Heidi)



                    $sql = "
                        INSERT INTO _TMS_His (

                            SiuntaUID, 

                            Created,

                            HisGroup,
                            HisAction,

                            Owner, 
                            OwnerUID,

                            XMLSend, 
                            XMLReceived, 

                            Comment,
                            successfully

                        ) VALUES (

                            '".$toDB['SiuntaUID']."', 

                            '".$toDB['SendetXMLTime']."', 

                            '".$toDB['HisGroup']."', 
                            '".$toDB['HisAction']."', 

                            '".$toDB['SendetXMLUser']."', 
                            '".$toDB['SendetXMLUserUID']."', 

                            '".$toDB['SendetXML']."', 
                            '".$toDB['ResponseXML']."', 

                            '".$toDB['Comment']."', 
                            '".$toDB['SendetXMLOK']."'

                        );                    
                    ";

                    //echo "<hr>".$sql."<hr>";

                    $wmssql = DBMSSqlCERM::getInstance();
                    $retSQL = $wmssql->execSql($sql, 1);
                    $testing = $retSQL > 0;
                    //$test[$test_name] &= $testing;

                    $ret = 'OK';



                } catch (Exception $ex) {
                    $this->AddError((string)$ex);
                    $ret = 'NOT OK DB001';
                }//catch

        }else{//end if KiekPS
            $this->AddError("Klaida rašant į DB. Nėra siuntos numerio.");
            $ret = 'NOT OK DB002';
        }
    }else{
        $ret = 'NOT OK DB003';
        $this->AddError("Nėra saugojamų duomenų.");
    }

    return $ret;
}//end function



//saugom pakuociu ID () po siuntos registravimo
public function saveTvsVENIPAKPakuotesID($toDB){

    $ret = 'OK'; //pradinis nustatymas
    if($toDB){
        //var_dump($toDB);
        if($toDB['SiuntaUID']>0){
                $siandien = date("Y-m-d H:i:s");
                try {
                        
                    if($toDB['SiuntuNr']){
                        $wmssql = DBMSSqlCERM::getInstance();
                        foreach ($toDB['SiuntuNr'] as $key => $siunta) {

                            //TODO reikia prideti svorius ir turius
                            /*
                                formuoti toki masyva kai formuojamas XML (nes grazinami tik pakuotes numeriai)
                            
                                $packToReg
                                    [V57943E0000100]
                                        [svoris]=5;
                                        [turis]=0.05;
                                    [V57943E0000101]
                                        [svoris]=4;
                                        [turis]=0.03;

                                o tada pasiimti atitinkamai
                                $packToReg[$siunta['KR_SiuntaNr']]['svoris']
                                $packToReg[$siunta['KR_SiuntaNr']]['turis']


                                Taip pat reikia pasigrazinti ManifestID
                            */

                            //irasom siuntos duomenis
                            $SvorisTmp = str_replace('/\s+/', '', $toDB['PacksArrayFull'][$siunta['KR_SiuntaNr']]['Svoris'])*1;

                            $sql = "
                                INSERT INTO _TMS_Pak (

                                    SiuntaUID,
                                    PakuotesNr,
                                    PakTipas,
                                    ManifestID,
                                    Created,
                                    VezejasReal,
                                    PakDocNr,
                                    Svoris,
                                    Plotis,
                                    Ilgis,
                                    Aukstis,
                                    Turis,
                                    Busena,
                                    LipdukasPdf

                                ) VALUES (

                                    '".$toDB['SiuntaUID']."', 

                                    '".$siunta['KR_SiuntaNr']."', 
                                    '".$toDB['PacksArrayFull'][$siunta['KR_SiuntaNr']]['Tipas']."', 

                                    '".$toDB['ManifestID']."', 
                                    '".$siandien."', 

                                    'VENIPAK', 
                                    '".$toDB['PacksArrayFull'][$siunta['KR_SiuntaNr']]['pack_doc_no']."', 

                                    '".$SvorisTmp."', 
                                    '".$toDB['PacksArrayFull'][$siunta['KR_SiuntaNr']]['Plotis']."', 
                                    '".$toDB['PacksArrayFull'][$siunta['KR_SiuntaNr']]['Ilgis']."', 
                                    '".$toDB['PacksArrayFull'][$siunta['KR_SiuntaNr']]['Aukstis']."', 
                                    '".$toDB['PacksArrayFull'][$siunta['KR_SiuntaNr']]['Turis']."', 

                                    'R', 
                                    ''

                                );                    
                            ";

                            //echo "<hr>|".$SvorisTmp."|<Br>".$sql."<hr>";

                            
                            $retSQL = $wmssql->execSql($sql, 1);
                            $testing = $retSQL > 0;
                            //$test[$test_name] &= $testing;



                            
                        }//end foreach
                    }else{//end if
                        $this->AddError("Klaida rašant į DB. Nėra siuntos numerių.");
                        $ret = 'NOT OK DB804';
                    }


                } catch (Exception $ex) {
                    $this->AddError((string)$ex);
                    $ret = 'NOT OK DB801';
                }//catch

        }else{//end if KiekPS
            $this->AddError("Klaida rašant į DB. Nėra siuntos numerio.");
            $ret = 'NOT OK DB802';
        }
    }else{
        $ret = 'NOT OK DB803';
        $this->AddError("Nėra pakuočių duomenų.");
    }

    return $ret;
}//end function





//saugom pakuociu ID () po siuntos registravimo
public function saveTvsSCHENKERPakuotesID($toDB){

    $ret = 'OK'; //pradinis nustatymas
    if($toDB){
        //var_dump($toDB);
        if($toDB['SiuntaUID']>0){
                $siandien = date("Y-m-d H:i:s");
                try {
                        
                    if($toDB['SiuntuNr']){
                        $wmssql = DBMSSqlCERM::getInstance();
                        foreach ($toDB['SiuntuNr'] as $key => $siunta) {

                            //irasom siuntos duomenis
                            //$SvorisTmp = str_replace('/\s+/', '', $toDB['PacksArrayFull'][$siunta['KR_SiuntaNr']]['Svoris'])*1;

                            /* gesinam, nes jau ateina su cm .. kaip VENIPAKe
                            $Plotis = $siunta['Plotis']/10;//pervedam is mm i CM kaip VENIPAKE
                            $Ilgis = $siunta['Ilgis']/10;//pervedam is mm i CM kaip VENIPAKE
                            $Aukstis = $siunta['Aukstis']/10;//pervedam is mm i CM kaip VENIPAKE
                            $turis = $siunta['Turis']/100; //pervedam i dm2 -> m2
                            */

                            $sql = "
                                INSERT INTO _TMS_Pak (

                                    SiuntaUID,
                                    PakuotesNr,
                                    PakTipas,
                                    ManifestID,
                                    Created,
                                    VezejasReal,
                                    PakDocNr,
                                    Svoris,
                                    Plotis,
                                    Ilgis,
                                    Aukstis,
                                    Turis,
                                    Busena,
                                    LipdukasPdf

                                ) VALUES (

                                    '".$toDB['SiuntaUID']."', 

                                    '".$toDB['SiuntuNrSCH']."', 
                                    '".$siunta['Tipas']."', 

                                    '', 
                                    '".$siandien."', 

                                    'SCHENKER', 
                                    '".$toDB['SiuntuDocNr']."', 

                                    '".$siunta['Svoris']."', 
                                    '".$Plotis."', 
                                    '".$Ilgis."', 
                                    '".$Aukstis."', 
                                    '".$turis."', 

                                    'R', 
                                    ''

                                );                    
                            ";

                            //echo "<hr>|".$SvorisTmp."|<Br>".$sql."<hr>";

                            
                            $retSQL = $wmssql->execSql($sql, 1);
                            $testing = $retSQL > 0;
                            //$test[$test_name] &= $testing;



                            
                        }//end foreach
                    }else{//end if
                        $this->AddError("Klaida rašant į DB. Nėra siuntos numerių.");
                        $ret = 'NOT OK DB804';
                    }


                } catch (Exception $ex) {
                    $this->AddError((string)$ex);
                    $ret = 'NOT OK DB801';
                }//catch

        }else{//end if KiekPS
            $this->AddError("Klaida rašant į DB. Nėra siuntos numerio.");
            $ret = 'NOT OK DB802';
        }
    }else{
        $ret = 'NOT OK DB803';
        $this->AddError("Nėra pakuočių duomenų.");
    }

    return $ret;
}//end function



//saugom pakuociu ID () po siuntos registravimo
public function saveTvsUPSPakuotesID($toDB){

    $ret = 'OK'; //pradinis nustatymas
    if($toDB){
        //var_dump($toDB);
        if($toDB['SiuntaUID']>0){
                $siandien = date("Y-m-d H:i:s");
                try {
                        
                    if($toDB['PacksArrayFull']){
                        $wmssql = DBMSSqlCERM::getInstance();
                        foreach ($toDB['PacksArrayFull'] as $key => $siunta) {


                            //irasom siuntos duomenis
                            //$SvorisTmp = str_replace('/\s+/', '', $toDB['PacksArrayFull'][$siunta['KR_SiuntaNr']]['Svoris'])*1;

                            $sql = "
                                INSERT INTO _TMS_Pak (

                                    SiuntaUID,
                                    PakuotesNr,
                                    PakTipas,
                                    ManifestID,
                                    Created,
                                    VezejasReal,
                                    PakDocNr,
                                    Svoris,
                                    Plotis,
                                    Ilgis,
                                    Aukstis,
                                    Turis,
                                    Busena,
                                    LipdukasPdf

                                ) VALUES (

                                    '".$toDB['SiuntaUID']."', 

                                    '".$siunta['TrackingNr']."', 
                                    '".$siunta['Tipas']."', 

                                    '', 
                                    '".$siandien."', 

                                    '".$siunta['VezejasReal']."', 
                                    '".$toDB['VezejoSiuntosNr']."', 

                                    '".$siunta['Svoris']."', 
                                    '".$siunta['Plotis']."', 
                                    '".$siunta['Ilgis']."', 
                                    '".$siunta['Aukstis']."', 
                                    '".$siunta['Turis']."', 

                                    'R', 
                                    '".$siunta['LipdukasPdf']."'

                                );                    
                            ";

                            //echo "<hr>|".$SvorisTmp."|<Br>".$sql."<hr>";

                            
                            $retSQL = $wmssql->execSql($sql, 1);
                            $testing = $retSQL > 0;
                            //$test[$test_name] &= $testing;



                            
                        }//end foreach
                    }else{//end if
                        $this->AddError("Klaida rašant į DB. Nėra siuntos numerių.");
                        $ret = 'NOT OK DB804';
                    }


                } catch (Exception $ex) {
                    $this->AddError((string)$ex);
                    $ret = 'NOT OK DB801';
                }//catch

        }else{//end if KiekPS
            $this->AddError("Klaida rašant į DB. Nėra siuntos numerio.");
            $ret = 'NOT OK DB802';
        }
    }else{
        $ret = 'NOT OK DB803';
        $this->AddError("Nėra pakuočių duomenų.");
    }

    return $ret;
}//end function




//saugom pakuociu ID () po siuntos registravimo
public function saveTvsACEPakuotesID($toDB){

    $ret = 'OK'; //pradinis nustatymas
    if($toDB){
        //var_dump($toDB);
        if($toDB['SiuntaUID']>0){
                $siandien = date("Y-m-d H:i:s");
                try {
                        
                    if($toDB['PacksArrayFull']){
                        $wmssql = DBMSSqlCERM::getInstance();
                        foreach ($toDB['PacksArrayFull'] as $key => $siunta) {


                            //irasom siuntos duomenis
                            //$SvorisTmp = str_replace('/\s+/', '', $toDB['PacksArrayFull'][$siunta['KR_SiuntaNr']]['Svoris'])*1;

                            $sql = "
                                INSERT INTO _TMS_Pak (

                                    SiuntaUID,
                                    PakuotesNr,
                                    PakTipas,
                                    ManifestID,
                                    Created,
                                    VezejasReal,
                                    PakDocNr,
                                    Svoris,
                                    Plotis,
                                    Ilgis,
                                    Aukstis,
                                    Turis,
                                    Busena,
                                    LipdukasPdf

                                ) VALUES (

                                    '".$toDB['SiuntaUID']."', 

                                    '".$siunta['TrackingNr']."', 
                                    '".$siunta['Tipas']."', 

                                    '', 
                                    '".$siandien."', 

                                    '".$siunta['VezejasReal']."', 
                                    '".$toDB['VezejoSiuntosNr']."', 

                                    '".$siunta['Svoris']."', 
                                    '".$siunta['Plotis']."', 
                                    '".$siunta['Ilgis']."', 
                                    '".$siunta['Aukstis']."', 
                                    '".$siunta['Turis']."', 

                                    'R', 
                                    '".$siunta['LipdukasPdf']."'

                                );                    
                            ";

                            //echo "<hr>|".$SvorisTmp."|<Br>".$sql."<hr>";

                            
                            $retSQL = $wmssql->execSql($sql, 1);
                            $testing = $retSQL > 0;
                            //$test[$test_name] &= $testing;



                            
                        }//end foreach
                    }else{//end if
                        $this->AddError("Klaida rašant į DB. Nėra siuntos numerių.");
                        $ret = 'NOT OK DB804';
                    }


                } catch (Exception $ex) {
                    $this->AddError((string)$ex);
                    $ret = 'NOT OK DB801';
                }//catch

        }else{//end if KiekPS
            $this->AddError("Klaida rašant į DB. Nėra siuntos numerio.");
            $ret = 'NOT OK DB802';
        }
    }else{
        $ret = 'NOT OK DB803';
        $this->AddError("Nėra pakuočių duomenų.");
    }

    return $ret;
}//end function





public function saveTvsCATPakuotesID($toDB){

    $ret = 'OK'; //pradinis nustatymas
    if($toDB){
        var_dump($toDB);
        if($toDB['SiuntaUID']>0){
                $siandien = date("Y-m-d H:i:s");
                try {
                        
                    if($toDB['PacksArrayFull']){
                        $wmssql = DBMSSqlCERM::getInstance();
                        foreach ($toDB['PacksArrayFull'] as $key => $siunta) {


                            //irasom siuntos duomenis
                            //$SvorisTmp = str_replace('/\s+/', '', $toDB['PacksArrayFull'][$siunta['KR_SiuntaNr']]['Svoris'])*1;

                            $sql = "
                                INSERT INTO _TMS_Pak (

                                    SiuntaUID,
                                    PakuotesNr,
                                    PakTipas,
                                    ManifestID,
                                    Created,
                                    VezejasReal,
                                    PakDocNr,
                                    Svoris,
                                    Plotis,
                                    Ilgis,
                                    Aukstis,
                                    Turis,
                                    Busena,
                                    LipdukasPdf

                                ) VALUES (

                                    '".$toDB['SiuntaUID']."', 

                                    '".$toDB['VezejoSiuntosNr']."', 
                                    '".$siunta['Tipas']."', 

                                    '', 
                                    '".$siandien."', 

                                    '".$toDB['VezejasReal']."', 
                                    '".$toDB['VezejoSiuntosNr']."', 

                                    '".$siunta['Svoris']."', 
                                    '".$siunta['Plotis']."', 
                                    '".$siunta['Ilgis']."', 
                                    '".$siunta['Aukstis']."', 
                                    '".$siunta['Turis']."', 

                                    'R', 
                                    ''

                                );                    
                            ";

                            //echo "<hr>|".$SvorisTmp."|<Br>".$sql."<hr>";

                            
                            $retSQL = $wmssql->execSql($sql, 1);
                            $testing = $retSQL > 0;
                            //$test[$test_name] &= $testing;



                            
                        }//end foreach
                    }else{//end if
                        $this->AddError("Klaida rašant į DB. Nėra siuntos numerių.");
                        $ret = 'NOT OK DB804';
                    }


                } catch (Exception $ex) {
                    $this->AddError((string)$ex);
                    $ret = 'NOT OK DB801';
                }//catch

        }else{//end if KiekPS
            $this->AddError("Klaida rašant į DB. Nėra siuntos numerio.");
            $ret = 'NOT OK DB802';
        }
    }else{
        $ret = 'NOT OK DB803';
        $this->AddError("Nėra pakuočių duomenų.");
    }

    return $ret;
}//end function




//saugom pakuociu ID () po siuntos registravimo
public function saveTvsMANUALPakuotesID($pakuociuArray){

    $ret = 'OK'; //pradinis nustatymas
    if($pakuociuArray){
        //var_dump($toDB);

                $siandien = date("Y-m-d H:i:s");
                try {
                        

                        $wmssql = DBMSSqlCERM::getInstance();
                        foreach ($pakuociuArray as $key => $siunta) {

                            $Plotis = $siunta['pPlotis'];//cm
                            $Ilgis = $siunta['pIlgis'];//cm
                            $Aukstis = $siunta['pAukstis'];//cm
                            $turis = ($Plotis/100) * ($Ilgis/100) * ($Aukstis/100); //m3
                            $Svoris = $siunta['pPakioSvoris'];//kg

                            $sql = "
                                INSERT INTO _TMS_Pak (

                                    SiuntaUID,
                                    PakuotesNr,
                                    PakTipas,
                                    ManifestID,
                                    Created,
                                    VezejasReal,
                                    PakDocNr,
                                    Svoris,
                                    Plotis,
                                    Ilgis,
                                    Aukstis,
                                    Turis,
                                    Busena,
                                    LipdukasPdf

                                ) VALUES (

                                    '".$siunta['SiuntaUID']."', 
                                    '".$siunta['PakuotesNr']."', 
                                    '".$siunta['pTipas']."', 

                                    '', /* Manifest */
                                    '".$siandien."', 

                                    '".$siunta['VezejasReal']."', 
                                    '".$siunta['SiuntuDocNr']."', 

                                    '".$Svoris."', 
                                    '".$Plotis."', 
                                    '".$Ilgis."', 
                                    '".$Aukstis."', 
                                    '".$turis."', 

                                    'R', 
                                    ''

                                );                    
                            ";

                            //echo "<hr>|".$SvorisTmp."|<Br>".$sql."<hr>";

                            
                            $retSQL = $wmssql->execSql($sql, 1);
                            $testing = $retSQL > 0;
                            //$test[$test_name] &= $testing;


                            if(!$packArray){
                                $ret = 'NOT OK DB815';
                            }
                            
                        }//end foreach

                        //tikrinam ar isirase
                        $qry = "
                            SELECT  
                                *
                            FROM _TMS_Pak
                            WHERE deleted<>1 AND SiuntaUID='".$siunta['SiuntaUID']."'
                        ";
                        
                        //$wmssql = DBMSSqlCERM::getInstance();
                        $packArray = $wmssql->querySql($qry, 1);
                        //var_dump($packArray);


                } catch (Exception $ex) {
                    $this->AddError((string)$ex);
                    $ret = 'NOT OK DB801';
                }//catch

    }else{
        $ret = 'NOT OK DB803';
        $this->AddError("Nėra pakuočių duomenų.");
    }

    $rez['OK']=$ret;
    $rez['PAKS']=$packArray;
    return $rez;
}//end function





public function getFullPackData($sDuom){

    $packData = array();
    //if($sDuom['SiuntaUID']){
        $siuntaFullData = $this->getSiuntaDataSuPack($sDuom);   

        if($sDuom['sPakuote']){
            $packNr = $sDuom['sPakuote'];
        }else{
            $packNr = $siuntaFullData['PAKS'][0]['PakuotesNr'];
        }
        if($packNr){
                $qry = "
                    SELECT  
                        *
                    FROM _TMS_Pak
                    WHERE deleted<>1 AND PakuotesNr='".$packNr."'
                ";
                
                $mssql = DBMSSqlCERM::getInstance();
                $packData = $mssql->querySqlOneRow($qry, 1);

        }

        $siuntaFullData ['THISPACKDATA'] = $packData;
    //}

    //!!!!!! DEBUG
    //$this->var_dump($siuntaFullData, "siuntaFullData <hr>$packNr<hr>$qry<hr> ");//-----------------DEBUG

    return $siuntaFullData;

}//end function






public function getSiuntaDataSuPack($sDuom){

    $mssql = DBMSSqlCERM::getInstance();

    $siuntaData = array();

    $SiuntaUID = $sDuom['sSiunta'];

    //jeigu tarp paieskos parametru nera siuntos nr tai ziurim kaip ji surasti
    if(!$SiuntaUID){
        if($sDuom['sPakuote']){
            $qryP = "
                SELECT  
                    uid, SiuntaUID
                FROM _TMS_Pak
                WHERE deleted<>1 AND PakuotesNr='".$sDuom['sPakuote']."'
            ";
            $packsSiuntaData = $mssql->querySqlOneRow($qryP, 1);

            if($packsSiuntaData['SiuntaUID']){
                $SiuntaUID = $packsSiuntaData['SiuntaUID'];
            }//end if
        }//end if
    }//end if


    if($SiuntaUID){
            $qryS = "
                SELECT  
                    *
                FROM _TMS_Siuntos
                WHERE deleted<>1 AND uid='".$SiuntaUID."' 
            ";
            
            $mssql = DBMSSqlCERM::getInstance();
            $siuntaData = $mssql->querySqlOneRow($qryS, 1);

            //nuskaitom pakuociu duomenis prie siuntos
            $qryP = "
                SELECT  
                    *
                FROM _TMS_Pak
                WHERE deleted<>1 AND SiuntaUID='".$SiuntaUID."' 
            ";
            $packsData = $mssql->querySql($qryP, 1);


            //nuskaitom history duomenis
            $qryH = "
                SELECT  
                    *
                FROM _TMS_His
                WHERE SiuntaUID='".$SiuntaUID."'
                ORDER BY uid DESC
            ";
            
            $hiskData = $mssql->querySql($qryH, 1);

    }else{

    }


    $rezData = $siuntaData;
    $rezData['PAKS'] = $packsData;
    $rezData['HISTORY'] = $hiskData;

    return $rezData;

}//end function



public function saveLabelFileToDB($packNr, $output_file){

    $ret = 'NOTOK'; //pradinis nustatymas
    if($packNr AND $output_file){
                try {
                        
                        $wsql = 'UPDATE _TMS_Pak SET LipdukasPdf=\''.$output_file.'\' WHERE  PakuotesNr=\''.$packNr.'\' ;';            
                        $wmssql = DBMSSqlCERM::getInstance();
                        $retSQL = $wmssql->execSql($wsql, 1);
                            
                        $ret = 'OK';
                } catch (Exception $ex) {
                    $this->AddError((string)$ex);
                    $ret = 'NOT OK DB801';
                }//catch

    }else{
        $ret = 'NOT OK DB803';
        $this->AddError("Duomeų perdavimo klaida saugant lipduko PDF į DB.");
    }

    return $ret;

}//end function


public function saveLabelSiuntaFileToDB($SiuntaNr, $output_file){

    $ret = 'NOTOK'; //pradinis nustatymas
    if($SiuntaNr AND $output_file){
                try {
                        
                        $wsql = 'UPDATE _TMS_Siuntos SET LabelLink=\''.$output_file.'\' WHERE  uid=\''.$SiuntaNr.'\' ;';   
                        //var_dump($wsql) ;       
                        $wmssql = DBMSSqlCERM::getInstance();
                        $retSQL = $wmssql->execSql($wsql, 1);
                            
                        $ret = 'OK';
                } catch (Exception $ex) {
                    $this->AddError((string)$ex);
                    $ret = 'NOT OK DB801';
                }//catch

    }else{
        $ret = 'NOT OK DB803';
        $this->AddError("Duomeų perdavimo klaida saugant lipduko PDF į DB.");
    }

    return $ret;

}//end function




public function saveLabelAllFileToDB($Manifest, $output_file){

    $ret = 'NOTOK'; //pradinis nustatymas
    if($Manifest AND $output_file){
                try {
//TODO Manifesto lipdukas rasosi i kita vieta (lauka)
                        //$wsql = 'UPDATE _TMS_Siuntos SET LabelLink=\''.$output_file.'\' WHERE  Manifest=\''.$Manifest.'\' ;';            
                        $wsql = 'UPDATE _TMS_Siuntos SET LabelLinkMan=\''.$output_file.'\' WHERE  Manifest=\''.$Manifest.'\' ;';            
                        $wmssql = DBMSSqlCERM::getInstance();
                        $retSQL = $wmssql->execSql($wsql, 1);
                            
                        $ret = 'OK';
                } catch (Exception $ex) {
                    $this->AddError((string)$ex);
                    $ret = 'NOT OK DB801';
                }//catch

    }else{
        $ret = 'NOT OK DB803';
        $this->AddError("Duomeų perdavimo klaida saugant lipduko PDF į DB.");
    }

    return $ret;

}//end function






    public function checkPacks ($PaksStr){

        

        $yraKlaidu['YRA'] = 'N';
        $yraKlaidu['SUMSVORIS'] = 0;

        $pakKiekis = 0;
        $pakSvoris = 0;
        $pakSumSvoris = 0;

        //tikrinam duomenis
        if ($PaksStr){

            //parsinam pakuotes
            $PaksArray = array();
            $i = 0;

            $paksBigArray = explode("::", $PaksStr);
            var_dump($paksBigArray);
            if($paksBigArray){

                foreach ($paksBigArray as $key => $pakuoteStr) {
                    if($pakuoteStr){
                        list($pKiekis, $pTipas, $pMatmenysStr, $pPakioSvoris) = explode("|", $pakuoteStr);
                        list($pPlotis, $pIlgis, $pAukstis) = explode("x", $pMatmenysStr);


                        if (!$pKiekis OR $pKiekis <=0 ){
                            $yraKlaidu['YRA'] = 'Y';
                            $yraKlaidu['Kiekis'] = "Neteisingai įvestas pakuočių kiekis.\n";
                        }

                        if (!$pPakioSvoris OR $pPakioSvoris <=0 ){
                            $yraKlaidu['YRA'] = 'Y';
                            $yraKlaidu['Svoris'] = "Neteisingai įvestas pakuočių svoris.\n";
                        }

                        if (!$pPlotis OR $pPlotis <=0 ){
                            $yraKlaidu['YRA'] = 'Y';
                            $yraKlaidu['Plotis'] = "Neteisingai įvestas pakuočių plotis.\n";
                        }

                        if (!$pIlgis OR $pIlgis <=0 ){
                            $yraKlaidu['YRA'] = 'Y';
                            $yraKlaidu['Ilgis'] = "Neteisingai įvestas pakuočių ilgis.\n";
                        }

                        if (!$pAukstis OR $pAukstis <=0 ){
                            $yraKlaidu['YRA'] = 'Y';
                            $yraKlaidu['Aukstis'] = "Neteisingai įvestas pakuočių aukštis.\n";
                        }

                        $GalimiTipaiArray = array ('PK', 'EP','MP', 'RD','DD');
                        if(!in_array($pTipas, $GalimiTipaiArray)){
                            $yraKlaidu['YRA'] = 'Y';
                            $yraKlaidu['Tipas'] = "Neteisingai patinktas pakuočių tipas.\n";
                        }

                        if($yraKlaidu['YRA'] != 'Y'){
                            $pakSumSvoris += ($pKiekis * $pPakioSvoris);

                        }

                    }
                }//end foreach

                $yraKlaidu['SUMSVORIS'] = $pakSumSvoris;

            }else{//end 
                $yraKlaidu['YRA'] = 'Y';
                $yraKlaidu['Kita'] = "Neteisingai suformuoti duomenys apie pakuotes.\n";
                $yraKlaidu['SUMSVORIS'] = 0;
            }

        }else{//end if $addressData
            $yraKlaidu['YRA'] = 'Y';
            $yraKlaidu['Kita'] = "Nėra duomenų apie pakuotes.\n";
            $yraKlaidu['SUMSVORIS'] = 0;
        }

        //priskiriam adresa


        return $yraKlaidu; //boolen
    }//end function



    public function parsePacksStrToArray ($PaksStr){


        $yraKlaidu['YRA'] = 'N';
        $PaksArray = array();

        //tikrinam duomenis
        if ($PaksStr){

            $i = 0;

            $paksBigArray = explode("::", $PaksStr);
            if($paksBigArray){

                foreach ($paksBigArray as $key => $pakuoteStr) {
                    $yraKlaidu = 'N'; //nunulinam pries kiekviena eilute, auksciau yra padaryta klaidu tikrinimo funkcija checkPacks ($PaksStr). galima ja paleisti pries kreipiantis i sia
                    if($pakuoteStr){
                        list($pKiekis, $pTipas, $pMatmenysStr, $pPakioSvoris) = explode("|", $pakuoteStr);
                        list($pPlotis, $pIlgis, $pAukstis) = explode("x", $pMatmenysStr);


                        if (!$pKiekis OR $pKiekis <=0 ){
                            $yraKlaidu = 'Y';
                        }

                        if (!$pPakioSvoris OR $pPakioSvoris <=0 ){
                            $yraKlaidu = 'Y';
                        }

                        if (!$pPlotis OR $pPlotis <=0 ){
                            $yraKlaidu = 'Y';
                        }

                        if (!$pIlgis OR $pIlgis <=0 ){
                            $yraKlaidu = 'Y';
                        }

                        if (!$pAukstis OR $pAukstis <=0 ){
                            $yraKlaidu = 'Y';
                        }

                        $GalimiTipaiArray = array ('PK', 'EP','MP', 'RD','DD');
                        if(!in_array($pTipas, $GalimiTipaiArray)){
                            $yraKlaidu = 'Y';
                        }

                        if($yraKlaidu != 'Y'){
                            $PaksArray[$i]['pKiekis'] = $pKiekis;
                            $PaksArray[$i]['pTipas'] = $pTipas;
                            $PaksArray[$i]['pPakioSvoris'] = $pPakioSvoris;
                            $PaksArray[$i]['pPlotis'] = $pPlotis;
                            $PaksArray[$i]['pIlgis'] = $pIlgis;
                            $PaksArray[$i]['pAukstis'] = $pAukstis;

                        }//end if

                        $i++;
                    }
                }//end foreach


            }else{//end 
                $yraKlaidu = 'Y';

            }

        }else{//end if $addressData
            $yraKlaidu = 'Y';
        }

        //!!!!!! DEBUG
        $this->var_dump($PaksArray, "PaksArray");//-----------------DEBUG


        return $PaksArray; //boolen
    }//end function



    public function GetSavedTrackingNumber($SiuntaID){
        
        if($SiuntaID){

            $sDuom['sSiunta'] = $SiuntaID;
            $rezData = $this->getSiuntaDataSuPack($sDuom);

        }//end if

        $rezTrackingNr = array();
        $i=0;
        if($rezData){
            if($rezData['VezejasReal']=='VENIPAK' OR $rezData['VezejasReal']=='SCHENKER' OR $rezData['VezejasReal']=='UPS'){
                if($rezData['PAKS']){
                    foreach ($rezData['PAKS'] as $keyP => $pakuote) {
                        if($pakuote['PakuotesNr']){
                            $rezTrackingNr[$i]['TrackingNr'] = $pakuote['PakuotesNr'];
                            $rezTrackingNr[$i]['VezejasReal'] = $pakuote['VezejasReal'];
                            $i++;
                        }//end if
                    }//end foreach
                }//end if
            }else{

            }
        }else{
            
        }

        return $rezTrackingNr;
    }//end function



    public function ParinktiVezeja($Param)
    {


    //!!!!!! DEBUG
    $this->var_dump($Param, "-------Param <hr><hr> ");//-----------------DEBUG



        /*
            Parametrai, pagal kuriuos nustatomas vezejas:
            - bendras svoris
            - pakuociu skaicius
            - tranzito laikas
            - salies kodas
            - klientasID
            - vezejas CERM ar tai 'AURIKA', 'KLIENTO TR'
            - ar express pozymis


            $Param['ClientID']=$PackData['SHORT']['ClientID'];
            $Param['VezejasStr']=$PackData['SHORT']['VezejasStr'];
            $Param['Det_SaliesKodas']=$PackData['SHORT']['Det_SaliesKodas'];
            $Param['GalutinisBrutto']=$PackData['SVORIAI']['GalutinisBrutto'];
            $Param['PakuociuSk']=$PakuociuSk;
            $Param['PaleciuSk']=$PaleciuSk;
            $Param['PakTipas']=$PakTipas;
            $Param['TranzitoLaikas']=$PackData['SHORT']['PristaLaikasDarboDienomis'];
            $Param['Express']=$PackData['SHORT']['express'];

            JS
            $Param['ClientID']=
            $Param['VezejasStr']=$('#Det_Vezejas').html(obj.SHORT.VezejasStr); 
            $Param['Det_SaliesKodas']=$('#Det_SaliesKodas').val(obj.ADRESAI.CONSIGNEE.countryCode);
            $Param['GalutinisBrutto']=$('#msvorisBrutto').val(obj.SVORIAI.GalutinisBrutto);
            $Param['PakuociuSk']=
            $Param['PaleciuSk']=
            $Param['PakTipas']=
            $Param['TranzitoLaikas']=
            $Param['Express']=$('#Det_Express').val(obj.SHORT.express);

            20211001
            Surašiau transporto pasirinkimo logiką

            1.  Pirmu prioritetu jei vežame svorius iki 20kg ir ne daugiau 5 pakuotės renkames UPS (jei atitinka tranzito laikas)- paslauga STANDART 
            2.  Jei tranzito laikas mažesnis (bet ne express požymis) svoris didesnis arba pakuočių daugiau- pasirinkimas SCHENKER
            3.  Jei Express (1 d pristatymas) paliekam rankinio registravimo pasirinkimą (kai bus padaryta  integracija su DHL reiks jį užkelti su šiuo pasirinkimu)
            4.  Jei šalis neįtraukta (CH, UK, USA ir pan)- rankinis registravimas


            UPS pasirinkimo logikos pagal šalis:
            DE-tranzitas:3 d ir daugiau 
            Svoris ne daugiau 20kg IR ne daugiau nei 5 pakuotės

            AT-tranzitas:3 d ir daugiau 
            Svoris ne daugiau 20kg IR ne daugiau nei 5 pakuotės


            DK-tranzitas:3d ir daugiau
            Svoris ne daugiau 20kg IR ne daugiau nei 5 pakuotės

            SE-tranzitas:4 d ir daugiau
            Svoris ne daugiau 20kg IR ne daugiau nei 5 pakuotės

            FI -tranzitas: 3 d ir daugiau
            Svoris ne daugiau 20kg IR ne daugiau nei 5 pakuotės


            PL- tranzitas:2 d. ir daugiau
            Svoris ne daugiau 20kg IR ne daugiau nei 5 pakuotės

            NL-tranzitas: 3 d ir daugiau
            Svoris ne daugiau 20kg IR ne daugiau nei 5 pakuotės


            BE-tranzitas: 3 d ir daugiau
            Svoris ne daugiau 20kg IR ne daugiau nei 5 pakuotės

            FR - tranzitas : 4 d ir daugiau
            Svoris ne daugiau 20kg IR ne daugiau nei 5 pakuotės


        */

        $NewVezejas = "MANUAL"; //defaultinis atvejis

        if($Param){
            //Estrella 100889 (kitos estrella nereikalingos)
            //Marood 100888
            //Packarna 100941
            //Voss  103355
            $vaziuojaTikSuDSVArray = array('100889', '100888', '100941', '103355');
            $vaziuojaTikSuCATArray = array('101747', '103341');
            $vaziuojaSavoTransportuArray = array('AURIKA', 'KLIENTO TR');
            if(in_array($Param['ClientID'], $vaziuojaTikSuDSVArray)){
                //$NewVezejas = "DSV";
                $NewVezejas = "MANUAL";
            }elseif(in_array($Param['ClientID'], $vaziuojaTikSuCATArray)){
                $NewVezejas = "CAT";
            }elseif($Param['VezejasStr']=='PICKUP VEN'){
                $NewVezejas = "VENIPAK";
            }elseif(in_array($Param['VezejasStr'], $vaziuojaSavoTransportuArray)){
                $NewVezejas = "KITA";//Kai vezama su Aurika arba KLIENTO transportas
            }else{
                switch ($Param['Det_SaliesKodas']) {
                    case 'LT': //LT, LV, EE 
                    case 'LV': //LT, LV, EE 
                    case 'EE': //LT, LV, EE 
                        /* 20250312 - Disablinam logika CAT parinkimui, ji pasikeite, paliekam cia tik Venipak kaip buvo anksciau
                        if($Param['PakTipas']=='P' AND $Param['Det_SaliesKodas']=='LV' AND $Param['ShipmentFromStr']=='KPG'){
                            $NewVezejas = "CAT"; // jeigu is LV, FI, PL ir  palete ir is KPG sandelio tai tada CAT (automatinis registravimas)// laiskas is transportas@aurika.lt 2024-09-18 16:16
                        }else{
                            $NewVezejas = "VENIPAK"; // jeigu ne is LV ir ne palete ir ne is KPG sandelio tai tada VENIPAK
                        }
                        */
                        $NewVezejas = "VENIPAK"; // jeigu ne is LV ir ne palete ir ne is KPG sandelio tai tada VENIPAK
                        break;
                    case 'DE': //DE, AT
                    case 'AT': //DE, AT 
                    case 'NO': //DE, AT 
                    case 'SE': //DE, AT 
                    case 'BE': //DE, AT 
                    case 'DK': //DE, AT 
                    case 'FR': //DE, AT 
                    case 'NL': //DE, AT 
                    case 'PL': //DE, AT 
                    case 'FI': //DE, AT 
                        /* Pasikeite nuo 20211004 pagal Editos nauja parinkimo logika
                        if($Param['GalutinisBrutto']*1<100){//jeigu bendras svoris maziau uz 100 kg tada vezam su ACE
                            $NewVezejas = "MANUAL";//ACE
                        }else{
                            $NewVezejas = "SCHENKER";
                        }
                        */

                        //20250206 TIK TESTAVIMUI - laikinai disablinam, kol iki galo neveikia CAT - istrinti salyga is IF "AND $DISABLINAM_CAT !='Y' " ARBA padaryti $DISABLINAM_CAT = 'N'
                        //$DISABLINAM_CAT = 'Y'; // cia disablinam CAT parinkima, kol jis iki galo nepadarytas, veliau reikes pakeisti i 'N'

                        if($Param['Express']=='Y'){
                            $NewVezejas = "MANUAL";
                        /*20250312 - Disablinam logika CAT parinkimui, ji pasikeite
                        }elseif($DISABLINAM_CAT != 'Y' AND $Param['PakTipas']=='P' AND ($Param['Det_SaliesKodas']=='PL' OR $Param['Det_SaliesKodas']=='FI') AND $Param['ShipmentFromStr']=='KPG'){// jeigu is LV, FI, PL ir  palete ir is KPG sandelio tai tada CAT (automatinis registravimas)// laiskas is transportas@aurika.lt 2024-09-18 16:16
                            $NewVezejas = "CAT";
                        */
                        }elseif($Param['GalutinisBrutto']*1 <= 20 AND $Param['PakuociuSk']<=5 AND $Param['PaleciuSk']<=0 ){
                            //$NewVezejas = "UPS";
                            $NewVezejas = "SCHENKER"; //pradinis pries patikrinant ar tai ne UPS siunta
                            switch ($Param['Det_SaliesKodas']) {
                                case 'DE':
                                case 'AT':
                                case 'DK':
                                case 'FI':
                                case 'NL':
                                case 'BE':
                                    if($Param['TranzitoLaikas']>=3){//jeigu tranzitas 3 d ir daugiau
                                        
                                        //20220222 - Editos laiskas (2022-02-14 08:01) - reikia nuimti UPS ir palikti tik VENIPAK IR SCHENKER. Anksciau cia buvo UPS, dabar MANUAL
                                        //$NewVezejas = "UPS";
                                        $NewVezejas = "MANUAL";
                                    }else{
                                        $NewVezejas = "SCHENKER";
                                    }
                                    break;
                                case 'SE':
                                case 'FR':
                                    if($Param['TranzitoLaikas']>=4){//jeigu tranzitas 3 d ir daugiau
                                        //20220222 - Editos laiskas (2022-02-14 08:01) - reikia nuimti UPS ir palikti tik VENIPAK IR SCHENKER. Anksciau cia buvo UPS, dabar MANUAL
                                        //$NewVezejas = "UPS";
                                        $NewVezejas = "MANUAL";
                                    }else{
                                        $NewVezejas = "SCHENKER";
                                    }
                                    break;
                                case 'PL':
                                    if($Param['TranzitoLaikas']>=2){//jeigu tranzitas 3 d ir daugiau
                                        //20220222 - Editos laiskas (2022-02-14 08:01) - reikia nuimti UPS ir palikti tik VENIPAK IR SCHENKER. Anksciau cia buvo UPS, dabar MANUAL
                                        //$NewVezejas = "UPS";
                                        $NewVezejas = "MANUAL";

                                    }else{
                                        $NewVezejas = "SCHENKER";
                                    }
                                    break;
                                
                                default:
                                    $NewVezejas = "SCHENKER";
                                    break;
                            }
                        }else{
                            $NewVezejas = "SCHENKER";
                        }

                        //Yra papildomu salygu kurios apdorosis veliau su pakuociu ir svoriu ivedimu
                        //Schenker: jeigu yra 1 ir daugiau paletes (arba palete +plius dezutes prie tos paletes) arba bendras svoris > 100kg nesvarbu kokia pakuote, bet ne daugiau kaip 10 paleciu, arba ne daugiau kaip ??? kg
                        //ACE: jeigu dezutes/ritineliai/pakuotes iki 100kg. 
                        //Kuomet vežama daugiau kaip 10 paleciu paliekam rankiniam apdorojimui -> RANKINIS IVEDIMAS
                        break;
                    
                    default:
                        $NewVezejas = "MANUAL";
                        break;
                }//end switch
            }//end else
        }//end if
        
        echo "<HR>$NewVezejas<hr>";
        return $NewVezejas;
    }//end function


/**
 * Number of days between two dates.
 *
 * @param date $dt1    First date
 * @param date $dt2    Second date
 * @return int
 */
function daysBetween($dt1, $dt2) {
    return date_diff(
        date_create($dt2),  
        date_create($dt1)
    )->format('%a');
}



public function getOrderToShipFromNAV ($sSearch, $iTVS = ''){

    /*
    SearchDuom
          'sSiuntaID' => string '' (length=0)
          'sOrderID' => string '339112' (length=6)
          'sPackingSlip' => string '' (length=0)
          'sInvStat' => string '' (length=0)
          'sSandelys' => string 'KEG' (length=3)
          'sDatNuo' => string '2021-11-29' (length=10)
          'sDatIki' => string '2021-11-29' (length=10)
          'sVezejas' => string 'VENIPAK' (length=7)
          'sKlientas' => string 'inter' (length=5)
          'sSaliesKodas' => string 'de' (length=2)
          'sAdresas' => string 'Sodų g. ' (length=9)
          'sSiuntosBus' => string '' (length=0)
          'CB' => null    
    */    


$DataNuot=$sSearch['sDatNuo'];
$DataIkit=$sSearch['sDatIki'];


if(!$DataNuot){$DataNuot = date('Y-m-d');}

if(!$DataIkit){$DataIkit = date('Y-m-d');}

if($DataIkit<$DataNuot){
    $DataIkit = $DataNuot;
}

$DataNuo = $DataNuot . ' 00:00:00.000';
$DataIki = $DataIkit . ' 23:59:59.000';


if($sSearch['sOrderID'] OR $sSearch['sPackingSlip']){
    if($sSearch['sOrderID'] AND !$sSearch['sPackingSlip']){
        $sWHERE .= " AND H.[No_] = '".$sSearch['sOrderID']."' ";
    }elseif($sSearch['sPackingSlip'] AND !$sSearch['sOrderID']){
        $sWHERE .= " AND H.[No_] = '".$sSearch['sPackingSlip']."' ";
    }elseif($sSearch['sPackingSlip'] AND $sSearch['sOrderID']){
        $sWHERE .= " AND ( H.[No_] = '".$sSearch['sOrderID']."' AND H.[No_] = '".$sSearch['sPackingSlip']."'  ) ";
    }
}else{
    if($DataNuo AND $DataIki){
        $sWHERE .= " AND (H.[Shipment Date] >= '".$DataNuo."' AND H.[Shipment Date] <= '".$DataIki."' ) ";
    }

    
    if($sSearch['sVezejas']){
        $sWHERE .= " AND H.[Shipment Method Code] = '".$sSearch['sVezejas']."'  ";
    }

    
    if($sSearch['sKlientas']){
        $sWHERE .= " AND H.[Bill-to Name] LIKE '%".$sSearch['sKlientas']."%'  ";
    }

    
    if($sSearch['sSaliesKodas']){
        $sWHERE .= " AND H.[Ship-to Country_Region Code] = '".$sSearch['sSaliesKodas']."'  ";
    }

    
    if($sSearch['sAdresas']){
        $sWHERE .= " AND H.[Ship-to Address] LIKE '%".$sSearch['sAdresas']."%' ";
    }

    /*
    if($sSearch['sSiuntosBus']){
        $sWHERE .= " AND H.[___] = '".$sSearch['sKlientas']."'  ";
    }

    
    if($sSearch['CB']){
        $sWHERE .= " AND H.[____] = '".$sSearch['sKlientas']."'  ";
    }
    */

}//end else

    if($iTVS){
        $sWHERE .= " AND H.[Status] = '".$iTVS."'  "; // jeigu ne i patikrinima o i tvs, tai tik paruostas siuntimui siuntas... 1-paruosta siuntimui
    }



    $mssqlNAV = DBMSSqlNAV::getInstance();

    $siuntaData = array();

    if($DataNuo AND $DataIki AND ($sSearch['sSandelys']=='ETK' OR !$sSearch['sSandelys']) ){
            $qryP = "
                SELECT TOP 100 
                      'ETK' AS FromSystem
                      ,H.[Document Type] /*-> 1 */
                      ,H.[No_] /* -> Užsakymo NR */

                      ,H.[Bill-to Customer No_] /*-> Kliento ID */
                      ,H.[Bill-to Name] /* -> Kliento pavadinimas */
                      ,H.[Sell-to Phone No_] /* -> Kliento kontaktinis Tel. Nr; Gavėjo asmens Tel Nr */
                      ,H.[Sell-to E-Mail] /* -> el. Paštas (būtina) */
                      ,H.[Your Reference] /* Galima pildyti kaip papildomą info */
                      ,H.[Ship-to Name] /* -> Gavėjo asmens Vardas */
                      ,H.[Ship-to Name 2]
                      ,H.[Ship-to Address] /* -> Pristatymo adresas (gatve, namo nr,...)*/
                      ,H.[Ship-to Address 2]
                      ,H.[Ship-to City] /* -> Pristatymo miestas */
                      ,H.[Ship-to Post Code] /* -> Pristatymo pasto kodas */
                      ,H.[Ship-to Country_Region Code] /* -> Pristatymo salies kodas */

                      ,CONVERT(DATE, H.[Shipment Date]) AS 'Shipment Date'/* -> Išvežimo data */
                      ,H.[Shipment Method Code] /* -> Numatomas vežėjas */
                      ,H.[Status] /* -> 1 Laukas pažymintis, kad užsakymą galima siųsti (paruoštas siuntimui) */
                      ,H.[Location Code] /* sandelys */
                      /* ,'-------' */
                      ,COUNT(H.[No_]) AS PakKiekis
                      ,SUM(L.[Gross Weight]) AS SUM_Gross /*-> Svoris brutto*/
                      ,SUM(L.[Net Weight]) AS SUM_Net/*-> Svoris netto   */
                      ,'32' AS 'Plotis' /* Visada vienodas, nes nera duomenu apie dezutes matmenys */
                      ,'23.5' AS 'Ilgis'
                      ,'19' AS 'Aukstis'
                      /* ,'-------' */
                      ,S.[APGDVSSendToDVS] /*-> Išsiųsta į DVS*/
                      ,S.[APGDVSSendToDVSDateTime] /*-> Išsiųsta į DVS data laikas  */
                      /* ,'-------' */
                      /* ,* */
                  FROM [AURIKA CERM\$Sales Header] AS H
                  LEFT JOIN [AURIKA CERM\$Sales Line] AS L ON H.[Document Type] = L.[Document Type] AND H.[No_] = L.[Document No_]
                  LEFT JOIN [AURIKA CERM\$Sales Header\$478bcd1e-cac5-4def-9017-2ecd670bc386] AS S ON H.[Document Type] = S.[Document Type] AND H.[No_] = S.[No_]
                  WHERE 
                    left(H.[No_],3) = 'UZS'
                  /*
                        [Status] = 1 
                            AND 
                    */
                        
                        AND 
                        H.[Shipment Method Code] != 'PASIIMA'

                        ".$sWHERE."
                  GROUP BY 
                        /*FromSystem */
                        H.[Document Type]
                        ,H.[No_]
                        ,H.[Bill-to Customer No_]
                        ,H.[Bill-to Name] /* -> Kliento pavadinimas */
                        ,H.[Sell-to Phone No_] /* -> Kliento kontaktinis Tel. Nr; Gavėjo asmens Tel Nr */
                        ,H.[Sell-to E-Mail] /* -> el. Paštas (būtina) */
                        ,H.[Your Reference] /* Galima pildyti kaip papildomą info */
                        ,H.[Ship-to Name] /* -> Gavėjo asmens Vardas */
                        ,H.[Ship-to Name 2]
                        ,H.[Ship-to Address] /* -> Pristatymo adresas (gatve, namo nr,...)*/
                        ,H.[Ship-to Address 2]
                        ,H.[Ship-to City] /* -> Pristatymo miestas */
                        ,H.[Ship-to Post Code] /* -> Pristatymo pasto kodas */
                        ,H.[Ship-to Country_Region Code] /* -> Pristatymo salies kodas */

                        ,H.[Shipment Date] /* -> Išvežimo data */
                        ,H.[Shipment Method Code] /* -> Numatomas vežėjas */
                        ,H.[Status] /* -> 1 Laukas pažymintis, kad užsakymą galima siųsti (paruoštas siuntimui) */
                        ,H.[Location Code] /* sandelys */
                      
                        /*
                        ,'Plotis' 
                        ,'Ilgis'  
                        ,'Aukstis'
                        */
                      
                        ,S.[APGDVSSendToDVS] /*-> Išsiųsta į DVS*/
                        ,S.[APGDVSSendToDVSDateTime] /*-> Išsiųsta į DVS data laikas  */
                      



                ";
            $OrdersFromNAV = $mssqlNAV->querySql($qryP, 1);

    }//end if

    //!!!!!! DEBUG
    //$this->var_dump($OrdersFromNAV, "-------OrdersFromNAV <hr>$qryP<hr> ");//-----------------DEBUG

    return $OrdersFromNAV;
}//end function


//20211214
//Nuskaito is Navision Orderius kurie papuls i Lista

public function getOrderToShipFromNAVNew ($sSearch, $iTVS = ''){

    /*
    SearchDuom
          'sSiuntaID' => string '' (length=0)
          'sOrderID' => string '339112' (length=6)
          'sPackingSlip' => string '' (length=0)
          'sInvStat' => string '' (length=0)
          'sSandelys' => string 'KEG' (length=3)
          'sDatNuo' => string '2021-11-29' (length=10)
          'sDatIki' => string '2021-11-29' (length=10)
          'sVezejas' => string 'VENIPAK' (length=7)
          'sKlientas' => string 'inter' (length=5)
          'sSaliesKodas' => string 'de' (length=2)
          'sAdresas' => string 'Sodų g. ' (length=9)
          'sSiuntosBus' => string '' (length=0)
          'CB' => null    
    */    


$DataNuot=$sSearch['sDatNuo'];
$DataIkit=$sSearch['sDatIki'];


if(!$DataNuot){$DataNuot = date('Y-m-d');}

if(!$DataIkit){$DataIkit = date('Y-m-d');}

if($DataIkit<$DataNuot){
    $DataIkit = $DataNuot;
}

$DataNuo = $DataNuot . ' 00:00:00.000';
$DataIki = $DataIkit . ' 23:59:59.000';


if($iTVS){
    $sWHERE .= " WHERE [Status] = '".$iTVS."'  "; // jeigu ne i patikrinima o i tvs, tai tik paruostas siuntimui siuntas... 1-paruosta siuntimui
}else{
    $sWHERE .= " WHERE [Status] = '1'  ";
}


if($sSearch['sOrderID'] OR $sSearch['sPackingSlip'] OR $sSearch['sPackingSlipArray']){
    if($sSearch['sOrderID'] AND !$sSearch['sPackingSlip']){
        $sWHERE .= " AND [No_] = '".$sSearch['sOrderID']."' ";
    }elseif($sSearch['sPackingSlip'] AND !$sSearch['sOrderID']){
        $sWHERE .= " AND [No_] = '".$sSearch['sPackingSlip']."' ";
    }elseif($sSearch['sPackingSlip'] AND $sSearch['sOrderID']){
        $sWHERE .= " AND ( [No_] = '".$sSearch['sOrderID']."' AND [No_] = '".$sSearch['sPackingSlip']."'  ) ";
    }

    //cia ateina visi packingSlipai (Array) jeigu paieska buvo pagal siuntos duomenys. 
    //Juos issitraukem is TVS pagal siuntos duomenys ir perdavem cia. 
    //Tai buna tik NAV bazei kai ieskome siuntos Nr kuris yra CERM bazej, tad pirma istraukiam duomenys is ten ir perduodam cia
    if($sSearch['sPackingSlipArray']){
       $PackingSlipStrArray = "'" . implode("','", $sSearch['sPackingSlipArray'])."'";
       $sWHERE .= " AND [No_] IN (".$PackingSlipStrArray.") ";
    }
}else{
    if($DataNuo AND $DataIki){
        $sWHERE .= " AND ([Shipment Date] >= '".$DataNuo."' AND [Shipment Date] <= '".$DataIki."' ) ";
    }

    
    if($sSearch['sVezejas']){
        $sWHERE .= " AND [Shipment Method Code] = '".$sSearch['sVezejas']."'  ";
    }

    
    if($sSearch['sKlientas']){
        $sWHERE .= " AND [Bill-to Name] LIKE '%".$sSearch['sKlientas']."%'  ";
    }

    
    if($sSearch['sSaliesKodas']){
        $sWHERE .= " AND [Ship-to Country_Region Code] = '".$sSearch['sSaliesKodas']."'  ";
    }

    
    if($sSearch['sAdresas']){
        $sWHERE .= " AND ([Ship-to Address] LIKE '%".$sSearch['sAdresas']."%' OR [Ship-to City]  LIKE '%".$sSearch['sAdresas']."%' OR   [Ship-to Post Code]  LIKE '%".$sSearch['sAdresas']."%'   ) ";
    }

    /*
    if($sSearch['sSiuntosBus']){
        $sWHERE .= " AND [___] = '".$sSearch['sKlientas']."'  ";
    }

    
    if($sSearch['CB']){
        $sWHERE .= " AND [____] = '".$sSearch['sKlientas']."'  ";
    }
    */

}//end else


    //!!!!!! DEBUG
    //$this->var_dump($sWHERE, "-------sWHERE <hr>$qryP<hr> ");//-----------------DEBUG


    $mssqlNAV = DBMSSqlNAV::getInstance();

    $siuntaData = array();

    if($DataNuo AND $DataIki AND ($sSearch['sSandelys']=='ETK' OR !$sSearch['sSandelys']) ){
            $qryP = "
                SELECT *
                FROM (


                SELECT TOP 100 
                        'ETK' AS FromSystem 
                        ,H.[Document Type] /*-> 1 */ 
                        ,H.[No_] /* -> Užsakymo NR */ 
                        ,'' AS Invoice/* -> Užsakymo po uzsakymo uzdarymo NR */ 
                        ,H.[Bill-to Customer No_] /*-> Kliento ID */ 
                        ,H.[Bill-to Name] /* -> Kliento pavadinimas */ 
                        ,H.[Sell-to Phone No_] /* -> Kliento kontaktinis Tel. Nr; Gavėjo asmens Tel Nr */ 
                        ,H.[Sell-to E-Mail] /* -> el. Paštas (būtina) */ 
                        ,H.[Your Reference] /* Galima pildyti kaip papildomą info */ 
                        ,H.[Ship-to Name] /* -> Gavėjo asmens Vardas */ 
                        ,H.[Ship-to Name 2] ,H.[Ship-to Address] /* -> Pristatymo adresas (gatve, namo nr,...)*/ 
                        ,H.[Ship-to Address 2] ,H.[Ship-to City] /* -> Pristatymo miestas */ 
                        ,H.[Ship-to Post Code] /* -> Pristatymo pasto kodas */ 
                        ,H.[Ship-to Country_Region Code] /* -> Pristatymo salies kodas */ 
                        ,CONVERT(DATE, H.[Shipment Date]) AS 'Shipment Date'/* -> Išvežimo data */ 
                        ,H.[Shipment Method Code] /* -> Numatomas vežėjas */ 
                        ,H.[Status] /* -> 1 Laukas pažymintis, kad užsakymą galima siųsti (paruoštas siuntimui) */ 
                        ,H.[Location Code] /* sandelys */ /* ,'-------' */ 
                        ,COUNT(H.[No_]) AS PakKiekis 
                        ,SUM(L.[Gross Weight]) AS SUM_Gross /*-> Svoris brutto*/ 
                        ,SUM(L.[Net Weight]) AS SUM_Net/*-> Svoris netto */ 
                        ,'32' AS 'Plotis' /* Visada vienodas, nes nera duomenu apie dezutes matmenys */ 
                        ,'23.5' AS 'Ilgis' ,'19' AS 'Aukstis' /* ,'-------' */ 
                        ,S.[APGDVSSendToDVS] /*-> Išsiųsta į DVS*/ 
                        ,S.[APGDVSSendToDVSDateTime] /*-> Išsiųsta į DVS data laikas */ /* ,'-------' */ /* ,* */ 
                FROM [AURIKA CERM\$Sales Header] AS H LEFT 
                JOIN [AURIKA CERM\$Sales Line] AS L ON H.[Document Type] = L.[Document Type] AND H.[No_] = L.[Document No_] 
                LEFT JOIN [AURIKA CERM\$Sales Header\$478bcd1e-cac5-4def-9017-2ecd670bc386] AS S ON H.[Document Type] = S.[Document Type] AND H.[No_] = S.[No_] 
                WHERE 
                left(H.[No_],3) = 'UZS' /* [Status] = 1 AND */ 
                AND H.[Shipment Method Code] != 'PASIIMA' 
                AND (H.[Shipment Date] >= '".$DataNuo."' 
                AND H.[Shipment Date] <= '".$DataIki."' ) 
                AND H.[Status] = '1' 

                GROUP BY 
                        /*FromSystem */ 
                        H.[Document Type] 
                        ,H.[No_] 
                        ,H.[Bill-to Customer No_] 
                        ,H.[Bill-to Name] /* -> Kliento pavadinimas */ 
                        ,H.[Sell-to Phone No_] /* -> Kliento kontaktinis Tel. Nr; Gavėjo asmens Tel Nr */ 
                        ,H.[Sell-to E-Mail] /* -> el. Paštas (būtina) */ 
                        ,H.[Your Reference] /* Galima pildyti kaip papildomą info */ 
                        ,H.[Ship-to Name] /* -> Gavėjo asmens Vardas */ 
                        ,H.[Ship-to Name 2] 
                        ,H.[Ship-to Address] /* -> Pristatymo adresas (gatve, namo nr,...)*/ 
                        ,H.[Ship-to Address 2] 
                        ,H.[Ship-to City] /* -> Pristatymo miestas */ 
                        ,H.[Ship-to Post Code] /* -> Pristatymo pasto kodas */ 
                        ,H.[Ship-to Country_Region Code] /* -> Pristatymo salies kodas */ 
                        ,H.[Shipment Date] /* -> Išvežimo data */ 
                        ,H.[Shipment Method Code] /* -> Numatomas vežėjas */ 
                        ,H.[Status] /* -> 1 Laukas pažymintis, kad užsakymą galima siųsti (paruoštas siuntimui) */ 
                        ,H.[Location Code] /* sandelys */ /* ,'Plotis' ,'Ilgis' ,'Aukstis' */ 
                        ,S.[APGDVSSendToDVS] /*-> Išsiųsta į DVS*/ 
                        ,S.[APGDVSSendToDVSDateTime] /*-> Išsiųsta į DVS data laikas */
                        


                UNION

                SELECT TOP 100 
                        'ETK' AS FromSystem 
                        ,'1' AS [Document Type] /*-> 1 */ 
                        ,H.[Order No_] AS [No_] /* -> Užsakymo NR */ 
                        ,H.[No_] AS Invoice/* -> Užsakymo po uzsakymo uzdarymo NR */ 
                        ,H.[Bill-to Customer No_] /*-> Kliento ID */ 
                        ,H.[Bill-to Name] /* -> Kliento pavadinimas */ 
                        ,H.[Sell-to Phone No_] /* -> Kliento kontaktinis Tel. Nr; Gavėjo asmens Tel Nr */ 
                        ,H.[Sell-to E-Mail] /* -> el. Paštas (būtina) */ 
                        ,H.[Your Reference] /* Galima pildyti kaip papildomą info */ 
                        ,H.[Ship-to Name] /* -> Gavėjo asmens Vardas */ 
                        ,H.[Ship-to Name 2] ,H.[Ship-to Address] /* -> Pristatymo adresas (gatve, namo nr,...)*/ 
                        ,H.[Ship-to Address 2] ,H.[Ship-to City] /* -> Pristatymo miestas */ 
                        ,H.[Ship-to Post Code] /* -> Pristatymo pasto kodas */ 
                        ,H.[Ship-to Country_Region Code] /* -> Pristatymo salies kodas */ 
                        ,CONVERT(DATE, H.[Shipment Date]) AS 'Shipment Date'/* -> Išvežimo data */ 
                        ,H.[Shipment Method Code] /* -> Numatomas vežėjas */ 
                        ,'1' AS [Status] /* -> 1 Laukas pažymintis, kad užsakymą galima siųsti (paruoštas siuntimui) */ 
                        ,H.[Location Code] /* sandelys */ /* ,'-------' */ 
                        ,COUNT(H.[No_]) AS PakKiekis 
                        ,SUM(L.[Gross Weight]) AS SUM_Gross /*-> Svoris brutto*/ 
                        ,SUM(L.[Net Weight]) AS SUM_Net/*-> Svoris netto */ 
                        ,'32' AS 'Plotis' /* Visada vienodas, nes nera duomenu apie dezutes matmenys */ 
                        ,'23.5' AS 'Ilgis' ,'19' AS 'Aukstis' /* ,'-------' */ 
                        ,S.[APGDVSSendToDVS] /*-> Išsiųsta į DVS*/ 
                        ,S.[APGDVSSendToDVSDateTime] /*-> Išsiųsta į DVS data laikas */ /* ,'-------' */ /* ,* */ 
                FROM [AURIKA CERM\$Sales Invoice Header] AS H 
                LEFT JOIN [AURIKA CERM\$Sales Invoice Line] AS L ON  H.[No_] = L.[Document No_] 
                LEFT JOIN [AURIKA CERM\$Sales Invoice Header\$478bcd1e-cac5-4def-9017-2ecd670bc386] AS S ON  H.[No_] = S.[No_] 

                WHERE 
                 left(H.[Order No_],3) = 'UZS' 
                 /* [Status] = 1 AND */ 
                 AND H.[Shipment Method Code] != 'PASIIMA' 
                AND (H.[Shipment Date] >= '".$DataNuo."' 
                AND H.[Shipment Date] <= '".$DataIki."' ) 
                /* AND H.[Status] = '1' */

                GROUP BY 
                        /*FromSystem */ 
                        /* H.[Document Type] */
                        H.[Order No_]
                        ,H.[No_] 
                        ,H.[Bill-to Customer No_] 
                        ,H.[Bill-to Name] /* -> Kliento pavadinimas */ 
                        ,H.[Sell-to Phone No_] /* -> Kliento kontaktinis Tel. Nr; Gavėjo asmens Tel Nr */ 
                        ,H.[Sell-to E-Mail] /* -> el. Paštas (būtina) */ 
                        ,H.[Your Reference] /* Galima pildyti kaip papildomą info */ 
                        ,H.[Ship-to Name] /* -> Gavėjo asmens Vardas */ 
                        ,H.[Ship-to Name 2] 
                        ,H.[Ship-to Address] /* -> Pristatymo adresas (gatve, namo nr,...)*/ 
                        ,H.[Ship-to Address 2] 
                        ,H.[Ship-to City] /* -> Pristatymo miestas */ 
                        ,H.[Ship-to Post Code] /* -> Pristatymo pasto kodas */ 
                        ,H.[Ship-to Country_Region Code] /* -> Pristatymo salies kodas */ 
                        ,H.[Shipment Date] /* -> Išvežimo data */ 
                        ,H.[Shipment Method Code] /* -> Numatomas vežėjas */ 
                        /* ,H.[Status] */ /* -> 1 Laukas pažymintis, kad užsakymą galima siųsti (paruoštas siuntimui) */ 
                        ,H.[Location Code] /* sandelys */ /* ,'Plotis' ,'Ilgis' ,'Aukstis' */ 
                        ,S.[APGDVSSendToDVS] /*-> Išsiųsta į DVS*/ 
                        ,S.[APGDVSSendToDVSDateTime] /*-> Išsiųsta į DVS data laikas */
                        

                ) AS duom

                ".$sWHERE."

                ORDER BY No_ DESC


                ";
            $OrdersFromNAV = $mssqlNAV->querySql($qryP, 1);

    }//end if

    //!!!!!! DEBUG
    //$this->var_dump($OrdersFromNAV, "-------OrdersFromNAV <hr>$qryP<hr>$sWHERE ");//-----------------DEBUG

    return $OrdersFromNAV;
}//end function





//20211209
//Nuskaito is Navision Orderius kurie papuls i Lista
//nuskaito naujus (dar neregistruotus TVSe ir tuos kurie jau registruoti TVSe kaip issiusti arba pusiau issiusti)
// Po paskutinio pokalbio su Paulium NAV, greiciausiai sios funkcijos nereikes, modernizuosim senaja pridedami dar viena lentele i kuria patenka jau baigti orderiai
public function getOrderToShipFromNAVnew___ ($SearchDuom, $OrderNavArrayInTVS){

    /*
    SearchDuom
          'sSiuntaID' => string '' (length=0)
          'sOrderID' => string '339112' (length=6)
          'sPackingSlip' => string '' (length=0)
          'sInvStat' => string '' (length=0)
          'sSandelys' => string 'KEG' (length=3)
          'sDatNuo' => string '2021-11-29' (length=10)
          'sDatIki' => string '2021-11-29' (length=10)
          'sVezejas' => string 'VENIPAK' (length=7)
          'sKlientas' => string 'inter' (length=5)
          'sSaliesKodas' => string 'de' (length=2)
          'sAdresas' => string 'Sodų g. ' (length=9)
          'sSiuntosBus' => string '' (length=0)
          'CB' => null    
    */    


$DataNuot=$sSearch['sDatNuo'];
$DataIkit=$sSearch['sDatIki'];


if(!$DataNuot){$DataNuot = date('Y-m-d');}

if(!$DataIkit){$DataIkit = date('Y-m-d');}

if($DataIkit<$DataNuot){
    $DataIkit = $DataNuot;
}

$DataNuo = $DataNuot . ' 00:00:00.000';
$DataIki = $DataIkit . ' 23:59:59.000';


if($sSearch['sOrderID'] OR $sSearch['sPackingSlip']){
    if($sSearch['sOrderID'] AND !$sSearch['sPackingSlip']){
        $sWHERE .= " AND H.[No_] = '".$sSearch['sOrderID']."' ";
    }elseif($sSearch['sPackingSlip'] AND !$sSearch['sOrderID']){
        $sWHERE .= " AND H.[No_] = '".$sSearch['sPackingSlip']."' ";
    }elseif($sSearch['sPackingSlip'] AND $sSearch['sOrderID']){
        $sWHERE .= " AND ( H.[No_] = '".$sSearch['sOrderID']."' AND H.[No_] = '".$sSearch['sPackingSlip']."'  ) ";
    }
}else{
    if($DataNuo AND $DataIki){
        $sWHERE .= " AND (H.[Shipment Date] >= '".$DataNuo."' AND H.[Shipment Date] <= '".$DataIki."' ) ";
    }

    
    if($sSearch['sVezejas']){
        $sWHERE .= " AND H.[Shipment Method Code] = '".$sSearch['sVezejas']."'  ";
    }

    
    if($sSearch['sKlientas']){
        $sWHERE .= " AND H.[Bill-to Name] LIKE '%".$sSearch['sKlientas']."%'  ";
    }

    
    if($sSearch['sSaliesKodas']){
        $sWHERE .= " AND H.[Ship-to Country_Region Code] = '".$sSearch['sSaliesKodas']."'  ";
    }

    
    if($sSearch['sAdresas']){
        $sWHERE .= " AND H.[Ship-to Address] LIKE '%".$sSearch['sAdresas']."%' ";
    }

    /*
    if($sSearch['sSiuntosBus']){
        $sWHERE .= " AND H.[___] = '".$sSearch['sKlientas']."'  ";
    }

    
    if($sSearch['CB']){
        $sWHERE .= " AND H.[____] = '".$sSearch['sKlientas']."'  ";
    }
    */

}//end else

    if($iTVS){

        $sWHERE .= " AND ( H.[Status] = '1'  OR H.[No_] IN ('" . implode('\',\'', $OrderNavArrayInTVS) . "') ) "; // i tvs sarasa - ima is Navisiono jau uzregistruotus TVSe ir Naujus Navisione
    }



    $mssqlNAV = DBMSSqlNAV::getInstance();

    $siuntaData = array();

    if($DataNuo AND $DataIki AND ($sSearch['sSandelys']=='ETK' OR !$sSearch['sSandelys']) ){

            // Sales Invoice Header - siuntos kurios jau uzregistruotos , jos identiskos su lentele Sales Header bet pasikeiciasi numeris, o surisimas per lauka "Order No_" */
            $qryP = "
                SELECT TOP 100 
                      'ETK' AS FromSystem
                      ,H.[Document Type] /*-> 1 */
                      ,H.[No_] /* -> Užsakymo NR */

                      ,H.[Bill-to Customer No_] /*-> Kliento ID */
                      ,H.[Bill-to Name] /* -> Kliento pavadinimas */
                      ,H.[Sell-to Phone No_] /* -> Kliento kontaktinis Tel. Nr; Gavėjo asmens Tel Nr */
                      ,H.[Sell-to E-Mail] /* -> el. Paštas (būtina) */
                      ,H.[Your Reference] /* Galima pildyti kaip papildomą info */
                      ,H.[Ship-to Name] /* -> Gavėjo asmens Vardas */
                      ,H.[Ship-to Name 2]
                      ,H.[Ship-to Address] /* -> Pristatymo adresas (gatve, namo nr,...)*/
                      ,H.[Ship-to Address 2]
                      ,H.[Ship-to City] /* -> Pristatymo miestas */
                      ,H.[Ship-to Post Code] /* -> Pristatymo pasto kodas */
                      ,H.[Ship-to Country_Region Code] /* -> Pristatymo salies kodas */

                      ,CONVERT(DATE, H.[Shipment Date]) AS 'Shipment Date'/* -> Išvežimo data */
                      ,H.[Shipment Method Code] /* -> Numatomas vežėjas */
                      ,H.[Status] /* -> 1 Laukas pažymintis, kad užsakymą galima siųsti (paruoštas siuntimui) */
                      ,H.[Location Code] /* sandelys */
                      /* ,'-------' */
                      ,COUNT(H.[No_]) AS PakKiekis
                      ,SUM(L.[Gross Weight]) AS SUM_Gross /*-> Svoris brutto*/
                      ,SUM(L.[Net Weight]) AS SUM_Net/*-> Svoris netto   */
                      ,'32' AS 'Plotis' /* Visada vienodas, nes nera duomenu apie dezutes matmenys */
                      ,'23.5' AS 'Ilgis'
                      ,'19' AS 'Aukstis'
                      /* ,'-------' */
                      ,S.[APGDVSSendToDVS] /*-> Išsiųsta į DVS*/
                      ,S.[APGDVSSendToDVSDateTime] /*-> Išsiųsta į DVS data laikas  */
                      /* ,'-------' */
                      /* ,* */
                  FROM [AURIKA CERM\$Sales Header] AS H
                  LEFT JOIN [AURIKA CERM\$Sales Line] AS L ON H.[Document Type] = L.[Document Type] AND H.[No_] = L.[Document No_]
                  LEFT JOIN [AURIKA CERM\$Sales Header\$478bcd1e-cac5-4def-9017-2ecd670bc386] AS S ON H.[Document Type] = S.[Document Type] AND H.[No_] = S.[No_]
                  WHERE 
                    left(H.[No_],3) = 'UZS'
                  /*
                        [Status] = 1 
                            AND 
                    */
                        
                        AND 
                        H.[Shipment Method Code] != 'PASIIMA'

                        ".$sWHERE."
                  GROUP BY 
                        /*FromSystem */
                        H.[Document Type]
                        ,H.[No_]
                        ,H.[Bill-to Customer No_]
                        ,H.[Bill-to Name] /* -> Kliento pavadinimas */
                        ,H.[Sell-to Phone No_] /* -> Kliento kontaktinis Tel. Nr; Gavėjo asmens Tel Nr */
                        ,H.[Sell-to E-Mail] /* -> el. Paštas (būtina) */
                        ,H.[Your Reference] /* Galima pildyti kaip papildomą info */
                        ,H.[Ship-to Name] /* -> Gavėjo asmens Vardas */
                        ,H.[Ship-to Name 2]
                        ,H.[Ship-to Address] /* -> Pristatymo adresas (gatve, namo nr,...)*/
                        ,H.[Ship-to Address 2]
                        ,H.[Ship-to City] /* -> Pristatymo miestas */
                        ,H.[Ship-to Post Code] /* -> Pristatymo pasto kodas */
                        ,H.[Ship-to Country_Region Code] /* -> Pristatymo salies kodas */

                        ,H.[Shipment Date] /* -> Išvežimo data */
                        ,H.[Shipment Method Code] /* -> Numatomas vežėjas */
                        ,H.[Status] /* -> 1 Laukas pažymintis, kad užsakymą galima siųsti (paruoštas siuntimui) */
                        ,H.[Location Code] /* sandelys */
                      
                        /*
                        ,'Plotis' 
                        ,'Ilgis'  
                        ,'Aukstis'
                        */
                      
                        ,S.[APGDVSSendToDVS] /*-> Išsiųsta į DVS*/
                        ,S.[APGDVSSendToDVSDateTime] /*-> Išsiųsta į DVS data laikas  */
                      



                ";
            $OrdersFromNAV = $mssqlNAV->querySql($qryP, 1);

    }//end if

    //!!!!!! DEBUG
    $this->var_dump($OrdersFromNAV, "-------OrdersFromNAV <hr>$qryP<hr> ");//-----------------DEBUG

    return $OrdersFromNAV;
}//end function







//********************************
// 20211229 Arnoldas R.
// VENIPAK Pastomatu viso saraso issaugojimas DB
// Pastomatu sarasa istraukiamas is https://go.venipak.lt/ws/get_pickup_points

// $PastomataiArrayTmp - pastomatu sarasas is VENIPAK (JSON->Array)
//*******************************
public function saveVENIPAK_Pastomatai($PastomataiArrayTmp){

    $rez['DelCERM'] = 0;
    $rez['UpdCERM'] = 0;
    $rez['InsCERN'] = 0;


    $rez['DelGmod'] = 0;
    $rez['UpdGmod'] = 0;
    $rez['InsGmod'] = 0;


    $rez['DelNav'] = 0;
    $rez['UpdNav'] = 0;
    $rez['InsNav'] = 0;

    if($PastomataiArrayTmp){

            $PastomataiArray=array();
            if($PastomataiArrayTmp){

                foreach ($PastomataiArrayTmp as $keyN => $newPickUp) {
                //if($newPickUp['id']!=2446){//testavimui
                    $PastomataiArray[$newPickUp['id']]=$newPickUp;
                    $PastomataiArray[$newPickUp['id']]['Yra']='Y';//pradine reiksme

                    /* gaunamo is VENIPAK struktura 
                    $PastomataiArray[$newPickUp['id']]['pid']=$newPickUp['id'];
                    $PastomataiArray[$newPickUp['id']]['name']=$newPickUp['name'];
                    $PastomataiArray[$newPickUp['id']]['code']=$newPickUp['code'];
                    $PastomataiArray[$newPickUp['id']]['address']=$newPickUp['address'];
                    $PastomataiArray[$newPickUp['id']]['city']=$newPickUp['city'];
                    $PastomataiArray[$newPickUp['id']]['zip']=$newPickUp['zip'];
                    $PastomataiArray[$newPickUp['id']]['country']=$newPickUp['country'];
                    $PastomataiArray[$newPickUp['id']]['terminal']=$newPickUp['terminal'];
                    $PastomataiArray[$newPickUp['id']]['description']=$newPickUp['description'];
                    $PastomataiArray[$newPickUp['id']]['working_hours']='';
                    $PastomataiArray[$newPickUp['id']]['contact_t']=$newPickUp['contact_t'];
                    $PastomataiArray[$newPickUp['id']]['lat']=$newPickUp['lat'];
                    $PastomataiArray[$newPickUp['id']]['lng']=$newPickUp['lng'];
                    $PastomataiArray[$newPickUp['id']]['pick_up_enabled']=$newPickUp['pick_up_enabled'];
                    $PastomataiArray[$newPickUp['id']]['cod_enabled']=$newPickUp['cod_enabled'];
                    $PastomataiArray[$newPickUp['id']]['ldg_enabled']=$newPickUp['ldg_enabled'];
                    $PastomataiArray[$newPickUp['id']]['size_limit']=$newPickUp['size_limit'];
                    $PastomataiArray[$newPickUp['id']]['type']=$newPickUp['type'];
                    $PastomataiArray[$newPickUp['id']]['max_height']=$newPickUp['max_height'];
                    $PastomataiArray[$newPickUp['id']]['max_width']=$newPickUp['max_width'];
                    $PastomataiArray[$newPickUp['id']]['max_length']=$newPickUp['max_length'];
                    $PastomataiArray[$newPickUp['id']]['updateDate']=$newPickUp['id'];
                    $PastomataiArray[$newPickUp['id']]['Yra']='Y';//pradine reiksme
                    */
                //}//end if//testavimui
                }//end foreach
            }//end if
            unset($PastomataiArrayTmp);


        //var_dump($PastomataiArray);
        //nuskaitoma senus pastomatus, kad palygintume, kas iskrito
            $wmssql = DBMSSqlCERM::getInstance();

            /* Cia musu DB pastomatu, bet reikia lyginti su CERMiniais pastomatais. 
            Su musu nereikia lyginti nes savus  pries atnaujinima visus istrinam ir surasom is VENIPAK gautus. 
            Net ir tokiu atveju ID atitinka, nes musiskiams pid naudojam VENIPAKO id lauka, 
            todel ID visada toks pat to pacio pastomato. id, pid ir CERMO cdelokap visada vienodi
            */
            /* QRY pagal Geduka is aprasymo https://conf.aurika.lt/display/CERM/Pickup+points+import+to+CERM+other+addresses */

            $qryP = "
                SELECT
                levlok__.status__, /* CERM įrašo statusas: 0 - įrašas aktyvus, 3 - įrašas neaktyvus */
                levlok__.cdelokap, /* Pickup punkto ID */
                levlok__.handelnr, /* Pickup punkto code */
                levlok__.lok__oms, /* Pickup punkto name */
                levlok__.lok__rpn, /* sudurtinis kodas VENI_ + Pickup punkto ID, pvz VENI_1212 */
                levlok__.lev_loc1, /* Pickup punkto name */ 
                levlok__.lev_loc3, /* Pickup punkto address */
                levlok__.postnaam, /* Pickup punkto city */
                levlok__.post_ref, /* Pickup punkto zip */
                levlok__.land_ref, /* Pickup punkto country */
                levlok__.trn__ref, /* Pickup punkto country */
                konper__.knp__ref, /* reikšmė 001 */
                konper__.knp__vnm, /* reikšmė '.' (taškas) */
                konper__.knp__nam, /* reikšmė PICKUP */
                levlok__.telefoon  /* Pickup punkto contact_t */
                FROM levlok__
                LEFT JOIN konper__ ON konper__.lok__ref=levlok__.lok__ref
                WHERE
                levlok__.lok__rpn LIKE 'VENI%'
                AND levlok__.status__ = '0'
            ";

            /*
            $qryP = "
                SELECT  
                    *
                FROM _PickupLocker
            ";
            */
            $oldPickUpArrayTmp = $wmssql->querySql($qryP, 1);

            //disablinam visus senus pickupus masyve ir sutvarkom masyvo ID
            $oldPickUpArray=array();
            if($oldPickUpArrayTmp){
                foreach ($oldPickUpArrayTmp as $keyO => $oldPickUp) {

                    $oldPickUpArray[$oldPickUp['cdelokap']]['id']=$oldPickUp['cdelokap'];
                    $oldPickUpArray[$oldPickUp['cdelokap']]['name']=$oldPickUp['lok__oms'];
                    $oldPickUpArray[$oldPickUp['cdelokap']]['code']=$oldPickUp['handelnr'];
                    $oldPickUpArray[$oldPickUp['cdelokap']]['address']=$oldPickUp['lev_loc3'];
                    $oldPickUpArray[$oldPickUp['cdelokap']]['city']=$oldPickUp['postnaam'];
                    $oldPickUpArray[$oldPickUp['cdelokap']]['zip']=$oldPickUp['post_ref'];
                    $oldPickUpArray[$oldPickUp['cdelokap']]['country']=$oldPickUp['land_ref'];
                    $oldPickUpArray[$oldPickUp['cdelokap']]['terminal']='';
                    $oldPickUpArray[$oldPickUp['cdelokap']]['description']='';
                    $oldPickUpArray[$oldPickUp['cdelokap']]['working_hours']='';
                    $oldPickUpArray[$oldPickUp['cdelokap']]['contact_t']=$oldPickUp['telefoon'];
                    $oldPickUpArray[$oldPickUp['cdelokap']]['lat']='';
                    $oldPickUpArray[$oldPickUp['cdelokap']]['lng']='';
                    $oldPickUpArray[$oldPickUp['cdelokap']]['pick_up_enabled']='';
                    $oldPickUpArray[$oldPickUp['cdelokap']]['cod_enabled']='';
                    $oldPickUpArray[$oldPickUp['cdelokap']]['ldg_enabled']='';
                    $oldPickUpArray[$oldPickUp['cdelokap']]['size_limit']='';
                    $oldPickUpArray[$oldPickUp['cdelokap']]['type']='';
                    $oldPickUpArray[$oldPickUp['cdelokap']]['max_height']='';
                    $oldPickUpArray[$oldPickUp['cdelokap']]['max_width']='';
                    $oldPickUpArray[$oldPickUp['cdelokap']]['max_length']='';
                    $oldPickUpArray[$oldPickUp['cdelokap']]['updateDate']='';
                    $oldPickUpArray[$oldPickUp['cdelokap']]['Yra']='3';//pradine reiksme, kad visi deaktyvuoti...paskui pakeisim, jeigu rasim atitikima, kitaip jis bus pazymetas kaip neaktyvus
                }
            }
            unset($oldPickUpArrayTmp);

            if($oldPickUpArray){
                foreach ($oldPickUpArray as $keyO => $oldPickUp) {
                    if($oldPickUp['id']==$PastomataiArray[$keyO]['id']){//jeigu senas pastomatas yra nauju pastomatu sarase tai paliekam kaip gera ar kaip paredaguota gera, o jeigu nera tai pazymim kaip negaliojanti
                        $yra='Y'; 
                        $oldPickUpArray[$keyO]['Yra']='1';
                    }else{
                        $oldPickUpArray[$keyO]['Yra']='3';//padarom neaktyvu
                    }

                }//end foreach
            }//end if


            //FORMUOJAM XML i CERM duomenu atnaujinimui
            //pagal aprasyma https://conf.aurika.lt/display/CERM/Pickup+points+import+to+CERM+other+addresses
            //formuojam dviem etapais, pirma surasom naujus, o po to is kito masyvo tuos kurie jau neaktyvus
            $kiekPastomatyIrasyta = 0;
            $XML = '<?xml version="1.0" encoding="UTF-8"?>
<Data>';

            //surasom kuos reikia padaryti neaktyvius pastomatys
            if($oldPickUpArray){
                foreach ($oldPickUpArray as $keyO => $oldPickUp) {
                    if($oldPickUp['Yra']=='3'){//jeigu nebegaliojantis pastomatas
                        $oldPickUp['name'] = str_replace('"', '\'', $oldPickUp['name']);
                        $oldPickUp['address'] = str_replace('"', '\'', $oldPickUp['address']);
                        $oldPickUp['city'] = str_replace('"', '\'', $oldPickUp['city']);

                        
$XML .= '
<Address 
status__="3" 
cdelokap="'.$oldPickUp['id'].'" 
handelnr="'.$oldPickUp['code'].'" 
lok__oms="'.$oldPickUp['name'].'" 
lok__rpn="VENI_'.$oldPickUp['id'].'" 
lev_loc1="'.$oldPickUp['name'].'" 
lev_loc3="'.$oldPickUp['address'].'" 
postnaam="'.$oldPickUp['city'].'" 
post_ref="'.$oldPickUp['zip'].'" 
land_ref="'.$oldPickUp['country'].'" 
trn__ref="'.$oldPickUp['country'].'" 
telefoon="'.$oldPickUp['contact_t'].'"
>
</Address>
<AddressContactPerson 
cdelokap="'.$oldPickUp['id'].'" 
knp__ref="001" 
knp__vnm="." 
knp__nam="PICKUP"
>
</AddressContactPerson>';
                        $kiekPastomatyIrasyta++;
                        $rez['DelCERM']++;
                        
                    }
                }//end foreach
            }//end if

            if($PastomataiArray){
                foreach ($PastomataiArray as $keyN => $newPickUp) {
                    //if($kiekPastomatyIrasyta == 426 OR $kiekPastomatyIrasyta == 427){

                        $newPickUp['name'] = str_replace('"', '\'', $newPickUp['name']);
                        $newPickUp['address'] = str_replace('"', '\'', $newPickUp['address']);
                        $newPickUp['city'] = str_replace('"', '\'', $newPickUp['city']);
                    
$XML .= '
<Address 
status__="0" 
cdelokap="'.$newPickUp['id'].'" 
handelnr="'.$newPickUp['code'].'" 
lok__oms="'.$newPickUp['name'].'" 
lok__rpn="VENI_'.$newPickUp['id'].'" 
lev_loc1="'.$newPickUp['name'].'" 
lev_loc3="'.$newPickUp['address'].'" 
postnaam="'.$newPickUp['city'].'" 
post_ref="'.$newPickUp['zip'].'" 
land_ref="'.$newPickUp['country'].'" 
trn__ref="'.$newPickUp['country'].'" 
telefoon="'.$newPickUp['contact_t'].'"
>
</Address>
<AddressContactPerson 
cdelokap="'.$newPickUp['id'].'" 
knp__ref="001" 
knp__vnm="." 
knp__nam="PICKUP"
>
</AddressContactPerson>';

                    
                    //}
                    $kiekPastomatyIrasyta++;
                    $rez['InsCERM']++;
                }//end foreach
            }//end if



$XML .= '
</Data>
';

            //SURASOM XML FAILA
            //echo" <br><br><br> !!!!!!!!!!!!!!!!!!!!! CIA DISABLINTAS PASTOMATU XML IRASYMAS CERMUI - LIVE REIKIA ATIDISABLINTI NUO /*111 eilutes iki 1111 * / eilutes <br><br><br>";
/* 111 Atblokuoti po testavimo */
            $dat = date("YmdHis");
            $file="VENIPAK_".$dat.".xml";

            // TESTAVIMUI PAS SAVE 
            //$filePath = '..\uploads\pastomatai\\';

            //i CERM
            $filePath = '../MNT/CERM_BRF/Hotfolders/ImportOtherAddresses/';
            //$filePath_save = '..\MNT\CERM_BRF\Hotfolders\ImportOtherAddresses_FTP_moved\\';

            //if (is_writable($filePath.$file)) {
                if (!$fp = fopen($filePath.$file, 'w')) {
                     echo "<br>Cannot open file ($file)<br>";
                     exit;
                }

                // Write $somecontent to our opened file.
                if (fwrite($fp, $XML) === FALSE) {
                    echo "<br>Cannot write to file ($file)<br>";
                    exit;
                }

                echo "<br>Success, wrote to file ($file) to 'ImportOtherAddresses'<br>";

                fclose($fp);

            // i CERM istorijai
            $filePath_save = '../MNT/CERM_BRF/Hotfolders/ImportOtherAddresses_FTP_moved/';

            //if (is_writable($filePath.$file)) {
                if (!$fp = fopen($filePath_save.$file, 'w')) {
                     echo "<br>Cannot open file ($file)";
                     exit;
                }

                // Write $somecontent to our opened file.
                if (fwrite($fp, $XML) === FALSE) {
                    echo "<br>Cannot write to file ($file)";
                    exit;
                }

                echo "<br>Success, wrote to file ($file) to ImportOtherAddresses_FTP_moved<br>";

                fclose($fp);

/*  111 */



            /* ************************************* nGAMOD duomenu apdirbimas ir surasymas **************************** */
            //Pasiimam musu duomenis
            $qryM = "
                SELECT *
                FROM _PickupLocker
            ";
            $oldGmodPickUpArrayTmp = $wmssql->querySql($qryM, 1);

            $oldGmodPickUpArray = array();
            if($oldGmodPickUpArrayTmp){
                foreach ($oldGmodPickUpArrayTmp as $keyOG => $valueOG) {
                    
                    $oldGmodPickUpArray[$valueOG['pid']]=$valueOG;
                    $oldGmodPickUpArray[$valueOG['pid']]['newONOFF']='Nerastas';//visi kurie veliau neigaus zyme Yra arba Update o liks zyme "Nerastas" bus trinami, jeigu dar nebuvo istrinti anksciau (['ONOFF']='Y' AND ['newONOFF']='Nerastas')

                }//end foreach
            }//end if
            


                    /* gaunamo is VENIPAK struktura 
                    $PastomataiArray[$newPickUp['id']]['pid']=$newPickUp['id'];
                    $PastomataiArray[$newPickUp['id']]['name']=$newPickUp['name'];
                    $PastomataiArray[$newPickUp['id']]['code']=$newPickUp['code'];
                    $PastomataiArray[$newPickUp['id']]['address']=$newPickUp['address'];
                    $PastomataiArray[$newPickUp['id']]['city']=$newPickUp['city'];
                    $PastomataiArray[$newPickUp['id']]['zip']=$newPickUp['zip'];
                    $PastomataiArray[$newPickUp['id']]['country']=$newPickUp['country'];
                    $PastomataiArray[$newPickUp['id']]['terminal']=$newPickUp['terminal'];
                    $PastomataiArray[$newPickUp['id']]['description']=$newPickUp['description'];
                    $PastomataiArray[$newPickUp['id']]['working_hours']='';
                    $PastomataiArray[$newPickUp['id']]['contact_t']=$newPickUp['contact_t'];
                    $PastomataiArray[$newPickUp['id']]['lat']=$newPickUp['lat'];
                    $PastomataiArray[$newPickUp['id']]['lng']=$newPickUp['lng'];
                    $PastomataiArray[$newPickUp['id']]['pick_up_enabled']=$newPickUp['pick_up_enabled'];
                    $PastomataiArray[$newPickUp['id']]['cod_enabled']=$newPickUp['cod_enabled'];
                    $PastomataiArray[$newPickUp['id']]['ldg_enabled']=$newPickUp['ldg_enabled'];
                    $PastomataiArray[$newPickUp['id']]['size_limit']=$newPickUp['size_limit'];
                    $PastomataiArray[$newPickUp['id']]['type']=$newPickUp['type'];
                    $PastomataiArray[$newPickUp['id']]['max_height']=$newPickUp['max_height'];
                    $PastomataiArray[$newPickUp['id']]['max_width']=$newPickUp['max_width'];
                    $PastomataiArray[$newPickUp['id']]['max_length']=$newPickUp['max_length'];
                    $PastomataiArray[$newPickUp['id']]['updateDate']=$newPickUp['id'];
                    $PastomataiArray[$newPickUp['id']]['Yra']='Y';//pradine reiksme
                    */



            //sulyginam ka reikia keisti, ka trinti o kas nesikeite
            $pastomataiIrasymui = array();
            if($PastomataiArray){
                foreach ($PastomataiArray as $keyN => $valueN) {
                    if($valueN['id']==2446){
                        //echo"<br><br><br>ATEJO IS VENIPAK";
                        //var_dump($valueN);
                        //echo"<br><br><br>BUVO PAS MUS";
                        //var_dump($oldGmodPickUpArray[$keyN]);
                    }

                    if($valueN['id']==$oldGmodPickUpArray[$keyN]['pid']){
                        if(
                            $valueN['name'] == $oldGmodPickUpArray[$keyN]['name']
                            AND $valueN['code'] == $oldGmodPickUpArray[$keyN]['code']
                            AND $valueN['address'] == $oldGmodPickUpArray[$keyN]['address']
                            AND $valueN['city'] == $oldGmodPickUpArray[$keyN]['city']
                            AND $valueN['zip'] == $oldGmodPickUpArray[$keyN]['zip']
                            AND $valueN['country'] == $oldGmodPickUpArray[$keyN]['country']
                            AND $valueN['terminal'] == $oldGmodPickUpArray[$keyN]['terminal']
                            AND $valueN['working_hours'] == $oldGmodPickUpArray[$keyN]['working_hours']
                            AND $valueN['contact_t'] == $oldGmodPickUpArray[$keyN]['contact_t']
                            AND $valueN['lat'] == $oldGmodPickUpArray[$keyN]['lat']
                            AND $valueN['lng'] == $oldGmodPickUpArray[$keyN]['lng']
                            AND $oldGmodPickUpArray[$keyN]['onoff']=='Y'

                        ){
                            //niekas is esmes nepasikeite pastomete, ir senasis nebuvo disablintas, tai jo updatinti nereikia
                            //$pastomataiIrasymui[$keyN]=$valueN; - nieko nereikia daryti tai i sarasa netraukiam
                            $oldGmodPickUpArray[$keyN]['newONOFF']='Yra'; ////pazymim, kad si radom, visi kurie netures zymes Yra arba Update o liks zyme "Nerastas" bus trinami, jeigu dar nebuvo istrinti  (['ONOFF']='Y' AND ['newONOFF']='Nerastas')
                        }else{
                            //toks pastomatas jau buvo, bet jame kazkas pasikeite, arba senasis buvo disablintas, tai reikia updatinti
                            $pastomataiIrasymui[$keyN]=$valueN;
                            $pastomataiIrasymui[$keyN]['onoff'] = 'Y';//padarom aktyvu
                            $pastomataiIrasymui[$keyN]['newONOFF'] = 'Update';//pazymim, kad si updatinsim
                            $oldGmodPickUpArray[$keyN]['newONOFF']='Update';//pazymim, kad si radom, visi kurie netures zymes Yra arba Update o liks zyme "Nerastas" bus trinami, jeigu dar nebuvo istrinti  (['ONOFF']='Y' AND ['newONOFF']='Nerastas')
                        }
                    }else{
                        $pastomataiIrasymui[$keyN] = $valueN;
                        $pastomataiIrasymui[$keyN]['newONOFF'] = 'New';
                    }

                    if($valueN['id']==2446){
                        //var_dump($valueN);
                        //echo"<br><br><br>PAS MUS PO PALYGINIMO";
                        //var_dump($oldGmodPickUpArray[$keyN]);
                    }

                }//end foreach
            }//end if

//echo"<hr>Irasymui";
//var_dump ($pastomataiIrasymui);

            //dabar tikrinam kuriuos reikia istrinti is senu ir jie dar nebuvo istrinti iki siol
            //visi kurie netures zymes Yra arba Update o liks zyme "Nerastas" bus trinami, jeigu dar nebuvo istrinti  (['ONOFF']='Y' AND ['newONOFF']='Nerastas')
            $pastomataiTrinimui = array();
            if($oldGmodPickUpArray){
                foreach ($oldGmodPickUpArray as $keyOG => $valueOG) {
                    if($valueOG['onoff']=='Y' AND $valueOG['newONOFF']=='Nerastas'){
                        $pastomataiTrinimui[$keyN]=$valueOG;
                        $pastomataiTrinimui[$keyN]['newONOFF'] = 'Disable';//pazymim, kad si disablinsim
                    }
                }//end foreach
            }//end if
//echo"<hr>Trinimui ARRAY";
//var_dump ($pastomataiTrinimui);
//echo"<hr>";

            //SURASOM DUOMENYS I MUSU DB LENTELE "_PickupLocker "
                try {

                    //istrinam senus pastomatus kuriuos reikia istrinti
                    if($pastomataiTrinimui){
                        foreach ($pastomataiTrinimui as $keyDel => $valueDel) {
                            if($valueDel['pid']){
                                $sqldel = '
                                UPDATE 
                                    "sqlb00"."dbo"."_PickupLocker" SET "onoff"=N\'N\'
                                WHERE pid = '.$valueDel['pid'].';
                                ';
                                
                                //var_dump($sqldel);
                                $retSQL = $wmssql->execSql($sqldel); 
                                $rez['DelGmod']++;
                            }//end if

                        }//end foreach
                    }//end if


                    /*
                    $sqldel = '
                        DELETE FROM "_PickupLocker" ;
                    ';
                    */



                    $siandien = date("Y-m-d H:i:s");

                    //atnaujinam pastomatus kuriuos reikia atnaujinti
                    
                    if($pastomataiIrasymui){

                        foreach ($pastomataiIrasymui as $keyUP => $pastomUP) {
                                if($pastom['id']==2446){
                                    //echo "<hr>TESTINIS UP";
                                    //var_dump($pastomUP);
                                    //echo "<hr>";
                                }

                            if($pastomUP['newONOFF']=="Update"){
                                $sqlupd = '
                                UPDATE 
                                    "sqlb00"."dbo"."_PickupLocker" SET 
                                    "name"=N\''.$pastomUP["name"].'\',
                                    "code"=N\''.$pastomUP["code"].'\',

                                    "address"=N\''.$pastomUP["address"].'\',
                                    "city"=N\''.$pastomUP["city"].'\',
                                    "zip"=N\''.$pastomUP["zip"].'\',
                                    "country"=N\''.$pastomUP["country"].'\',

                                    "terminal"=\''.$pastomUP["terminal"].'\',
                                    "description"=N\''.$pastomUP["description"].'\',
                                    "working_hours"=N\''.$pastomUP["working_hours"].'\',
                                    "contact_t"=N\''.$pastomUP["contact_t"].'\',

                                    "lat"=\''.$pastomUP["lat"].'\',
                                    "lng"=\''.$pastomUP["lng"].'\',

                                    "pick_up_enabled"='.$pastomUP["pick_up_enabled"].',
                                    "cod_enabled"='.$pastomUP["cod_enabled"].',
                                    "ldg_enabled"='.$pastomUP["ldg_enabled"].',
                                    "size_limit"='.$pastomUP["size_limit"].',

                                    "type"='.$pastomUP["type"].',
                                    "max_height"='.$pastomUP["max_height"].',
                                    "max_width"='.$pastomUP["max_width"].',
                                    "max_length"='.$pastomUP["max_length"].',
                                    "updateDate"=\''.$siandien.'\',
                                    "onoff"=N\''.$pastomUP["onoff"].'\'
                                WHERE pid = '.$pastomUP['id'].' ;
                                ';

                                $retSQLupd = $wmssql->execSql($sqlupd, 1); 
                                $rez['UpdGmod']++;

                                //testavimui
                                if($pastomUP['id']==2446){
                                    //echo "<hr>TESTINIS";
                                    //var_dump($sqlupd);
                                    //echo "<hr>";
                                }


                            }//end if
                        }//end foreach




                        //irasom naujus pastomatus
                        foreach ($pastomataiIrasymui as $key => $pastom) {
                            if($pastomUP['newONOFF']=="New"){
                                if($pastom['id']==2446){
                                    //echo "<hr>TESTINIS UP";
                                    //var_dump($pastomUP);
                                    //echo "<hr>";
                                }

                                    $sql = "
                                        INSERT INTO _PickupLocker (
                                            pid, 
                                            name,
                                            code,

                                            address, 
                                            city, 
                                            zip, 
                                            country, 

                                            terminal,
                                            description, 
                                            working_hours,
                                            contact_t,

                                            lat, 
                                            lng, 

                                            pick_up_enabled,
                                            cod_enabled, 
                                            ldg_enabled, 
                                            size_limit, 

                                            type,
                                            max_height,
                                            max_width,
                                            max_length,
                                            updateDate,
                                            onoff
                                        ) VALUES (
                                            '".$pastom['id']."', 
                                            N'".$pastom['name']."', 
                                            N'".$pastom['code']."', 

                                            N'".$pastom['address']."', 
                                            N'".$pastom['city']."', 
                                            N'".$pastom['zip']."', 
                                            N'".$pastom['country']."', 

                                            N'".$pastom['terminal']."', 
                                            N'".$pastom['description']."', 
                                            N'".$pastom['working_hours']."', 
                                            N'".$pastom['contact_t']."', 

                                            '".$pastom['lat']."', 
                                            '".$pastom['lng']."', 

                                            '".$pastom['pick_up_enabled']."', 
                                            '".$pastom['cod_enabled']."', 
                                            '".$pastom['ldg_enabled']."', 
                                            '".$pastom['size_limit']."', 

                                            '".$pastom['type']."', 
                                            '".$pastom['max_height']."', 
                                            '".$pastom['max_width']."', 
                                            '".$pastom['max_length']."', 
                                            '".$siandien."',
                                            N'".$pastom['Yra']."'

                                        );                    
                                    ";

                                    //$wmssql = DBMSSqlCERM::getInstance();
                                    $retSQL = $wmssql->execSql($sql, 1); 
                                    $rez['InsGmod']++;

                                    $testing = $retSQL > 0;
                                    $test[$test_name] &= $testing;


                                    //testavimui
                                    //if($pastom['id']==2446){
                                        //echo "<hr>TESTINIS INS";
                                        //var_dump($sql);
                                        //echo "<hr>";
                                    //}

                                    
                                    
                                    /*
                                    if ($testing) {
                                        
                                        if($retSQL){//jeigu issisaugojo 

                                        }else{//end if
                                            $this->AddError("Duomenys neišsaugoti.");
                                            $ret = 'NOT OK DB';
                                        }

                                    } else{
                                        $ret = 'OK DB1';
                                    }
                                    */
                            }//end if
                        }//end foreach

                        
                    }//end if
            } catch (Exception $ex) {
                $this->AddError((string)$ex);
                $ret = '<br>NOT OK DB<br>';
            }//catch












            /* ************************************* NAVISION duomenu apdirbimas ir surasymas **************************** */
            //Pasiimam musu duomenis
            $qryM = '
                SELECT 
                    A."Customer No_",
                    A."Code" AS "pid",
                    A."Name",
                    A."Name 2",
                    A."Address",
                    A."Address 2",
                    A."City",
                    A."Contact",
                    A."Phone No_",
                    A."Telex No_",
                    A."Shipment Method Code",
                    A."Shipping Agent Code",
                    A."Place of Export",
                    A."Country_Region Code",
                    A."Last Date Modified",
                    A."Location Code",
                    A."Fax No_",
                    A."Telex Answer Back",
                    A."Post Code",
                    A."County",
                    A."E-Mail",
                    A."Home Page",
                    A."Tax Area Code",
                    A."Tax Liable",
                    A."Shipping Agent Service Code",
                    A."Service Zone Code",
                    A."GLN",
                    B."Customer No_" AS "B_Customer No_",
                    B."Code" AS "B_Code",
                    B."APGDVSBlocked" AS "onoff"
                FROM "AURIKA_CERM"."dbo"."AURIKA CERM$Ship-to Address" AS A
                LEFT JOIN "AURIKA_CERM"."dbo"."AURIKA CERM$Ship-to Address$478bcd1e-cac5-4def-9017-2ecd670bc386"  AS B ON A."Customer No_"= B."Customer No_" AND A."Code"=B."Code"
                WHERE A."Customer No_" = \'VENIPAK_TERMINAL\';            
            ';

            $oldNAVPickUpArrayTmp = $wmssql->querySql($qryM, 1);

            $oldNAVPickUpArray = array();
            if($oldNAVPickUpArrayTmp){
                foreach ($oldNAVPickUpArrayTmp as $keyOG => $valueOG) {
                    
                    $oldNAVPickUpArray[$valueOG['pid']]=$valueOG;
                    $oldNAVPickUpArray[$valueOG['pid']]['newONOFF']='Nerastas';//visi kurie veliau neigaus zyme Yra arba Update o liks zyme "Nerastas" bus trinami, jeigu dar nebuvo istrinti anksciau (['ONOFF']='Y' AND ['newONOFF']='Nerastas')

                }//end foreach
            }//end if
            

            //echo"<br><br><br>NAV PO PALYGINIMO";
            //var_dump($oldNAVPickUpArray);


                    /* gaunamo is VENIPAK struktura 
                    $PastomataiArray[$newPickUp['id']]['pid']=$newPickUp['id'];
                    $PastomataiArray[$newPickUp['id']]['name']=$newPickUp['name'];
                    $PastomataiArray[$newPickUp['id']]['code']=$newPickUp['code'];
                    $PastomataiArray[$newPickUp['id']]['address']=$newPickUp['address'];
                    $PastomataiArray[$newPickUp['id']]['city']=$newPickUp['city'];
                    $PastomataiArray[$newPickUp['id']]['zip']=$newPickUp['zip'];
                    $PastomataiArray[$newPickUp['id']]['country']=$newPickUp['country'];
                    $PastomataiArray[$newPickUp['id']]['terminal']=$newPickUp['terminal'];
                    $PastomataiArray[$newPickUp['id']]['description']=$newPickUp['description'];
                    $PastomataiArray[$newPickUp['id']]['working_hours']='';
                    $PastomataiArray[$newPickUp['id']]['contact_t']=$newPickUp['contact_t'];
                    $PastomataiArray[$newPickUp['id']]['lat']=$newPickUp['lat'];
                    $PastomataiArray[$newPickUp['id']]['lng']=$newPickUp['lng'];
                    $PastomataiArray[$newPickUp['id']]['pick_up_enabled']=$newPickUp['pick_up_enabled'];
                    $PastomataiArray[$newPickUp['id']]['cod_enabled']=$newPickUp['cod_enabled'];
                    $PastomataiArray[$newPickUp['id']]['ldg_enabled']=$newPickUp['ldg_enabled'];
                    $PastomataiArray[$newPickUp['id']]['size_limit']=$newPickUp['size_limit'];
                    $PastomataiArray[$newPickUp['id']]['type']=$newPickUp['type'];
                    $PastomataiArray[$newPickUp['id']]['max_height']=$newPickUp['max_height'];
                    $PastomataiArray[$newPickUp['id']]['max_width']=$newPickUp['max_width'];
                    $PastomataiArray[$newPickUp['id']]['max_length']=$newPickUp['max_length'];
                    $PastomataiArray[$newPickUp['id']]['updateDate']=$newPickUp['id'];
                    $PastomataiArray[$newPickUp['id']]['Yra']='Y';//pradine reiksme
                    */



            //sulyginam ka reikia keisti, ka trinti o kas nesikeite
            $pastomataiIrasymui = array();

            //echo"<br><br><br>VENI PO PALYGINIMO";
            //var_dump($PastomataiArray);

            if($PastomataiArray){//duomenys is VENIPAK
                //$i=0;// tik testavimui
                foreach ($PastomataiArray as $keyN => $valueN) {
                    /*
                    if($valueN['country']=='LT'){
                        echo"<br><br><br>ATEJO IS VENIPAK";
                        var_dump($valueN);
                        echo"<br><br><br>BUVO NAV";
                        var_dump($oldNAVPickUpArray[$keyN]);
                    }
                    */
                    //if($oldNAVPickUpArray[$keyN]['Customer No_']=="VENIPAK_TERMINAL"){//apsisaugom jeigu netycia nuskaitem ne pastomato adresa
                
                    if($valueN['country']=='LT'){
                        //if($i<5){ //tik testavimui
                            if($valueN['id']==$oldNAVPickUpArray[$keyN]['pid']){
                                if(
                                    $valueN['name'] == $oldNAVPickUpArray[$keyN]['Name']
                                    AND $valueN['code'] == $oldNAVPickUpArray[$keyN]['Address 2']
                                    AND $valueN['address'] == $oldNAVPickUpArray[$keyN]['Address']
                                    AND $valueN['city'] == $oldNAVPickUpArray[$keyN]['City']
                                    AND $valueN['zip'] == $oldNAVPickUpArray[$keyN]['Post Code']
                                    AND $valueN['country'] == $oldNAVPickUpArray[$keyN]['Country_Region Code']
                                    AND $valueN['terminal'] == $oldNAVPickUpArray[$keyN]['Service Zone Code']
                                    //AND $valueN['working_hours'] == $oldNAVPickUpArray[$keyN]['working_hours']
                                    AND $valueN['contact_t'] == $oldNAVPickUpArray[$keyN]['Contact']
                                    //AND $valueN['lat'] == $oldNAVPickUpArray[$keyN]['lat']
                                    //AND $valueN['lng'] == $oldNAVPickUpArray[$keyN]['lng']
                                    AND $oldNAVPickUpArray[$keyN]['onoff']=='0'

                                ){
                                    //niekas is esmes nepasikeite pastomete, ir senasis nebuvo disablintas, tai jo updatinti nereikia
                                    //$pastomataiIrasymui[$keyN]=$valueN; - nieko nereikia daryti tai i sarasa netraukiam
                                    $oldNAVPickUpArray[$keyN]['newONOFF']='Yra'; ////pazymim, kad si radom, visi kurie netures zymes Yra arba Update o liks zyme "Nerastas" bus trinami, jeigu dar nebuvo istrinti  (['ONOFF']='Y' AND ['newONOFF']='Nerastas')
                                }else{
                                    //toks pastomatas jau buvo, bet jame kazkas pasikeite, arba senasis buvo disablintas, tai reikia updatinti
                                    $pastomataiIrasymui[$keyN]=$valueN;
                                    $pastomataiIrasymui[$keyN]['onoff'] = '0';//padarom aktyvu
                                    $pastomataiIrasymui[$keyN]['newONOFF'] = 'Update';//pazymim, kad si updatinsim
                                    $oldNAVPickUpArray[$keyN]['newONOFF']='Update';//pazymim, kad si radom, visi kurie netures zymes Yra arba Update o liks zyme "Nerastas" bus trinami, jeigu dar nebuvo istrinti  (['ONOFF']='Y' AND ['newONOFF']='Nerastas')

                                    /*
                                    echo"<hr>ID:".$valueN['id']."<br>";
                                    var_dump($valueN);
                                    echo "<br><br>";
                                    var_dump($oldNAVPickUpArray[$keyN]);
                                    */
                                }
                                
                            }else{
                                $pastomataiIrasymui[$keyN] = $valueN;
                                $pastomataiIrasymui[$keyN]['newONOFF'] = 'New';
                            }
                        //}//end if tik testavimui
                        //$i++;//tik testavimui
                    }//end if

                    /*
                    if($valueN['id']==2778){
                        echo"<br><br><br> VENI 2778";
                        var_dump($valueN);
                        echo"<br><br><br>NAV 2778";
                        var_dump($oldNAVPickUpArray[$keyN]);
                    }
                    */
                    
                    
                }//end foreach
            }//end if

//echo"<hr>NAV Irasymui";
//var_dump ($pastomataiIrasymui);

            //dabar tikrinam kuriuos reikia istrinti is senu ir jie dar nebuvo istrinti iki siol
            //visi kurie netures zymes Yra arba Update o liks zyme "Nerastas" bus trinami, jeigu dar nebuvo istrinti  (['ONOFF']='Y' AND ['newONOFF']='Nerastas')
            $pastomataiTrinimui = array();
            if($oldNAVPickUpArray){
                foreach ($oldNAVPickUpArray as $keyOG => $valueOG) {
                    if($valueOG['onoff']=='0' AND $valueOG['newONOFF']=='Nerastas'){
                        $pastomataiTrinimui[$keyN]=$valueOG;
                        $pastomataiTrinimui[$keyN]['newONOFF'] = 'Disable';//pazymim, kad si disablinsim
                    }
                }//end foreach
            }//end if
//echo"<hr>NAV Trinimui ARRAY";
//var_dump ($pastomataiTrinimui);
//echo"<hr>";


$siandien = date("Y-m-d H:i:s");
$date = date("Y-m-d 00:00:00.000");
            //SURASOM DUOMENYS I NAV DB LENTELE 
                try {
                    $mssqlNAV = DBMSSqlNAV::getInstance();
                    //istrinam senus pastomatus kuriuos reikia istrinti
                    if($pastomataiTrinimui){
                        foreach ($pastomataiTrinimui as $keyDel => $valueDel) {
                            if($valueDel['pid']){
                                //trinimas pazymimas tik pagalbineje lenteleje "AURIKA CERM$Ship-to Address$478bcd1e-cac5-4def-9017-2ecd670bc386"
                                $sqldel = '
                                UPDATE 
                                    "AURIKA_CERM"."dbo"."AURIKA CERM$Ship-to Address$478bcd1e-cac5-4def-9017-2ecd670bc386" SET "APGDVSBlocked"=1
                                WHERE "Customer No_" = \'VENIPAK_TERMINAL\' AND "Code" = \''.$valueDel['pid'].'\';
                                ';
                                
                                //var_dump($sqldel);

                                $retSQL = $mssqlNAV->execSql($sqldel); 
                                $rez['DelNav']++;
                            }//end if

                        }//end foreach
                    }//end if


                    

                    //atnaujinam pastomatus kuriuos reikia atnaujinti
                    if($pastomataiIrasymui){
//var_dump($pastomataiIrasymui);
                        foreach ($pastomataiIrasymui as $keyUP => $pastomUP) {
                                /*
                                if($pastom['id']==2446){
                                    echo "<hr>TESTINIS UP";
                                    var_dump($pastomUP);
                                    echo "<hr>";
                                }
                                */

                            if($pastomUP['newONOFF']=="Update"){
                                /*
                                $valueN['name'] == $oldNAVPickUpArray[$keyN]['Name']
                                AND $valueN['code'] == $oldNAVPickUpArray[$keyN]['Address 2']
                                AND $valueN['address'] == $oldNAVPickUpArray[$keyN]['Address']
                                AND $valueN['city'] == $oldNAVPickUpArray[$keyN]['City']
                                AND $valueN['zip'] == $oldNAVPickUpArray[$keyN]['Post Code']
                                AND $valueN['Country_Region Code'] == $oldNAVPickUpArray[$keyN]['Country']
                                AND $valueN['terminal'] == $oldNAVPickUpArray[$keyN]['Service Zone Code']
                                //AND $valueN['working_hours'] == $oldNAVPickUpArray[$keyN]['working_hours']
                                AND $valueN['contact_t'] == $oldNAVPickUpArray[$keyN]['Contact']
                                //AND $valueN['lat'] == $oldNAVPickUpArray[$keyN]['lat']
                                //AND $valueN['lng'] == $oldNAVPickUpArray[$keyN]['lng']
                                AND $oldNAVPickUpArray[$keyN]['onoff']=='0'
                                */
                                
                                $sqlupd = '
                                UPDATE 
                                    "AURIKA_CERM"."dbo"."AURIKA CERM$Ship-to Address" SET 

                                    "Customer No_"=N\'VENIPAK_TERMINAL\',
                                    "Code"=N\''.$pastomUP['id'].'\',
                                    "Name"=N\''.$pastomUP['name'].'\',
                                    "Name 2"=N\'\',
                                    "Address"=N\''.$pastomUP['address'].'\',
                                    "Address 2"=N\''.$pastomUP['code'].'\',
                                    "City"=N\''.$pastomUP['city'].'\',
                                    "Contact"=N\''.$pastomUP['contact_t'].'\',
                                    "Phone No_"=N\'\',
                                    "Telex No_"=N\'\',
                                    "Shipment Method Code"=N\'\',
                                    "Shipping Agent Code"=N\'\',
                                    "Place of Export"=N\'\',
                                    "Country_Region Code"=N\''.$pastomUP['country'].'\',
                                    "Last Date Modified"=\''.$date.'\',
                                    "Location Code"=N\'\',
                                    "Fax No_"=N\'\',
                                    "Telex Answer Back"=N\'\',
                                    "Post Code"=N\''.$pastomUP['zip'].'\',
                                    "County"=N\'\',
                                    "E-Mail"=N\'\',
                                    "Home Page"=N\'\',
                                    "Tax Area Code"=N\'\',
                                    "Tax Liable"=\'\',
                                    "Shipping Agent Service Code"=N\'\',
                                    "Service Zone Code"=N\''.$pastomUP['terminal'].'\',
                                    "GLN"=N\'\'
                                WHERE "Customer No_"=\'VENIPAK_TERMINAL\' AND  "Code" = \''.$pastomUP['id'].'\' ;
                                ';

                                $retSQLupd = $mssqlNAV->execSql($sqlupd, 1); 

                                //updatinam, jeigu reikia vel prikelti is disablintu
                                $sqlupd1 = '
                                UPDATE 
                                    "AURIKA_CERM"."dbo"."AURIKA CERM$Ship-to Address$478bcd1e-cac5-4def-9017-2ecd670bc386" SET 
                                    "APGDVSBlocked"=N\''.$pastomUP['onoff'].'\'
                                WHERE "Customer No_"=\'VENIPAK_TERMINAL\' AND  "Code" = \''.$pastomUP['id'].'\' ;
                                ';

                                $retSQLupd = $mssqlNAV->execSql($sqlupd1, 1); 





                                $rez['UpdNav']++;

                                //testavimui
                                
                                /*
                                //if($pastomUP['id']==2446){
                                    echo "<hr>TESTINIS UPD";
                                    var_dump($sqlupd);
                                    echo "<hr>";
                                //}
                                */
                                


                            }//end if
                        }//end foreach




                        //irasom naujus pastomatus
                        foreach ($pastomataiIrasymui as $key => $pastomIn) {
                            if($pastomIn['newONOFF']=="New"){
                                    /*
                                    if($pastom['id']==1275){
                                        echo "<hr>TESTINIS 1275";
                                        var_dump($pastomIn);
                                        echo "<hr>";
                                    }
                                    */

                                    $sql = '
                                        INSERT INTO "AURIKA_CERM"."dbo"."AURIKA CERM$Ship-to Address" (

                                            "Customer No_",
                                            "Code",
                                            "Name",
                                            "Name 2",
                                            "Address",
                                            "Address 2",
                                            "City",
                                            "Contact",
                                            "Phone No_",
                                            "Telex No_",
                                            "Shipment Method Code",
                                            "Shipping Agent Code",
                                            "Place of Export",
                                            "Country_Region Code",
                                            "Last Date Modified",
                                            "Location Code",
                                            "Fax No_",
                                            "Telex Answer Back",
                                            "Post Code",
                                            "County",
                                            "E-Mail",
                                            "Home Page",
                                            "Tax Area Code",
                                            "Tax Liable",
                                            "Shipping Agent Service Code",
                                            "Service Zone Code",
                                            "GLN"

                                        ) VALUES (
                                            N\'VENIPAK_TERMINAL\',
                                            N\''.$pastomIn['id'].'\',
                                            N\''.$pastomIn['name'].'\',
                                            N\''.$pastomIn['code'].'\',
                                            N\''.$pastomIn['address'].'\',
                                            N\'\',
                                            N\''.$pastomIn['city'].'\',
                                            N\''.$pastomIn['contact_t'].'\',
                                            N\'\',
                                            N\'\',
                                            N\'\',
                                            N\'\',
                                            N\'\',
                                            N\''.$pastomIn['country'].'\',
                                            \''.$date.'\',
                                            N\'\',
                                            N\'\',
                                            N\'\',
                                            N\''.$pastomIn['zip'].'\',
                                            N\'\',
                                            N\'\',
                                            N\'\',
                                            N\'\',
                                            \'\',
                                            N\'\',
                                            N\''.$pastomIn['terminal'].'\',
                                            N\'\'

                                        );                    
                                    ';

                                    //$wmssql = DBMSSqlCERM::getInstance();
                                    $retSQL = $mssqlNAV->execSql($sql, 1); 
                                    $testing = $retSQL > 0;
                                    $test[$test_name] &= $testing;

                                    //testavimui
                                    
                                    /*
                                    //if($pastom['id']==2446){
                                        echo "<hr>TESTINIS INS";
                                        var_dump($sql);
                                        echo "<hr>";
                                    //}
                                    */
                                    

                                    /* sito nereikia, ji padaro NAVisiono trigeris, atsiranda automatu */
                                    $sql2 = '
                                        INSERT INTO "AURIKA_CERM"."dbo"."AURIKA CERM$Ship-to Address$478bcd1e-cac5-4def-9017-2ecd670bc386" (

                                            "Customer No_",
                                            "Code",
                                            "APGDVSBlocked"
                                        ) VALUES (
                                            N\'VENIPAK_TERMINAL\',
                                            N\''.$pastomIn['id'].'\',
                                            0
                                        );                    
                                    ';

                                    //$wmssql = DBMSSqlCERM::getInstance();
                                    $retSQL = $wmssql->execSql($sql2, 1); 
                                    $rez['InsNav']++;


                                    /*
                                    if ($testing) {
                                        
                                        if($retSQL){//jeigu issisaugojo 

                                        }else{//end if
                                            $this->AddError("Duomenys neišsaugoti.");
                                            $ret = 'NOT OK DB';
                                        }

                                    } else{
                                        $ret = 'OK DB1';
                                    }
                                    */
                            }//end if
                        }//end foreach

                        
                    }//end if
            } catch (Exception $ex) {
                $this->AddError((string)$ex);
                $ret = '<br>NOT OK DB<br>';
            }//catch





    }//end if PastomataiArray

    var_dump ($rez);

    echo "<br><hr>DONE<br>";

    return $ret;

}//end function


/* funkcija skirta tik pataisyti pastomatu adresus NAVISIONE
seip veikloje nenaudojama ir pasileidzia tik is controller'io testFun.php
*/
public function repairNavPastomatai (){

    $mssqlNAV = DBMSSqlNAV::getInstance();
            $qryM = '
                SELECT 
                    A."Customer No_",
                    A."Code" AS "pid",
                    A."Name",
                    A."Name 2",
                    A."Address",
                    A."Address 2",
                    A."City",
                    A."Contact",
                    A."Phone No_",
                    A."Telex No_",
                    A."Shipment Method Code",
                    A."Shipping Agent Code",
                    A."Place of Export",
                    A."Country_Region Code",
                    A."Last Date Modified",
                    A."Location Code",
                    A."Fax No_",
                    A."Telex Answer Back",
                    A."Post Code",
                    A."County",
                    A."E-Mail",
                    A."Home Page",
                    A."Tax Area Code",
                    A."Tax Liable",
                    A."Shipping Agent Service Code",
                    A."Service Zone Code",
                    A."GLN",
                    B."Customer No_" AS "B_Customer No_",
                    B."Code" AS "B_Code",
                    B."APGDVSBlocked" AS "onoff"
                FROM "AURIKA_CERM"."dbo"."AURIKA CERM$Ship-to Address" AS A
                LEFT JOIN "AURIKA_CERM"."dbo"."AURIKA CERM$Ship-to Address$478bcd1e-cac5-4def-9017-2ecd670bc386"  AS B ON A."Customer No_"= B."Customer No_" AND A."Code"=B."Code"
                WHERE A."Customer No_" = \'VENIPAK_TERMINAL\';            
            ';

            $oldNAVPickUpArrayTmp = $mssqlNAV->querySql($qryM, 1);

            $countUpd = 0;
            if($oldNAVPickUpArrayTmp){
                foreach ($oldNAVPickUpArrayTmp as $key => $value) {
                    if ($value['onoff']=== NULL){
                                    $sql2 = '
                                        INSERT INTO "AURIKA_CERM"."dbo"."AURIKA CERM$Ship-to Address$478bcd1e-cac5-4def-9017-2ecd670bc386" (
                                            "Customer No_",
                                            "Code",
                                            "APGDVSBlocked"
                                        ) VALUES (
                                            N\'VENIPAK_TERMINAL\',
                                            N\''.$value['pid'].'\',
                                            0
                                        );                    
                                    ';

                                    if($countUpd<10){
                                        echo $sql2. "<br><br>";
                                    }
                                    //$wmssql = DBMSSqlCERM::getInstance();
                                    $retSQL = $mssqlNAV->execSql($sql2, 1); 
                        $countUpd++;
                    }//end if
                }//end foreach                    
            }//end if

            return "OK COUNT: ". $countUpd." is: ". count($oldNAVPickUpArrayTmp);
}//end function



}//end class3


?>
