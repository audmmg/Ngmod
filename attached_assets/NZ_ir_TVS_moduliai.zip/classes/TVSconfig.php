<?php
// IMPORTANT!
// Copy it as "config.php" and MAKE YOUR CHANGES THERE

class TVS_CONFIG {

    //VENIPAK
    const VENIPAK_MODE = 'test'; //test/live

    //SCHENKER
    const SCHENKER_MODE = 'test'; //test/live

    //UPS
    const UPS_MODE = 'test'; //test/live

    //ACE
    const ACE_MODE = 'test'; //test/live

    //CAT
    const CAT_MODE = 'test'; //test/live

    //MANUAL
    const MANUAL_MODE = 'test'; //test/live


    //DIR ROOT
    const TVS_IMG_ROOT = '../../';
    const TVS_LABEL_ROOT = '../../';
    const TVS_DOWNLOAD_ROOT = '../../';


    //public static $DEBUG_ECHO_SQLS = false;

}


